// ===== SISTEMA COMPLETO DE SUPORTE - VERSÃO CORRIGIDA =====

// ===== CONFIGURAÇÕES =====
const EMAILJS_CONFIG = {
    serviceId: 'service_w7gwnny',
    templateId: 'template_a51plye', 
    publicKey: 'DMPGPzWLXVS9oMNmo'
};
// ===== VARIÁVEIS GLOBAIS =====
let isOnline = navigator.onLine;
let supportState = {
    activeTab: 'bug',
    supportData: {
        bugs: [],
        suggestions: [],
        helpRequests: []
    }
};

// ===== INICIALIZAÇÃO DO EMAILJS =====
function initializeEmailJS() {
    if (typeof emailjs !== 'undefined') {
        emailjs.init(EMAILJS_CONFIG.publicKey);
        console.log('✅ EmailJS inicializado com sucesso');
        return true;
    } else {
        console.error('❌ EmailJS não carregado');
        return false;
    }
}

// ===== SISTEMA DE SUPORTE CORRIGIDO =====
function openSupport() {
    console.log('🎯 Abrindo suporte...');
    
    // Inicializar EmailJS se necessário
    initializeEmailJS();
    
    const modal = document.getElementById('supportModal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        resetSupportForms();
        setupModalEvents();
    } else {
        console.log('📦 Criando modal de suporte...');
        createSupportModal();
    }
}

function closeSupport() {
    console.log('🚪 Fechando suporte...');
    
    const modal = document.getElementById('supportModal');
    if (modal) {
        modal.classList.add('hidden');
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

function closeSupportAndReset() {
    closeSupport();
    resetSupportForms();
    
    setTimeout(() => {
        showToast('✅ Mensagem enviada com sucesso! Obrigado pelo contato.');
    }, 500);
}

function setupModalEvents() {
    const modal = document.getElementById('supportModal');
    if (!modal) return;
    
    // Fechar modal ao clicar fora
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeSupport();
        }
    });
    
    // Fechar modal com ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
            closeSupport();
        }
    });
}

function openTab(tabName) {
    console.log('📑 Abrindo aba:', tabName);
    
    // Remover active de todas as tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Adicionar active à tab clicada
    const clickedBtn = event.target.closest('.tab-btn');
    if (clickedBtn) {
        clickedBtn.classList.add('active');
    }
    
    const tabContent = document.getElementById(tabName);
    if (tabContent) {
        tabContent.classList.add('active');
    }
    
    supportState.activeTab = tabName;
}

function resetSupportForms() {
    console.log('🧹 Limpando formulários...');
    
    // Limpar todos os campos dos formulários
    const inputs = document.querySelectorAll('#supportModal input, #supportModal textarea');
    inputs.forEach(input => {
        if (input.type !== 'button' && input.type !== 'submit') {
            input.value = '';
        }
    });
    
    // Resetar selects
    const selects = document.querySelectorAll('#supportModal select');
    selects.forEach(select => {
        if (select.options.length > 0) {
            select.selectedIndex = 0;
        }
    });
    
    // Resetar para a primeira aba
    const firstTab = document.querySelector('.tab-btn');
    if (firstTab) {
        firstTab.click();
    }
}

// ===== FUNÇÕES AUXILIARES =====
function getSuggestionTypeName(type) {
    const types = {
        'newFeature': 'Nova Funcionalidade',
        'visualImprovement': 'Melhoria Visual', 
        'newGameMode': 'Novo Modo de Jogo',
        'performance': 'Melhoria de Performance',
        'other': 'Outro'
    };
    return types[type] || type;
}

function getBugCategoryName(category) {
    const categories = {
        'technical': 'Problema Técnico',
        'questionError': 'Erro em Pergunta',
        'accountIssue': 'Problema de Conta',
        'other': 'Outro'
    };
    return categories[category] || category;
}

function saveSupportRequest(type, data) {
    const requestType = type === 'bug' ? 'bugs' : 
                       type === 'suggestion' ? 'suggestions' : 'helpRequests';
    
    if (!supportState.supportData[requestType]) {
        supportState.supportData[requestType] = [];
    }
    
    supportState.supportData[requestType].push({
        ...data,
        timestamp: new Date().toISOString(),
        id: Date.now().toString(),
        status: 'enviado'
    });
    
    localStorage.setItem('quizEduSupportData', JSON.stringify(supportState.supportData));
    console.log('💾 Mensagem salva no histórico local');
}

function validateForm(title, description) {
    if (!title || title.trim() === '') {
        showToast('❌ Por favor, digite um título');
        return false;
    }
    
    if (!description || description.trim() === '') {
        showToast('❌ Por favor, digite uma descrição');
        return false;
    }
    
    if (title.length < 5) {
        showToast('❌ O título deve ter pelo menos 5 caracteres');
        return false;
    }
    
    if (description.length < 10) {
        showToast('❌ A descrição deve ter pelo menos 10 caracteres');
        return false;
    }
    
    return true;
}

// ===== SISTEMA DE EMAIL PROFISSIONAL CORRIGIDO =====
async function submitSupport() {
    console.log('📤 Enviando mensagem de suporte...');
    
    const activeTab = supportState.activeTab;
    
    if (!isOnline) {
        showToast('📡 Sem internet - Conecte-se para enviar mensagem');
        return;
    }

    showToast('📨 Enviando sua mensagem...');

    try {
        // Coletar dados básicos do usuário
        const currentUser = window.currentUser || {};
        
        let templateParams = {
            name: currentUser.name || 'Visitante',
            email: currentUser.email || 'nao-informado@quizedu.com',
            user_name: currentUser.name || 'Visitante',
            user_points: currentUser.points || 0,
            user_agent: navigator.userAgent.substring(0, 100),
            date: new Date().toLocaleString('pt-BR'),
            to_email: 'jidelcorporation7@gmail.com'
        };

        // Coletar dados específicos de cada aba
        let title, description, category;
        
        if (activeTab === 'suggestion') {
            title = document.getElementById('suggestionTitle')?.value || '';
            description = document.getElementById('suggestionDescription')?.value || '';
            category = document.getElementById('suggestionCategory')?.value || 'newFeature';
            
            if (!validateForm(title, description)) return;

            templateParams = {
                ...templateParams,
                type: 'Sugestão',
                category: getSuggestionTypeName(category),
                subject: `Sugestão: ${title}`,
                message: description,
                to_name: 'Suporte QUIZ-EDU'
            };
        } else if (activeTab === 'bug') {
            title = document.getElementById('bugTitle')?.value || '';
            description = document.getElementById('bugDescription')?.value || '';
            category = document.getElementById('bugCategory')?.value || 'technical';
            
            if (!validateForm(title, description)) return;

            templateParams = {
                ...templateParams,
                type: 'Bug Report',
                category: getBugCategoryName(category),
                subject: `Bug: ${title}`,
                message: description,
                to_name: 'Suporte Técnico QUIZ-EDU'
            };
        } else {
            // Ajuda geral
            templateParams = {
                ...templateParams,
                type: 'Ajuda Geral',
                category: 'help',
                subject: 'Pedido de Ajuda QUIZ-EDU',
                message: 'Preciso de assistência com o jogo QUIZ-EDU',
                to_name: 'Suporte QUIZ-EDU'
            };
        }

        console.log('📤 Enviando email com parâmetros:', templateParams);

        // Verificar se EmailJS está disponível
        if (typeof emailjs === 'undefined') {
            throw new Error('EmailJS não disponível');
        }

        // ENVIO VIA EMAILJS
        const response = await emailjs.send(
            EMAILJS_CONFIG.serviceId, 
            EMAILJS_CONFIG.templateId, 
            templateParams
        );

        console.log('✅ Email enviado com sucesso:', response);
        
        // Fechar modal e limpar formulário
        closeSupportAndReset();
        
        // Salvar localmente o histórico
        saveSupportRequest(activeTab, templateParams);
        
    } catch (error) {
        console.error('❌ Erro no EmailJS:', error);
        
        // Informações detalhadas do erro
        let errorMessage = 'Erro ao enviar email';
        if (error.text) {
            console.error('Detalhes do erro EmailJS:', error.text);
            errorMessage = error.text;
        }
        
        showToast('❌ Erro ao enviar. Usando método alternativo...');
        
        // Fallback para email tradicional
        sendFallbackEmail(templateParams);
    }
}

function sendFallbackEmail(params) {
    console.log('📧 Usando fallback de email...');
    
    const subject = `🎮 QUIZ-EDU ${params.type}: ${params.subject}`;
    const body = `
De: ${params.name} (${params.email})
Data: ${params.date}

📋 INFORMAÇÕES:
• Tipo: ${params.type}
• Categoria: ${params.category}
• Usuário: ${params.user_name}
• Pontuação: ${params.user_points}

📝 MENSAGEM:
${params.message}

---
🛠️ DADOS TÉCNICOS:
Navegador: ${params.user_agent}

Enviado via QUIZ-EDU Support System
    `.trim();

    const mailtoLink = `mailto:jidelcorporation7@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    
    console.log('📧 Abrindo cliente de email:', mailtoLink);
    
    // Fechar modal primeiro
    closeSupportAndReset();
    
    // Pequeno delay para usuário ver o feedback
    setTimeout(() => {
        window.open(mailtoLink, '_blank');
        showToast('📧 Email aberto! Complete e envie manualmente.');
    }, 1000);
}

// ===== SISTEMA DE AJUDA RÁPIDA =====
function openFAQ() {
    createInfoModal(
        '📖 FAQ - Perguntas Frequentes',
        `
        <div class="faq-content">
            <div class="faq-item">
                <h3>❓ Como criar uma conta?</h3>
                <p>Clique em "Criar Conta" na tela inicial e preencha seus dados básicos: email, senha e nome (opcional).</p>
            </div>
            
            <div class="faq-item">
                <h3>🎮 Como jogar?</h3>
                <p>1. Faça login ➝ 2. Escolha um modo de jogo ➝ 3. Selecione categorias ➝ 4. Comece a responder perguntas!</p>
            </div>
            
            <div class="faq-item">
                <h3>🏆 Como ganhar pontos?</h3>
                <p>• Cada resposta correta: +10 pontos<br>• Acertos consecutivos: bônus de streak<br>• Medalhas: Ouro (90%+), Prata (70%+), Bronze (50%+)</p>
            </div>

            <div class="faq-item">
                <h3>🔔 O que é o Modo Buzzer?</h3>
                <p>Competição entre 2 jogadores - quem buzinar primeiro responde! Acertos: +10 pontos, Erros: -5 pontos.</p>
            </div>

            <div class="faq-item">
                <h3>👥 Como funciona o Multiplayer?</h3>
                <p>Até 4 jogadores podem competir localmente. Cada um responde às mesmas perguntas e vence quem fizer mais pontos.</p>
            </div>

            <div class="faq-item">
                <h3>💾 Meus dados estão seguros?</h3>
                <p>Sim! Todos os dados são armazenados localmente no seu navegador. Não coletamos informações pessoais.</p>
            </div>
        </div>

        <style>
            .faq-content {
                max-height: 400px;
                overflow-y: auto;
                padding: 10px;
            }
            .faq-item {
                margin-bottom: 20px;
                padding: 15px;
                background: var(--bg-dark);
                border-radius: 10px;
                border-left: 4px solid var(--primary);
            }
            .faq-item h3 {
                margin: 0 0 10px 0;
                color: var(--primary);
                font-size: 1.1em;
            }
            .faq-item p {
                margin: 0;
                color: var(--text);
                line-height: 1.5;
            }
        </style>
        `
    );
}

function openTutorial() {
    createInfoModal(
        '🎬 Tutorial - Como Usar o QUIZ-EDU',
        `
        <div style="text-align: center; max-height: 400px; overflow-y: auto;">
            <div style="margin-bottom: 25px;">
                <h3 style="color: var(--primary); margin-bottom: 15px;">🚀 Começando</h3>
                <div style="display: flex; flex-direction: column; gap: 10px; text-align: left;">
                    <div>1. <strong>Crie sua conta</strong> ou faça login</div>
                    <div>2. <strong>Escolha um modo de jogo</strong> que mais gosta</div>
                    <div>3. <strong>Configure categorias</strong> e número de perguntas</div>
                    <div>4. <strong>Responda perguntas</strong> e ganhe pontos</div>
                    <div>5. <strong>Suba no ranking</strong> e conquiste medalhas</div>
                </div>
            </div>

            <div style="margin-bottom: 25px;">
                <h3 style="color: var(--primary); margin-bottom: 15px;">🎯 Dicas de Jogo</h3>
                <div style="display: flex; flex-direction: column; gap: 8px; text-align: left;">
                    <div>• <strong>Use a Ajuda</strong> quando estiver em dúvida entre opções</div>
                    <div>• <strong>Mantenha o streak</strong> para ganhar bônus</div>
                    <div>• <strong>Jogue todos os modos</strong> para descobrir seu favorito</div>
                    <div>• <strong>Revise as explicações</strong> para aprender mais</div>
                </div>
            </div>

            <div>
                <h3 style="color: var(--primary); margin-bottom: 15px;">⚡ Modos Disponíveis</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; text-align: left;">
                    <div><strong>🎯 Solo:</strong> Treine sozinho</div>
                    <div><strong>👥 Multiplayer:</strong> Competição local</div>
                    <div><strong>🔔 Buzzer:</strong> Reação rápida</div>
                    <div><strong>⚡ SpeedQuiz:</strong> Contra o tempo</div>
                    <div><strong>🧩 Puzzle:</strong> Montar respostas</div>
                    <div><strong>➗ Tabuada:</strong> Desafio matemático</div>
                </div>
            </div>
        </div>
        `
    );
}

function contactEmail() {
    const currentUser = window.currentUser || {};
    const email = 'jidelcorporation7@gmail.com';
    const subject = 'Suporte QUIZ-EDU - Ajuda Personalizada';
    const body = `
Olá equipe QUIZ-EDU,

Preciso de ajuda com:

[Descreva seu problema ou dúvida aqui]

---
Informações do usuário:
- Nome: ${currentUser.name || 'Não logado'}
- Email: ${currentUser.email || 'Não informado'}
- Data: ${new Date().toLocaleDateString('pt-BR')}

Atenciosamente,
${currentUser.name || 'Usuário QUIZ-EDU'}
    `.trim();

    window.open(`mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
    showToast('📧 Email aberto! Descreva sua dúvida.');
}

// ===== FUNÇÃO DE MODAL UNIVERSAL =====
function createInfoModal(title, content) {
    // Remover modal existente
    const existingModal = document.querySelector('.info-modal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal info-modal';
    modal.style.display = 'flex';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>${title}</h2>
                <button class="close-btn" onclick="this.closest('.modal').remove()">&times;</button>
            </div>
            <div class="modal-body">${content}</div>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="this.closest('.modal').remove()">
                    Fechar
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Fechar modal clicando fora
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
        }
    });

    return modal;
}

function createSupportModal() {
    console.log('🏗️ Criando modal de suporte...');
    
    const modal = document.createElement('div');
    modal.id = 'supportModal';
    modal.className = 'modal hidden';
    modal.style.display = 'none';
    
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>🎯 Suporte & Sugestões</h2>
                <button class="close-btn" onclick="closeSupport()">&times;</button>
            </div>
            
            <div class="support-tabs">
                <button class="tab-btn active" onclick="openTab('bug')">🐛 Reportar Bug</button>
                <button class="tab-btn" onclick="openTab('suggestion')">💡 Sugestão</button>
                <button class="tab-btn" onclick="openTab('help')">❓ Ajuda</button>
            </div>
            
            <!--Formulário de Bug -->
            
            <div id="bug" class="tab-content active">
                <div class="form-group">
                    <label class="form-label">Título do Problema</label>
                    <input type="text" class="form-input" id="bugTitle" placeholder="Descreva brevemente o problema">
                </div>
                <div class="form-group">
                    <label class="form-label">Descrição Detalhada</label>
                    <textarea class="form-input" id="bugDescription" rows="4" placeholder="Descreva o problema em detalhes..."></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Categoria</label>
                    <select class="form-select" id="bugCategory">
                        <option value="technical">Problema técnico</option>
                        <option value="questionError">Erro em pergunta</option>
                        <option value="accountIssue">Problema de conta</option>
                        <option value="other">Outro</option>
                    </select>
                </div>
            </div>
            
                        <!-- Formulário de Sugestão -->
            <div id="suggestion" class="tab-content">
                <div class="form-group">
                    <label class="form-label">Título da Sugestão</label>
                    <input type="text" class="form-input" id="suggestionTitle" placeholder="Sua sugestão em uma frase">
                </div>
                <div class="form-group">
                    <label class="form-label">Descrição Detalhada</label>
                    <textarea class="form-input" id="suggestionDescription" rows="4" placeholder="Descreva sua ideia em detalhes..."></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Categoria</label>
                    <select class="form-select" id="suggestionCategory">
                        <option value="newFeature">Nova funcionalidade</option>
                        <option value="visualImprovement">Melhoria visual</option>
                        <option value="newGameMode">Novo modo de jogo</option>
                        <option value="performance">Melhoria de performance</option>
                        <option value="other">Outro</option>
                    </select>
                </div>
            </div>
            
            <!-- Ajuda Rápida -->
            <div id="help" class="tab-content">
                <h3>📞 Canais de Ajuda</h3>
                <div class="help-options">
                    <button class="help-btn" onclick="openFAQ()">
                        <span class="help-icon">📖</span>
                        <span class="help-text">FAQ/Perguntas Frequentes</span>
                    </button>
                    <button class="help-btn" onclick="contactEmail()">
                        <span class="help-icon">📧</span>
                        <span class="help-text">Email: jidelcorporation7@gmail.com</span>
                    </button>
                    <button class="help-btn" onclick="openTutorial()">
                        <span class="help-icon">🎬</span>
                        <span class="help-text">Tutorial em Vídeo</span>
                    </button>
                </div>
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-primary" onclick="submitSupport()">Enviar Mensagem</button>
                <button class="btn btn-secondary" onclick="closeSupport()">Cancelar</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Configurar eventos
    setupModalEvents();
    
    // Mostrar o modal
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.classList.remove('hidden');
    }, 10);
    
    return modal;
}

// ===== SISTEMA DE VERIFICAÇÃO DE INTERNET =====
function checkInternetConnection() {
    isOnline = navigator.onLine;
    
    if (isOnline) {
        console.log('🌐 Conectado à internet');
    } else {
        console.log('📡 Modo Offline');
        showToast('📡 Sem conexão com a internet');
    }
    
    return isOnline;
}

// ===== INICIALIZAÇÃO =====
function initializeSupportSystem() {
    console.log('🛠️ Inicializando sistema de suporte...');
    
    // Carregar dados de suporte salvos
    try {
        const savedSupportData = localStorage.getItem('quizEduSupportData');
        if (savedSupportData) {
            supportState.supportData = JSON.parse(savedSupportData);
            console.log('📂 Histórico de suporte carregado');
        }
    } catch (error) {
        console.error('❌ Erro ao carregar histórico de suporte:', error);
    }
    
    // Configurar event listeners de rede
    window.addEventListener('online', () => {
        isOnline = true;
        showToast('🌐 Conexão restaurada - Sistema online');
    });

    window.addEventListener('offline', () => {
        isOnline = false;
        showToast('📡 Sem internet - Modo offline');
    });
    
    // Inicializar EmailJS
    initializeEmailJS();
    
    // Verificar conexão inicial
    checkInternetConnection();
    
    console.log('✅ Sistema de suporte inicializado!');
}

// ===== FUNÇÃO TOAST MELHORADA =====
function showToast(message, duration = 3000) {
    // Usar a função global se existir
    if (window.showToast && typeof window.showToast === 'function') {
        window.showToast(message, duration);
        return;
    }
    
    // Fallback simples
    console.log('💬 Toast:', message);
    
    // Criar toast básico
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        bottom: 100px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--text);
        color: var(--bg-card);
        padding: 12px 25px;
        border-radius: 25px;
        box-shadow: var(--shadow);
        z-index: 1001;
        font-weight: 600;
        animation: toastSlideUp 0.3s ease;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Adicionar animação CSS se não existir
    if (!document.querySelector('style#toast-animations')) {
        const style = document.createElement('style');
        style.id = 'toast-animations';
        style.textContent = `
            @keyframes toastSlideUp {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, duration);
}

// ===== INICIALIZAÇÃO AUTOMÁTICA =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM carregado - Iniciando sistema de suporte...');
    setTimeout(() => {
        initializeSupportSystem();
    }, 1000);
});

// ===== EXPORTAÇÃO PARA USO GLOBAL =====
window.openSupport = openSupport;
window.closeSupport = closeSupport;
window.openTab = openTab;
window.submitSupport = submitSupport;
window.openFAQ = openFAQ;
window.openTutorial = openTutorial;
window.contactEmail = contactEmail;
window.createInfoModal = createInfoModal;
window.initializeSupportSystem = initializeSupportSystem;

console.log('🛠️ Sistema de suporte carregado e pronto!');