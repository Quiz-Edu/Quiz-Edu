// © 2025 QUIZ-EDU™ — All Rights Reserved
// Uso permitido somente para jogar. Modificações ou redistribuição proibidas.
// ===== SISTEMA PRINCIPAL DO JOGO =====

// ===== ESTADO GLOBAL =====
let currentUser = null;
let gameState = {
    mode: null,
    score: 0,
    streak: 0,
    currentQuestion: 0,
    totalQuestions: 10,
    timeLeft: 30,
    timer: null,
    helpUsed: false,
    selectedCategories: [],
    questions: []
};

let buzzerState = {
    active: false,
    currentPlayer: null,
    scores: {1: 0, 2: 0},
    timer: 15,
    buzzerTimer: null,
    questionActive: false
};

// ===== SISTEMA DE CONFIGURAÇÃO DE JOGO =====
let gameConfig = {
    mode: '',
    category: 'random',
    questionCount: 10,
    difficulty: 'medium',
    timePerQuestion: 30
};

// ===== BANCO DE DADOS LOCAL =====
const DB_USERS = 'quiz_edu_users';
const DB_RANKING = 'quiz_edu_ranking';
const DB_SETTINGS = 'quiz_edu_settings';

// ===== FUNÇÕES DE ARMAZENAMENTO =====
function getUsers() {
    try {
        return JSON.parse(localStorage.getItem(DB_USERS) || '[]');
    } catch (error) {
        console.error('Erro ao carregar usuários:', error);
        return [];
    }
}

function saveUsers(users) {
    try {
        localStorage.setItem(DB_USERS, JSON.stringify(users));
    } catch (error) {
        console.error('Erro ao salvar usuários:', error);
        showToast('Erro ao salvar dados do usuário');
    }
}

function getRanking() {
    try {
        return JSON.parse(localStorage.getItem(DB_RANKING) || '[]');
    } catch (error) {
        console.error('Erro ao carregar ranking:', error);
        return [];
    }
}

function saveRanking(ranking) {
    try {
        localStorage.setItem(DB_RANKING, JSON.stringify(ranking));
    } catch (error) {
        console.error('Erro ao salvar ranking:', error);
    }
}

function getSettings() {
    const defaultSettings = {
        sound: {
            volume: 50,
            music: true,
            effects: true
        },
        game: {
            difficulty: 'medium',
            timer: true,
            animations: true
        },
        appearance: {
            theme: 'dark',
            language: 'pt'
        }
    };
    
    try {
        const saved = JSON.parse(localStorage.getItem(DB_SETTINGS));
        return {...defaultSettings, ...saved};
    } catch (error) {
        console.error('Erro ao carregar configurações:', error);
        return defaultSettings;
    }
}

function saveSettings(settings) {
    try {
        localStorage.setItem(DB_SETTINGS, JSON.stringify(settings));
        console.log('⚙️ Configurações salvas:', settings);
    } catch (error) {
        console.error('Erro ao salvar configurações:', error);
        showToast('Erro ao salvar configurações');
    }
}

// ===== SISTEMA DE AUTENTICAÇÃO =====
function register() {
    const name = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value.trim();
    const genderElement = document.querySelector('input[name="gender"]:checked');
    
    if (!genderElement) {
        showToast('Por favor, selecione um gênero');
        return;
    }
    
    const gender = genderElement.value;
    const messageEl = document.getElementById('regMessage');
    
    if (!email || !password) {
        messageEl.textContent = 'Por favor, preencha email e senha.';
        messageEl.style.color = 'var(--danger)';
        return;
    }
    
    if (password.length < 4) {
        messageEl.textContent = 'A senha deve ter pelo menos 4 caracteres.';
        messageEl.style.color = 'var(--danger)';
        return;
    }
    
    const users = getUsers();
    
    if (users.find(user => user.email === email)) {
        messageEl.textContent = 'Este email já está registrado.';
        messageEl.style.color = 'var(--danger)';
        return;
    }
    
    const username = name || generateUsername(email);
    
    const newUser = {
        id: Date.now().toString(),
        name: username,
        email: email,
        password: password,
        gender: gender,
        points: 0,
        gamesPlayed: 0,
        medals: { gold: 0, silver: 0, bronze: 0 },
        joinDate: new Date().toISOString(),
        avatar: '👤',
        level: 1,
        lastLogin: new Date().toISOString()
    };
    
    users.push(newUser);
    saveUsers(users);
    
    showToast('🎉 Conta criada com sucesso!');
    showSection('login');
    
    // Limpar formulário
    document.getElementById('regName').value = '';
    document.getElementById('regEmail').value = '';
    document.getElementById('regPassword').value = '';
    messageEl.textContent = '';
}

function generateUsername(email) {
    const base = email.split('@')[0];
    const random = Math.floor(Math.random() * 1000);
    return base + random;
}

function login() {
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    
    const messageEl = document.getElementById('loginMessage');
    
    if (!email || !password) {
        messageEl.textContent = 'Por favor, preencha email e senha.';
        messageEl.style.color = 'var(--danger)';
        return;
    }
    
    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
        messageEl.textContent = 'Email ou senha incorretos.';
        messageEl.style.color = 'var(--danger)';
        return;
    }
    
    // Atualizar último login
    user.lastLogin = new Date().toISOString();
    const userIndex = users.findIndex(u => u.id === user.id);
    users[userIndex] = user;
    saveUsers(users);
    
    currentUser = user;
    localStorage.setItem('quizEduLastUser', user.email);
    
    showSection('modes');
    showToast(`👋 Bem-vindo de volta, ${user.name}!`);
    
    updateProfile();
    updateTopBar();
    
    // Limpar formulário
    document.getElementById('loginEmail').value = '';
    document.getElementById('loginPassword').value = '';
    messageEl.textContent = '';
}

function recoverAccount() {
    const email = document.getElementById('recoverEmail').value.trim();
    const messageEl = document.getElementById('recoverMessage');
    
    if (!email) {
        messageEl.textContent = 'Por favor, digite seu email.';
        messageEl.style.color = 'var(--danger)';
        return;
    }
    
    const users = getUsers();
    const user = users.find(u => u.email === email);
    
    if (user) {
        messageEl.textContent = 'Instruções de recuperação enviadas para seu email.';
        messageEl.style.color = 'var(--success)';
        
        // Simular envio de email (em produção, integrar com serviço de email)
        console.log('📧 Email de recuperação enviado para:', email);
        
        // Limpar campo
        document.getElementById('recoverEmail').value = '';
    } else {
        messageEl.textContent = 'Email não encontrado.';
        messageEl.style.color = 'var(--danger)';
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('quizEduLastUser');
    showSection('initial');
    showToast('👋 Você saiu da conta.');
}

// ===== SISTEMA DE INTERFACE =====
function showSection(sectionId) {
    console.log('🔄 Mostrando seção:', sectionId);
    
    // Esconder todos os menus de idioma abertos
    const langMenus = document.querySelectorAll('.lang-menu');
    langMenus.forEach(menu => menu.classList.add('hidden'));
    
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Esconder task bar durante o jogo
    const topBar = document.querySelector('.top-bar');
    const footer = document.querySelector('.footer');
    
    if (sectionId === 'quiz' || sectionId === 'buzzer' || sectionId === 'multiplayer-local') {
        if (topBar) topBar.style.display = 'none';
        if (footer) footer.style.display = 'none';
        document.body.style.paddingTop = '0';
        document.body.style.paddingBottom = '0';
    } else {
        if (topBar) topBar.style.display = 'flex';
        if (footer) footer.style.display = 'block';
        document.body.style.paddingTop = '70px';
        document.body.style.paddingBottom = '70px';
    }
    
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    } else {
        console.error('❌ Seção não encontrada:', sectionId);
        showSection('initial');
    }
}

function showToast(message, duration = 3000) {
    // Verificar se já existe um toast ativo e remover
    const existingToast = document.getElementById('toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Criar novo toast
    const toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 100px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--text);
        color: var(--bg-card);
        padding: 12px 25px;
        border-radius: 25px;
        box-shadow: var(--shadow);
        z-index: 1001;
        animation: slideUp 0.3s ease;
        font-weight: 600;
    `;
    
    document.body.appendChild(toast);
    
    // Adicionar animação CSS se não existir
    if (!document.querySelector('style#toast-animations')) {
        const style = document.createElement('style');
        style.id = 'toast-animations';
        style.textContent = `
            @keyframes slideUp {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, duration);
}

function updateTopBar() {
    if (currentUser) {
        const userPointsEl = document.getElementById('userPointsTop');
        if (userPointsEl) {
            userPointsEl.textContent = currentUser.points;
        }
        
        // Atualizar último login se necessário
        const users = getUsers();
        const userIndex = users.findIndex(u => u.id === currentUser.id);
        if (userIndex !== -1) {
            users[userIndex].lastLogin = new Date().toISOString();
            saveUsers(users);
        }
    }
}

// ===== SISTEMA DE PERFIL =====
function updateProfile() {
    if (!currentUser) return;
    
    document.getElementById('profileName').textContent = currentUser.name;
    document.getElementById('profileEmail').textContent = currentUser.email;
    document.getElementById('profileAvatar').textContent = currentUser.avatar;
    
    document.getElementById('statPoints').textContent = currentUser.points;
    document.getElementById('statGames').textContent = currentUser.gamesPlayed;
    document.getElementById('statMedals').textContent = 
        currentUser.medals.gold + currentUser.medals.silver + currentUser.medals.bronze;
    
    document.getElementById('goldMedals').textContent = currentUser.medals.gold;
    document.getElementById('silverMedals').textContent = currentUser.medals.silver;
    document.getElementById('bronzeMedals').textContent = currentUser.medals.bronze;
    
    // Calcular posição no ranking
    const users = getUsers();
    const sortedUsers = [...users].sort((a, b) => b.points - a.points);
    const position = sortedUsers.findIndex(user => user.id === currentUser.id) + 1;
    document.getElementById('statRank').textContent = '#' + position;
}

// ===== SISTEMA DE CONFIGURAÇÕES FUNCIONAL =====
function loadSettingsToUI() {
    const settings = getSettings();
    
    console.log('⚙️ Carregando configurações para UI:', settings);
    
    // Configurações de Som
    const masterVolume = document.getElementById('masterVolume');
    const volumeValue = document.getElementById('volumeValue');
    const musicToggle = document.getElementById('musicToggle');
    const effectsToggle = document.getElementById('effectsToggle');
    
    if (masterVolume) {
        masterVolume.value = settings.sound.volume;
        if (volumeValue) {
            volumeValue.textContent = settings.sound.volume + '%';
        }
    }
    
    if (musicToggle) musicToggle.checked = settings.sound.music;
    if (effectsToggle) effectsToggle.checked = settings.sound.effects;
    
    // Configurações de Jogo
    const difficultySelect = document.getElementById('difficultySelect');
    const timerToggle = document.getElementById('timerToggle');
    const animationsToggle = document.getElementById('animationsToggle');
    
    if (difficultySelect) difficultySelect.value = settings.game.difficulty;
    if (timerToggle) timerToggle.checked = settings.game.timer;
    if (animationsToggle) animationsToggle.checked = settings.game.animations;
    
    // Aplicar configurações imediatamente
    applySoundSettings(settings.sound);
    applyGameSettings(settings.game);
}

function saveSettingsFromUI() {
    const settings = {
        sound: {
            volume: parseInt(document.getElementById('masterVolume').value),
            music: document.getElementById('musicToggle').checked,
            effects: document.getElementById('effectsToggle').checked
        },
        game: {
            difficulty: document.getElementById('difficultySelect').value,
            timer: document.getElementById('timerToggle').checked,
            animations: document.getElementById('animationsToggle').checked
        }
    };
    
    saveSettings(settings);
    applySoundSettings(settings.sound);
    applyGameSettings(settings.game);
    
    showToast('✅ Configurações salvas!');
}

function applySoundSettings(soundSettings) {
    // Aplicar no sistema de áudio
    if (typeof audioSystem !== 'undefined') {
        audioSystem.volume = soundSettings.volume / 100;
        audioSystem.musicEnabled = soundSettings.music;
        audioSystem.effectsEnabled = soundSettings.effects;
        audioSystem.enabled = soundSettings.effects;
        
        // Atualizar música de fundo baseado nas configurações
        if (soundSettings.music && !audioSystem.currentMusic) {
            audioSystem.playBackgroundMusic();
        } else if (!soundSettings.music && audioSystem.currentMusic) {
            audioSystem.stopBackgroundMusic();
        }
        
        console.log('🔊 Configurações de som aplicadas:', soundSettings);
    }
}

function applyGameSettings(gameSettings) {
    // Aplicar configurações de jogo
    gameConfig.difficulty = gameSettings.difficulty;
    
    console.log('🎮 Configurações de jogo aplicadas:', gameSettings);
}

// Event Listeners para configurações em tempo real
function setupSettingsEventListeners() {
    // Volume - atualização em tempo real
    const masterVolume = document.getElementById('masterVolume');
    if (masterVolume) {
        masterVolume.addEventListener('input', function() {
            const volumeValue = document.getElementById('volumeValue');
            if (volumeValue) {
                volumeValue.textContent = this.value + '%';
            }
            
            // Aplicar imediatamente
            if (typeof audioSystem !== 'undefined') {
                audioSystem.volume = this.value / 100;
            }
        });
    }
    
    // Music toggle - atualização em tempo real
    const musicToggle = document.getElementById('musicToggle');
    if (musicToggle) {
        musicToggle.addEventListener('change', function() {
            if (typeof audioSystem !== 'undefined') {
                audioSystem.musicEnabled = this.checked;
                if (this.checked) {
                    audioSystem.playBackgroundMusic();
                } else {
                    audioSystem.stopBackgroundMusic();
                }
            }
        });
    }
    
    // Effects toggle - atualização em tempo real
    const effectsToggle = document.getElementById('effectsToggle');
    if (effectsToggle) {
        effectsToggle.addEventListener('change', function() {
            if (typeof audioSystem !== 'undefined') {
                audioSystem.effectsEnabled = this.checked;
                audioSystem.enabled = this.checked;
            }
        });
    }
    
    // Botão de salvar configurações
    const saveSettingsBtn = document.querySelector('button[onclick="saveSettingsFromUI()"]');
    if (saveSettingsBtn) {
        saveSettingsBtn.onclick = saveSettingsFromUI;
    }
    
    console.log('🎛️ Event listeners de configurações configurados');
}

// ===== SISTEMA DE CONFIGURAÇÃO DE JOGO =====
function startGameSetup(mode) {
    if (!currentUser) {
        showSection('login');
        showToast('🔒 Faça login para jogar.');
        return;
    }
    
    gameConfig.mode = mode;
    
    // Atualizar título e descrição
    const setupTitle = document.getElementById('setupTitle');
    const setupSubtitle = document.getElementById('setupSubtitle');
    const specialModesInfo = document.getElementById('specialModesInfo');
    const categoriesSection = document.querySelector('.setup-section');
    
    if (setupTitle) setupTitle.textContent = `🎯 Configurar ${getModeName(mode)}`;
    if (setupSubtitle) setupSubtitle.textContent = getModeDescription(mode);
    
    // Modos que não permitem seleção de categoria
    const specialModes = ['tabuada', 'puzzle'];
    const isSpecialMode = specialModes.includes(mode);
    
    if (specialModesInfo) {
        specialModesInfo.style.display = isSpecialMode ? 'block' : 'none';
    }
    
    if (categoriesSection) {
        categoriesSection.style.display = isSpecialMode ? 'none' : 'block';
    }
    
    if (isSpecialMode) {
        const specialModeDesc = document.getElementById('specialModeDesc');
        if (specialModeDesc) {
            specialModeDesc.textContent = getSpecialModeDescription(mode);
        }
        
        // Configurações automáticas para modos especiais
        if (mode === 'tabuada') {
            gameConfig.questionCount = 20;
            gameConfig.category = 'Matemática';
        } else if (mode === 'puzzle') {
            gameConfig.questionCount = 10;
            gameConfig.category = 'random';
        }
    } else {
        // Carregar categorias para modos normais
        loadCategories();
        gameConfig.questionCount = 10;
        gameConfig.category = 'random';
    }
    
    updateQuestionOptions();
    showSection('game-setup');
}

function loadCategories() {
    const availableCategories = getAvailableCategories();
    const categoriesGrid = document.getElementById('categoriesGrid');
    
    if (!categoriesGrid) return;
    
    categoriesGrid.innerHTML = '';
    
    // Adicionar opção "Aleatório"
    const randomCard = document.createElement('div');
    randomCard.className = 'category-card selected';
    randomCard.innerHTML = `
        <div class="category-icon">🎲</div>
        <div class="category-name">Aleatório</div>
    `;
    randomCard.onclick = () => selectCategory('random');
    categoriesGrid.appendChild(randomCard);
    
    // Adicionar categorias específicas
    availableCategories.forEach(category => {
        const card = document.createElement('div');
        card.className = 'category-card';
        card.innerHTML = `
            <div class="category-icon">${getCategoryIcon(category)}</div>
            <div class="category-name">${category}</div>
        `;
        card.onclick = () => selectCategory(category);
        categoriesGrid.appendChild(card);
    });
}

function selectCategory(category) {
    gameConfig.category = category;
    
    // Atualizar UI
    document.querySelectorAll('.category-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    event.currentTarget.classList.add('selected');
    showToast(`📚 Categoria: ${category === 'random' ? 'Aleatório' : category}`);
}

function selectQuestionCount(count) {
    gameConfig.questionCount = count;
    updateQuestionOptions();
    showToast(`🔢 ${count === 'all' ? 'Todas as perguntas' : count + ' perguntas'}`);
}

function useCustomCount() {
    const customCountInput = document.getElementById('customQuestionCount');
    if (!customCountInput) return;
    
    const customCount = parseInt(customCountInput.value);
    if (customCount && customCount >= 1 && customCount <= 50) {
        gameConfig.questionCount = customCount;
        updateQuestionOptions();
        showToast(`🔢 Definido para ${customCount} perguntas!`);
        customCountInput.value = '';
    } else {
        showToast('❌ Por favor, insira um número entre 1 e 50');
    }
}

function updateQuestionOptions() {
    document.querySelectorAll('.question-option').forEach(option => {
        option.classList.remove('active');
    });
    
    if (gameConfig.questionCount === 'all') {
        const allOption = document.querySelector('.question-option:nth-child(1)');
        if (allOption) allOption.classList.add('active');
    } else {
        const options = document.querySelectorAll('.question-option');
        for (let option of options) {
            const icon = option.querySelector('.option-icon');
            if (icon && parseInt(icon.textContent) === gameConfig.questionCount) {
                option.classList.add('active');
                break;
            }
        }
    }
}

function startConfiguredGame() {
    if (!gameConfig.category && !['tabuada', 'puzzle'].includes(gameConfig.mode)) {
        showToast('❌ Selecione uma categoria');
        return;
    }
    
    // Salvar configuração
    localStorage.setItem('currentGameConfig', JSON.stringify(gameConfig));
    
    // Redirecionar para o jogo apropriado
    if (gameConfig.mode === 'buzzer') {
        startBuzzerGame();
    } else if (gameConfig.mode === 'multiplayer') {
        startMultiplayerSetup();
    } else {
        startQuizGame();
    }
}

// ===== SISTEMA DE JOGO PRINCIPAL =====
function startQuizGame() {
    const config = JSON.parse(localStorage.getItem('currentGameConfig')) || gameConfig;
    
    // Buscar perguntas baseado na configuração
    let questions = [];
    
    if (config.category === 'random') {
        const allCategories = getAvailableCategories();
        questions = getRandomQuestions(
            config.questionCount === 'all' ? 20 : config.questionCount, 
            allCategories
        );
    } else {
        questions = getQuestionsByCategory(config.category);
        if (config.questionCount !== 'all') {
            questions = [...questions].sort(() => Math.random() - 0.5);
            questions = questions.slice(0, config.questionCount);
        }
    }
    
    if (questions.length === 0) {
        showToast('❌ Erro: Nenhuma pergunta encontrada.');
        return;
    }
    
    initializeGame(questions, config.mode);
    showSection('quiz');
}

function initializeGame(questions, mode) {
    gameState.mode = mode;
    gameState.score = 0;
    gameState.streak = 0;
    gameState.currentQuestion = 0;
    gameState.helpUsed = false;
    gameState.questions = questions;
    gameState.totalQuestions = questions.length;
    
    // Atualizar interface
    document.getElementById('quizMode').textContent = getModeName(mode);
    document.getElementById('quizCategory').textContent = gameConfig.category === 'random' ? 'Aleatório' : gameConfig.category;
    document.getElementById('quizScore').textContent = '0';
    document.getElementById('quizStreak').textContent = '0';
    document.getElementById('totalQuestions').textContent = gameState.totalQuestions;
    
    loadQuestion();
}

function loadQuestion() {
    if (gameState.currentQuestion >= gameState.questions.length) {
        endGame();
        return;
    }
    
    const question = gameState.questions[gameState.currentQuestion];
    
    // Modo Puzzle especial
    if (gameState.mode === 'puzzle') {
        loadPuzzleQuestion(question);
    } else {
        // Modo normal de múltipla escolha
        document.getElementById('quizQuestion').textContent = question.txt;
        document.getElementById('currentQuestion').textContent = gameState.currentQuestion + 1;
        
        const optionsContainer = document.getElementById('quizOptions');
        optionsContainer.innerHTML = '';
        
        question.opts.forEach((option, index) => {
            const optionEl = document.createElement('div');
            optionEl.className = 'quiz-option';
            optionEl.textContent = option;
            optionEl.onclick = () => selectAnswer(index);
            optionsContainer.appendChild(optionEl);
        });
    }
    
    startTimer();
}

function startTimer() {
    clearInterval(gameState.timer);
    
    const settings = getSettings();
    gameState.timeLeft = settings.game.timer ? 30 : 999; // Timer infinito se desativado
    document.getElementById('timeLeft').textContent = gameState.timeLeft;
    document.getElementById('quizTimer').style.width = '100%';
    
    if (settings.game.timer) {
        gameState.timer = setInterval(() => {
            gameState.timeLeft--;
            document.getElementById('timeLeft').textContent = gameState.timeLeft;
            document.getElementById('quizTimer').style.width = `${(gameState.timeLeft / 30) * 100}%`;
            
            if (gameState.timeLeft <= 0) {
                clearInterval(gameState.timer);
                handleTimeOut();
            }
        }, 1000);
    }
}

function selectAnswer(selectedIndex) {
    clearInterval(gameState.timer);
    
    const question = gameState.questions[gameState.currentQuestion];
    const options = document.querySelectorAll('.quiz-option');
    
    options.forEach((option, index) => {
        option.style.pointerEvents = 'none';
        if (index === question.correct) {
            option.classList.add('correct');
        } else if (index === selectedIndex) {
            option.classList.add('wrong');
        }
    });
    
    if (selectedIndex === question.correct) {
        // Tocar som de acerto
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(true);
        }
        
        gameState.score += 10;
        gameState.streak++;
        showToast('✅ Correto! +10 pontos');
    } else {
        // Tocar som de erro
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(false);
        }
        
        gameState.streak = 0;
        showToast(`❌ Errado! Resposta: ${question.opts[question.correct]}`);
    }
    
    document.getElementById('quizScore').textContent = gameState.score;
    document.getElementById('quizStreak').textContent = gameState.streak;
    
    setTimeout(() => {
        gameState.currentQuestion++;
        if (gameState.currentQuestion >= gameState.questions.length) {
            endGame();
        } else {
            loadQuestion();
        }
    }, 2000);
}

function handleTimeOut() {
    const question = gameState.questions[gameState.currentQuestion];
    const options = document.querySelectorAll('.quiz-option');
    
    options.forEach((option, index) => {
        option.style.pointerEvents = 'none';
        if (index === question.correct) {
            option.classList.add('correct');
        }
    });
    
    showToast('⏰ Tempo esgotado!');
    gameState.streak = 0;
    document.getElementById('quizStreak').textContent = gameState.streak;
    
    setTimeout(() => {
        gameState.currentQuestion++;
        if (gameState.currentQuestion >= gameState.questions.length) {
            endGame();
        } else {
            loadQuestion();
        }
    }, 2000);
}

function useHelp() {
    if (gameState.helpUsed) {
        showToast('❌ Ajuda já usada nesta pergunta.');
        return;
    }
    
    const question = gameState.questions[gameState.currentQuestion];
    const options = document.querySelectorAll('.quiz-option');
    const wrongOptions = [];
    
    options.forEach((option, index) => {
        if (index !== question.correct && !option.classList.contains('wrong')) {
            wrongOptions.push(option);
        }
    });
    
    if (wrongOptions.length > 0) {
        const randomOption = wrongOptions[Math.floor(Math.random() * wrongOptions.length)];
        randomOption.classList.add('wrong');
        randomOption.style.pointerEvents = 'none';
        gameState.helpUsed = true;
        showToast('💡 Uma opção errada foi eliminada!');
    }
}

function endGame() {
    clearInterval(gameState.timer);
    
    // Tocar som de fim de jogo
    if (typeof audioSystem !== 'undefined') {
        audioSystem.playGameEnd(gameState.score, gameState.totalQuestions);
    }
    
    // Atualizar estatísticas do usuário
    if (currentUser) {
        const users = getUsers();
        const userIndex = users.findIndex(u => u.id === currentUser.id);
        
        if (userIndex !== -1) {
            users[userIndex].points += gameState.score;
            users[userIndex].gamesPlayed++;
            
            // Atribuir medalhas baseado na pontuação
            const percentage = (gameState.score / (gameState.questions.length * 10)) * 100;
            if (percentage >= 90) {
                users[userIndex].medals.gold++;
                showToast('🥇 Medalha de Ouro conquistada!');
            } else if (percentage >= 70) {
                users[userIndex].medals.silver++;
                showToast('🥈 Medalha de Prata conquistada!');
            } else if (percentage >= 50) {
                users[userIndex].medals.bronze++;
                showToast('🥉 Medalha de Bronze conquistada!');
            }
            
            saveUsers(users);
            currentUser = users[userIndex];
        }
    }
    
    showToast(`🎮 Fim do jogo! Pontuação: ${gameState.score}`);
    
    // Confetes para boas pontuações
    if (gameState.score >= 70) {
        confettiBurst();
    }
    
    showSection('modes');
    updateProfile();
    updateTopBar();
}

// ===== SISTEMA MULTIPLAYER =====
function startMultiplayerSetup() {
    if (!currentUser) {
        showSection('login');
        showToast('🔒 Faça login para jogar.');
        return;
    }
    
    showSection('multiplayer-setup');
    setupMultiplayerPlayers();
}

function setupMultiplayerPlayers() {
    const playerCount = parseInt(document.getElementById('playerCount').value);
    const playersContainer = document.getElementById('playersSetup');
    
    if (!playersContainer) return;
    
    playersContainer.innerHTML = '';
    
    for (let i = 0; i < playerCount; i++) {
        const playerHtml = `
            <div class="player-setup-item">
                <div class="player-avatar">${getRandomAvatar()}</div>
                <input type="text" class="form-input" id="playerName${i}" 
                       placeholder="Nome do Jogador ${i + 1}" required
                       value="${i === 0 ? currentUser.name : ''}">
            </div>
        `;
        playersContainer.innerHTML += playerHtml;
    }
}

function selectPlayerCount(count) {
    document.getElementById('playerCount').value = count;
    
    // Atualizar UI dos botões
    document.querySelectorAll('.player-count-btn').forEach((btn, index) => {
        btn.classList.remove('active');
        if (parseInt(btn.textContent) === count) {
            btn.classList.add('active');
        }
    });
    
    setupMultiplayerPlayers();
}

function getRandomAvatar() {
    const avatars = ['👤', '🎮', '⭐', '🔥', '🚀', '🎯', '👑', '💎'];
    return avatars[Math.floor(Math.random() * avatars.length)];
}

// ===== SISTEMA BUZZER =====
function startBuzzerGame() {
    if (!currentUser) {
        showSection('login');
        showToast('🔒 Faça login para jogar.');
        return;
    }
    
    buzzerState.scores = {1: 0, 2: 0};
    buzzerState.active = true;
    
    document.getElementById('player1Score').textContent = '0';
    document.getElementById('player2Score').textContent = '0';
    document.getElementById('buzzerMessage').textContent = '';
    
    showSection('buzzer');
}

// ===== SISTEMA DE RANKING =====
function changeRankingFilter(filter) {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    event.target.classList.add('active');
    loadRanking(filter);
}

function loadRanking(filter = 'all') {
    const users = getUsers();
    let filteredUsers = [...users];
    
    // Aplicar filtros
    if (filter === 'male') {
        filteredUsers = users.filter(user => user.gender === 'male');
    } else if (filter === 'female') {
        filteredUsers = users.filter(user => user.gender === 'female');
    }
    
    // Ordenar por pontos
    filteredUsers.sort((a, b) => b.points - a.points);
    
    const rankingList = document.getElementById('rankingList');
    if (!rankingList) return;
    
    rankingList.innerHTML = '';
    
    filteredUsers.slice(0, 20).forEach((user, index) => {
        const item = document.createElement('div');
        item.className = 'ranking-item';
        
        item.innerHTML = `
            <div class="ranking-position">#${index + 1}</div>
            <div class="ranking-user">
                <div class="ranking-avatar">${user.avatar}</div>
                <div>
                    <div class="ranking-name">${user.name}</div>
                    <div style="color: var(--text-muted); font-size: 0.8em;">${user.email}</div>
                </div>
            </div>
            <div class="ranking-points">${user.points} pts</div>
        `;
        
        // Destacar usuário atual
        if (currentUser && user.id === currentUser.id) {
            item.style.background = 'var(--primary)';
            item.style.color = 'white';
        }
        
        rankingList.appendChild(item);
    });
}

// ===== SISTEMA DE CONFETES =====
function confettiBurst() {
    const canvas = document.getElementById('confetti');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const confettiPieces = [];
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
    
    // Criar confetes
    for (let i = 0; i < 150; i++) {
        confettiPieces.push({
            x: Math.random() * canvas.width,
            y: -Math.random() * canvas.height,
            size: Math.random() * 10 + 5,
            speed: Math.random() * 3 + 2,
            color: colors[Math.floor(Math.random() * colors.length)],
            rotation: Math.random() * 360,
            rotationSpeed: Math.random() * 10 - 5
        });
    }
    
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        let activePieces = 0;
        
        confettiPieces.forEach(confetti => {
            confetti.y += confetti.speed;
            confetti.x += Math.sin(confetti.y * 0.01) * 2;
            confetti.rotation += confetti.rotationSpeed;
            
            ctx.save();
            ctx.translate(confetti.x, confetti.y);
            ctx.rotate(confetti.rotation * Math.PI / 180);
            ctx.fillStyle = confetti.color;
            ctx.fillRect(-confetti.size/2, -confetti.size/2, confetti.size, confetti.size);
            ctx.restore();
            
            if (confetti.y < canvas.height) {
                activePieces++;
            }
        });
        
        if (activePieces > 0) {
            requestAnimationFrame(animate);
        }
    }
    
    animate();
}

// ===== FUNÇÕES AUXILIARES =====
function getRandomQuestions(count = 10, categories = []) {
    let allQuestions = [];
    
    // Se nenhuma categoria for especificada, usar todas
    if (categories.length === 0) {
        categories = getAvailableCategories();
    }
    
    // Coletar todas as perguntas das categorias selecionadas
    categories.forEach(category => {
        const categoryQuestions = getQuestionsByCategory(category);
        allQuestions = allQuestions.concat(categoryQuestions);
    });
    
    if (allQuestions.length === 0) {
        console.error('Nenhuma pergunta encontrada!');
        return [];
    }
    
    // Embaralhar e selecionar
    const shuffled = [...allQuestions].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, count);
}

function getQuestionsByCategory(category) {
    const lang = window.currentLanguage || 'pt';
    return QUESTIONS[lang]?.[category] || [];
}

function getAvailableCategories() {
    const lang = window.currentLanguage || 'pt';
    return Object.keys(QUESTIONS[lang] || {});
}

function getCategoryIcon(category) {
    const icons = {
        'Música': '🎵',
        'Matemática': '🔢',
        'História': '📜',
        'Geografia': '🌍',
        'Ciências': '🔬',
        'Português': '📝',
        'Jogos': '🎮',
        'Cultura Geral': '🌟',
        'Inglês': '🇬🇧'
    };
    return icons[category] || '❓';
}

function getModeName(mode) {
    const names = {
        'solo': 'Modo Solo',
        'multiplayer': 'Multiplayer',
        'buzzer': 'Modo Buzzer',
        'speed': 'SpeedQuiz',
        'puzzle': 'Modo Puzzle',
        'tabuada': 'Tabuada'
    };
    return names[mode] || mode;
}

function getModeDescription(mode) {
    const descriptions = {
        'solo': 'Teste seu conhecimento sozinho',
        'multiplayer': 'Desafie seus amigos',
        'buzzer': 'Competição de velocidade',
        'speed': 'Perguntas rápidas - 10 segundos cada',
        'puzzle': 'Monte respostas com letras embaralhadas',
        'tabuada': 'Desafio de multiplicação'
    };
    return descriptions[mode] || 'Modo personalizado';
}

function getSpecialModeDescription(mode) {
    const descriptions = {
        'tabuada': 'Desafio de matemática com 20 perguntas de multiplicação automáticas',
        'puzzle': 'Modo puzzle com 10 perguntas de montagem de palavras'
    };
    return descriptions[mode] || 'Modo com configurações automáticas';
}

// ===== INICIALIZAÇÃO DA APLICAÇÃO =====
function initializeApp() {
    console.log('🚀 Inicializando QUIZ-EDU...');
    
    // Carregar configurações
    loadSettingsToUI();
    setupSettingsEventListeners();
    
    // Carregar ranking
    loadRanking();
    
    // Verificar se há usuário logado anteriormente
    const lastUserEmail = localStorage.getItem('quizEduLastUser');
    if (lastUserEmail) {
        const users = getUsers();
        const lastUser = users.find(user => user.email === lastUserEmail);
        if (lastUser) {
            currentUser = lastUser;
            console.log('🔑 Sessão restaurada para:', lastUser.name);
            updateTopBar();
        }
    }
    
    // Inicializar notificações
    initializeNotifications();
    
    showSection('initial');
    
    // Mostrar mensagem de boas-vindas
    setTimeout(() => {
        showToast('🎮 QUIZ-EDU carregado com sucesso!');
    }, 1000);
    
    console.log('✅ Aplicação inicializada');
}

// ===== SISTEMA DE NOTIFICAÇÕES =====
function initializeNotifications() {
    const notificationCount = document.querySelector('.notification-count');
    if (!notificationCount) return;
    
    let notificationCountValue = 0;
    const notifications = [];
    
    if (currentUser) {
        // Notificação de boas-vindas para novos usuários
        if (currentUser.gamesPlayed === 0) {
            notificationCountValue++;
            notifications.push({
                icon: '🎉',
                text: 'Bem-vindo ao QUIZ-EDU! Comece seu primeiro jogo.',
                time: 'Agora',
                type: 'welcome'
            });
        }
        
        // Notificação baseada em pontos
        if (currentUser.points > 0) {
            notificationCountValue++;
            
            let pointsMessage = '';
            if (currentUser.points >= 1000) {
                pointsMessage = `🏆 Excelente! Você tem ${currentUser.points} pontos! Continue assim!`;
            } else if (currentUser.points >= 500) {
                pointsMessage = `⭐ Bom trabalho! ${currentUser.points} pontos conquistados!`;
            } else {
                pointsMessage = `📈 Você acumulou ${currentUser.points} pontos! Continue evoluindo.`;
            }
            
            notifications.push({
                icon: '⭐',
                text: pointsMessage,
                time: 'Recentemente',
                type: 'points'
            });
        }
        
        // Notificação de posição no ranking
        const users = getUsers();
        const sortedUsers = [...users].sort((a, b) => b.points - a.points);
        const position = sortedUsers.findIndex(user => user.id === currentUser.id) + 1;
        
        if (position <= 3 && position > 0) {
            notificationCountValue++;
            let rankMessage = '';
            
            if (position === 1) {
                rankMessage = '👑 PARABÉNS! Você é o #1 do ranking!';
            } else if (position === 2) {
                const top1Points = sortedUsers[0]?.points || 0;
                const pointsNeeded = top1Points - currentUser.points;
                rankMessage = `🥈 Incrível! Você está em 2º lugar! Faltam ${pointsNeeded} pontos para o topo!`;
            } else if (position === 3) {
                rankMessage = '🥉 Excelente! Você está no TOP 3! Continue assim!';
            }
            
            notifications.push({
                icon: '🏆',
                text: rankMessage,
                time: 'Agora',
                type: 'ranking'
            });
        }
        
        // Notificação especial para usuárias femininas
        if (currentUser.gender === 'female') {
            notificationCountValue++;
            notifications.push({
                icon: '🎬',
                text: '💖 Modo especial para você: Descubra Doramas coreanos!',
                time: 'Novo',
                type: 'special'
            });
        }
        
        // Notificação de conquista de jogos
        if (currentUser.gamesPlayed >= 30) {
            notificationCountValue++;
            notifications.push({
                icon: '🎯',
                text: `🎉 INCRÍVEL! Você já jogou ${currentUser.gamesPlayed} jogos!`,
                time: 'Conquista',
                type: 'milestone'
            });
        } else if (currentUser.gamesPlayed >= 10) {
            notificationCountValue++;
            notifications.push({
                icon: '⚡',
                text: `🔥 Você já completou ${currentUser.gamesPlayed} jogos! Continue a saga!`,
                time: 'Progresso',
                type: 'milestone'
            });
        }
    }
    
    // Notificações gerais do sistema
    notificationCountValue++;
    notifications.push({
        icon: '🆕',
        text: '✨ Novos modos de jogo em breve! Fique atento às atualizações.',
        time: 'Em breve',
        type: 'system'
    });
    
    // Notificação de média de pontos
    if (currentUser && currentUser.gamesPlayed > 0) {
        const averagePoints = Math.round(currentUser.points / currentUser.gamesPlayed);
        let performanceMessage = '';
        
        if (averagePoints >= 80) {
            performanceMessage = `📊 EXCELENTE! Sua média é ${averagePoints} pts/jogo!`;
        } else if (averagePoints >= 60) {
            performanceMessage = `📊 Boa performance! Média: ${averagePoints} pts/jogo`;
        } else {
            performanceMessage = `📊 Sua média é ${averagePoints} pts/jogo. Você pode melhorar!`;
        }
        
        notificationCountValue++;
        notifications.push({
            icon: '📈',
            text: performanceMessage,
            time: 'Estatística',
            type: 'performance'
        });
    }
    
    // Atualizar contador
    notificationCount.textContent = notificationCountValue > 9 ? '9+' : notificationCountValue;
    
    // Salvar notificações para mostrar no painel
    window.currentNotifications = notifications;
}

function showNotificationPanel() {
    const notifications = [];
    
    if (currentUser) {
        // Notificação de boas-vindas
        if (currentUser.gamesPlayed === 0) {
            notifications.push({
                icon: '🎉',
                text: 'Bem-vindo ao QUIZ-EDU! Comece seu primeiro jogo.',
                time: 'Agora',
                type: 'welcome'
            });
        }
        
        // Notificação de pontos
        if (currentUser.points > 0) {
            notifications.push({
                icon: '⭐',
                text: `Você acumulou ${currentUser.points} pontos! Continue assim.`,
                time: 'Recentemente',
                type: 'points'
            });
        }
    }
    
    // Notificações gerais do sistema
    notifications.push({
        icon: '🆕',
        text: 'Novos modos de jogo em breve! Fique atento.',
        time: 'Em breve',
        type: 'system'
    });
    
    let notificationsHTML = '<h3>🔔 Notificações</h3>';
    
    if (notifications.length === 0) {
        notificationsHTML += `
            <div class="no-notifications">
                <div class="no-notifications-icon">📭</div>
                <p>Nenhuma notificação no momento</p>
                <small>As notificações aparecerão aqui quando você tiver novas atividades</small>
            </div>
        `;
    } else {
        notificationsHTML += '<div class="notifications-list">';
        
        notifications.forEach((notification, index) => {
            notificationsHTML += `
                <div class="notification-item ${notification.type}">
                    <div class="notification-icon">${notification.icon}</div>
                    <div class="notification-content">
                        <div class="notification-text">${notification.text}</div>
                        <div class="notification-time">${notification.time}</div>
                    </div>
                </div>
            `;
        });
        
        notificationsHTML += '</div>';
    }
    
    // Criar modal de notificações
    const modal = document.createElement('div');
    modal.className = 'modal notifications-modal';
    modal.style.display = 'flex';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h2>🔔 Notificações</h2>
                <button class="close-btn" onclick="this.closest('.modal').remove()">&times;</button>
            </div>
            <div class="modal-body">
                ${notificationsHTML}
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="markAllAsRead()">Marcar todas como lidas</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Fechar modal clicando fora
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

function markAllAsRead() {
    const notificationCount = document.querySelector('.notification-count');
    if (notificationCount) {
        notificationCount.textContent = '0';
        showToast('✅ Todas as notificações marcadas como lidas');
    }
    
    // Fechar modal
    const modal = document.querySelector('.notifications-modal');
    if (modal) {
        modal.remove();
    }
}

// ===== SISTEMA DE ESTATÍSTICAS =====
function showStats() {
    if (!currentUser) {
        showToast('🔒 Faça login para ver estatísticas');
        return;
    }
    
    const users = getUsers();
    const sortedUsers = [...users].sort((a, b) => b.points - a.points);
    const userPosition = sortedUsers.findIndex(user => user.id === currentUser.id) + 1;
    const totalUsers = users.length;
    
    // Calcular estatísticas avançadas
    const totalPointsAll = users.reduce((sum, user) => sum + user.points, 0);
    const averagePoints = Math.round(totalPointsAll / totalUsers);
    const userLevel = Math.floor(currentUser.points / 1000) + 1;
    const pointsToNextLevel = (userLevel * 1000) - currentUser.points;
    
    const statsHTML = `
        <div class="stats-container">
            <div class="stats-header">
                <h3>📊 Estatísticas de ${currentUser.name}</h3>
                <div class="user-level">Nível ${userLevel}</div>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card-large">
                    <div class="stat-icon">📈</div>
                    <div class="stat-value">${currentUser.points}</div>
                    <div class="stat-label">Pontos Totais</div>
                    <div class="stat-progress">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${(currentUser.points % 1000) / 10}%"></div>
                        </div>
                        <small>${pointsToNextLevel} pts para o próximo nível</small>
                    </div>
                </div>
                
                <div class="stat-card-large">
                    <div class="stat-icon">🏆</div>
                    <div class="stat-value">#${userPosition}</div>
                    <div class="stat-label">Ranking Global</div>
                    <div class="stat-subtext">Entre ${totalUsers} jogadores</div>
                </div>
                
                <div class="stat-card-large">
                    <div class="stat-icon">🎮</div>
                    <div class="stat-value">${currentUser.gamesPlayed}</div>
                    <div class="stat-label">Jogos Realizados</div>
                    <div class="stat-subtext">Média: ${currentUser.gamesPlayed > 0 ? Math.round(currentUser.points / currentUser.gamesPlayed) : 0} pts/jogo</div>
                </div>
                
                <div class="stat-card-large">
                    <div class="stat-icon">⭐</div>
                    <div class="stat-value">${currentUser.medals.gold + currentUser.medals.silver + currentUser.medals.bronze}</div>
                    <div class="stat-label">Total de Medalhas</div>
                    <div class="stat-subtext">Conquistas</div>
                </div>
            </div>
            
            <div class="stats-sections">
                <div class="stats-section">
                    <h4>🏅 Medalhas Conquistadas</h4>
                    <div class="medals-display">
                        <div class="medal-item gold">
                            <span class="medal-icon">🥇</span>
                            <span class="medal-count">${currentUser.medals.gold}</span>
                            <span class="medal-label">Ouro</span>
                        </div>
                        <div class="medal-item silver">
                            <span class="medal-icon">🥈</span>
                            <span class="medal-count">${currentUser.medals.silver}</span>
                            <span class="medal-label">Prata</span>
                        </div>
                        <div class="medal-item bronze">
                            <span class="medal-icon">🥉</span>
                            <span class="medal-count">${currentUser.medals.bronze}</span>
                            <span class="medal-label">Bronze</span>
                        </div>
                    </div>
                </div>
                
                <div class="stats-section">
                    <h4>🌍 Comparação Global</h4>
                    <div class="comparison-stats">
                        <div class="comparison-item">
                            <span>Sua Pontuação:</span>
                            <span class="value">${currentUser.points} pts</span>
                        </div>
                        <div class="comparison-item">
                            <span>Média dos Jogadores:</span>
                            <span class="value">${averagePoints} pts</span>
                        </div>
                        <div class="comparison-item">
                            <span>Top 1 do Ranking:</span>
                            <span class="value">${sortedUsers[0]?.points || 0} pts</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="stats-actions">
                <button class="btn btn-secondary" onclick="showSection('ranking')">📋 Ver Ranking Completo</button>
                <button class="btn btn-primary" onclick="showSection('modes')">🎮 Continuar Jogando</button>
            </div>
        </div>
    `;
    
    // Criar modal de estatísticas
    const modal = document.createElement('div');
    modal.className = 'modal stats-modal';
    modal.style.display = 'flex';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h2>📊 Estatísticas Detalhadas</h2>
                <button class="close-btn" onclick="this.closest('.modal').remove()">&times;</button>
            </div>
            <div class="modal-body">
                ${statsHTML}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Fechar modal clicando fora
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

// ===== INICIALIZAÇÃO AUTOMÁTICA =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM carregado - Iniciando aplicação...');
    setTimeout(initializeApp, 500);
});

// ===== NOVOS MODOS DORAMAS E RELIGIÃO =====
function startDoramasMode() {
    if (!currentUser) {
        showSection('login');
        showToast('🔒 Faça login para jogar.');
        return;
    }
    
    gameConfig.mode = 'doramas';
    gameConfig.category = 'Doramas';
    gameConfig.questionCount = 20;
    
    localStorage.setItem('currentGameConfig', JSON.stringify(gameConfig));
    startQuizGame();
}

function startReligiousMode() {
    if (!currentUser) {
        showSection('login');
        showToast('🔒 Faça login para jogar.');
        return;
    }
    
    gameConfig.mode = 'religion';
    gameConfig.category = 'Religião';
    gameConfig.questionCount = 20;
    
    localStorage.setItem('currentGameConfig', JSON.stringify(gameConfig));
    startQuizGame();
}

// ===== SISTEMA DE PUZZLE CORRIGIDO =====
function loadPuzzleQuestion(question) {
    // Converter para modo de múltipla escolha normal como fallback
    document.getElementById('quizQuestion').innerHTML = `
        <div style="text-align: center;">
            <div>🧩 ${question.txt}</div>
            <div style="color: var(--text-muted); font-size: 0.9em; margin-top: 10px;">
                Modo Puzzle - Escolha a resposta correta
            </div>
        </div>
    `;
    
    const optionsContainer = document.getElementById('quizOptions');
    optionsContainer.innerHTML = '';
    
    question.opts.forEach((option, index) => {
        const optionEl = document.createElement('div');
        optionEl.className = 'quiz-option';
        optionEl.textContent = option;
        optionEl.onclick = () => selectAnswer(index);
        optionsContainer.appendChild(optionEl);
    });
}

// ===== SISTEMA DE TEMA CORRIGIDO =====
function changeTheme(theme) {
    const savedSettings = getSettings();
    savedSettings.appearance = savedSettings.appearance || {};
    savedSettings.appearance.theme = theme;
    saveSettings(savedSettings);
    
    document.documentElement.setAttribute('data-theme', theme);
    
    // Atualizar botões ativos
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.currentTarget.classList.add('active');
    
    showToast(`🎨 Tema ${theme === 'dark' ? 'Escuro' : theme === 'light' ? 'Claro' : 'Automático'} aplicado`);
}

// ===== BOTÃO DE AJUDA DURANTE O JOGO =====
function toggleHelpButton(show) {
    const helpBtn = document.querySelector('.help-floating-btn');
    if (helpBtn) {
        helpBtn.style.display = show ? 'flex' : 'none';
    }
}

// Modificar a função startQuizGame para esconder o botão
function startQuizGame() {
    const config = JSON.parse(localStorage.getItem('currentGameConfig')) || gameConfig;
    
    // Esconder botão de ajuda durante o jogo
    toggleHelpButton(false);
    
    // Resto do código existente...
    let questions = [];
    
    if (config.category === 'random') {
        const allCategories = getAvailableCategories();
        questions = getRandomQuestions(
            config.questionCount === 'all' ? 20 : config.questionCount, 
            allCategories
        );
    } else {
        questions = getQuestionsByCategory(config.category);
        if (config.questionCount !== 'all') {
            questions = [...questions].sort(() => Math.random() - 0.5);
            questions = questions.slice(0, config.questionCount);
        }
    }
    
    if (questions.length === 0) {
        showToast('❌ Erro: Nenhuma pergunta encontrada.');
        toggleHelpButton(true); // Mostrar botão novamente em caso de erro
        return;
    }
    
    initializeGame(questions, config.mode);
    showSection('quiz');
}

// Modificar a função endGame para mostrar o botão novamente
function endGame() {
    clearInterval(gameState.timer);
    
    // Mostrar botão de ajuda novamente
    toggleHelpButton(true);
    
    // Resto do código existente...
    if (typeof audioSystem !== 'undefined') {
        audioSystem.playGameEnd(gameState.score, gameState.totalQuestions);
    }
    
    // Atualizar estatísticas do usuário
    if (currentUser) {
        const users = getUsers();
        const userIndex = users.findIndex(u => u.id === currentUser.id);
        
        if (userIndex !== -1) {
            users[userIndex].points += gameState.score;
            users[userIndex].gamesPlayed++;
            
            const percentage = (gameState.score / (gameState.questions.length * 10)) * 100;
            if (percentage >= 90) {
                users[userIndex].medals.gold++;
                showToast('🥇 Medalha de Ouro conquistada!');
            } else if (percentage >= 70) {
                users[userIndex].medals.silver++;
                showToast('🥈 Medalha de Prata conquistada!');
            } else if (percentage >= 50) {
                users[userIndex].medals.bronze++;
                showToast('🥉 Medalha de Bronze conquistada!');
            }
            
            saveUsers(users);
            currentUser = users[userIndex];
        }
    }
    
    showToast(`🎮 Fim do jogo! Pontuação: ${gameState.score}`);
    
    if (gameState.score >= 70) {
        confettiBurst();
    }
    
    showSection('modes');
    updateProfile();
    updateTopBar();
}

// ===== SISTEMA DE EDIÇÃO DE PERFIL PARCIAL =====
function showEditProfile() {
    if (!currentUser) return;
    
    const editHTML = `
        <div class="form-container">
            <h2>✏️ Editar Perfil</h2>
            
            <div class="form-group">
                <label class="form-label">Nome</label>
                <input type="text" class="form-input" id="editName" value="${currentUser.name}">
            </div>
            
            <div class="form-group">
                <label class="form-label">Avatar</label>
                <div class="avatar-selector">
                    <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px;">
                        ${['👤', '🎮', '⭐', '🔥', '🚀', '🎯', '👑', '💎'].map(avatar => `
                            <div class="avatar-option ${currentUser.avatar === avatar ? 'selected' : ''}" 
                                 onclick="selectAvatar('${avatar}')" style="font-size: 2em; cursor: pointer; padding: 5px; border: 2px solid ${currentUser.avatar === avatar ? 'var(--primary)' : 'transparent'}; border-radius: 8px;">
                                ${avatar}
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-primary" onclick="saveProfileChanges()">Salvar Alterações</button>
                <button class="btn btn-secondary" onclick="this.closest('.modal').remove()">Cancelar</button>
            </div>
        </div>
    `;
    
    createInfoModal('✏️ Editar Perfil', editHTML);
}

function selectAvatar(avatar) {
    document.querySelectorAll('.avatar-option').forEach(option => {
        option.style.borderColor = 'transparent';
    });
    event.currentTarget.style.borderColor = 'var(--primary)';
    currentUser.tempAvatar = avatar;
}

function saveProfileChanges() {
    const newName = document.getElementById('editName').value.trim();
    
    if (!newName) {
        showToast('❌ O nome não pode estar vazio');
        return;
    }
    
    const users = getUsers();
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    
    if (userIndex !== -1) {
        users[userIndex].name = newName;
        if (currentUser.tempAvatar) {
            users[userIndex].avatar = currentUser.tempAvatar;
        }
        
        saveUsers(users);
        currentUser = users[userIndex];
        
        updateProfile();
        updateTopBar();
        showToast('✅ Perfil atualizado com sucesso!');
        
        // Fechar modal
        const modal = document.querySelector('.modal');
        if (modal) modal.remove();
    }
}

// ===== INICIALIZAÇÃO DO TEMA =====
function initializeTheme() {
    const settings = getSettings();
    const theme = settings.appearance?.theme || 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    
    // Atualizar botões ativos
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.textContent.includes(theme === 'dark' ? 'Dark' : theme === 'light' ? 'Light' : 'Auto')) {
            btn.classList.add('active');
        }
    });
}
// ===== SISTEMA PUZZLE REAL =====
function loadPuzzleQuestion(question) {
    // Esconder opções normais
    document.getElementById('quizOptions').innerHTML = '';
    
    // Mostrar pergunta
    document.getElementById('quizQuestion').innerHTML = `
        <div style="text-align: center;">
            <div style="font-size: 1.2em; margin-bottom: 20px;">🧩 ${question.txt}</div>
            <div style="color: var(--text-muted); margin-bottom: 15px;">
                Monte a resposta com as letras abaixo:
            </div>
            <div id="puzzleAnswer" style="
                font-size: 1.5em; 
                font-weight: bold; 
                letter-spacing: 5px;
                margin: 20px 0;
                min-height: 50px;
                display: flex;
                justify-content: center;
                align-items: center;
                background: var(--bg-dark);
                border: 2px dashed var(--border);
                border-radius: 10px;
                padding: 15px;
            "></div>
            <div id="puzzleLetters" style="
                display: flex;
                justify-content: center;
                flex-wrap: wrap;
                gap: 8px;
                margin: 20px 0;
                min-height: 60px;
            "></div>
            <div style="display: flex; gap: 10px; justify-content: center;">
                <button class="btn btn-secondary" onclick="clearPuzzleAnswer()">🗑️ Limpar</button>
                <button class="btn btn-primary" onclick="submitPuzzleAnswer()">✅ Verificar</button>
            </div>
        </div>
    `;
    
    // Configurar o puzzle
    setupPuzzle(question);
}

function setupPuzzle(question) {
    const correctAnswer = question.opts[question.correct];
    
    // Embaralhar as letras da resposta correta
    const shuffledLetters = shuffleString(correctAnswer);
    
    // Mostrar letras embaralhadas
    const lettersContainer = document.getElementById('puzzleLetters');
    lettersContainer.innerHTML = '';
    
    shuffledLetters.split('').forEach((letter, index) => {
        if (letter !== ' ') { // Ignorar espaços
            const letterElement = document.createElement('div');
            letterElement.className = 'puzzle-letter';
            letterElement.textContent = letter;
            letterElement.style.cssText = `
                padding: 10px 15px;
                background: var(--primary);
                color: white;
                border-radius: 8px;
                cursor: pointer;
                font-weight: bold;
                font-size: 1.2em;
                min-width: 40px;
                text-align: center;
                user-select: none;
                transition: all 0.2s ease;
            `;
            letterElement.onclick = () => addLetterToAnswer(letter, letterElement);
            letterElement.onmouseover = function() { this.style.transform = 'scale(1.1)'; };
            letterElement.onmouseout = function() { this.style.transform = 'scale(1)'; };
            lettersContainer.appendChild(letterElement);
        }
    });
    
    // Salvar resposta correta para verificação
    gameState.currentPuzzle = {
        correctAnswer: correctAnswer.toUpperCase(),
        userAnswer: '',
        question: question
    };
}

function shuffleString(str) {
    const array = str.toUpperCase().split('').filter(char => char !== ' ');
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array.join('');
}

function addLetterToAnswer(letter, element) {
    if (gameState.currentPuzzle) {
        gameState.currentPuzzle.userAnswer += letter;
        updatePuzzleDisplay();
        element.style.background = 'var(--text-muted)';
        element.style.cursor = 'default';
        element.onclick = null;
    }
}

function updatePuzzleDisplay() {
    const answerDisplay = document.getElementById('puzzleAnswer');
    if (gameState.currentPuzzle) {
        answerDisplay.textContent = gameState.currentPuzzle.userAnswer;
        answerDisplay.style.borderColor = 'var(--primary)';
    }
}

function clearPuzzleAnswer() {
    if (gameState.currentPuzzle) {
        gameState.currentPuzzle.userAnswer = '';
        updatePuzzleDisplay();
        
        // Reativar todas as letras
        const letters = document.querySelectorAll('.puzzle-letter');
        letters.forEach(letter => {
            letter.style.background = 'var(--primary)';
            letter.style.cursor = 'pointer';
            letter.onclick = () => addLetterToAnswer(letter.textContent, letter);
        });
    }
}

function submitPuzzleAnswer() {
    if (!gameState.currentPuzzle) return;
    
    const userAnswer = gameState.currentPuzzle.userAnswer.toUpperCase().replace(/\s/g, '');
    const correctAnswer = gameState.currentPuzzle.correctAnswer.toUpperCase().replace(/\s/g, '');
    
    const answerDisplay = document.getElementById('puzzleAnswer');
    
    if (userAnswer === correctAnswer) {
        // Resposta correta
        answerDisplay.style.background = 'var(--success)';
        answerDisplay.style.color = 'white';
        answerDisplay.style.borderColor = 'var(--success)';
        
        // Tocar som de acerto
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(true);
        }
        
        gameState.score += 15; // Bônus extra no puzzle
        gameState.streak++;
        showToast('✅ Correto! +15 pontos (bônus puzzle)');
        
        document.getElementById('quizScore').textContent = gameState.score;
        document.getElementById('quizStreak').textContent = gameState.streak;
        
        setTimeout(() => {
            gameState.currentQuestion++;
            if (gameState.currentQuestion >= gameState.questions.length) {
                endGame();
            } else {
                loadQuestion();
            }
        }, 2000);
        
    } else {
        // Resposta incorreta
        answerDisplay.style.background = 'var(--danger)';
        answerDisplay.style.color = 'white';
        answerDisplay.style.borderColor = 'var(--danger)';
        
        // Mostrar resposta correta
        setTimeout(() => {
            answerDisplay.innerHTML = `
                <div style="text-align: center;">
                    <div style="color: white; text-decoration: line-through;">${userAnswer}</div>
                    <div style="color: var(--success); margin-top: 5px;">${correctAnswer}</div>
                </div>
            `;
        }, 1000);
        
        // Tocar som de erro
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(false);
        }
        
        gameState.streak = 0;
        showToast(`❌ Resposta correta: ${correctAnswer}`);
        document.getElementById('quizStreak').textContent = gameState.streak;
        
        setTimeout(() => {
            gameState.currentQuestion++;
            if (gameState.currentQuestion >= gameState.questions.length) {
                endGame();
            } else {
                loadQuestion();
            }
        }, 3000);
    }
}
// Adicione estas funções ao script.js:

// ===== SISTEMA DE PRONÚNCIA NO JOGO =====
function setupPronunciationForQuestion(question) {
    if (!question.hasAudio && !question.pronunciation) return;
    
    const questionElement = document.getElementById('quizQuestion');
    const originalText = questionElement.innerHTML;
    
    let audioButtons = '';
    
    // Botão para pronúncia da pergunta
    if (question.pronunciation) {
        audioButtons += `
            <button class="pronunciation-btn" onclick="playPronunciation('${question.pronunciation}')" 
                    title="Ouvir pronúncia" style="
                background: var(--primary);
                border: none;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                color: white;
                font-size: 1.2em;
                cursor: pointer;
                margin-left: 10px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
            ">
                🔊
            </button>
        `;
    }
    
    questionElement.innerHTML = originalText + audioButtons;
    
    // Adicionar botões de áudio às opções se necessário
    if (question.hasAudio) {
        setTimeout(() => {
            addAudioToOptions(question);
        }, 100);
    }
}

function addAudioToOptions(question) {
    const options = document.querySelectorAll('.quiz-option');
    
    options.forEach((option, index) => {
        const optionText = question.opts[index];
        
        if (isEnglishText(optionText)) {
            const audioBtn = document.createElement('button');
            audioBtn.className = 'option-audio-btn';
            audioBtn.innerHTML = '🔊';
            audioBtn.title = 'Ouvir pronúncia';
            audioBtn.style.cssText = `
                background: var(--secondary);
                border: none;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                color: white;
                font-size: 0.9em;
                cursor: pointer;
                margin-left: 10px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
            `;
            
            audioBtn.onclick = (e) => {
                e.stopPropagation();
                playPronunciation(optionText);
            };
            
            audioBtn.onmouseover = function() { 
                this.style.transform = 'scale(1.1)'; 
                this.style.background = 'var(--primary)';
            };
            audioBtn.onmouseout = function() { 
                this.style.transform = 'scale(1)'; 
                this.style.background = 'var(--secondary)';
            };
            
            option.style.display = 'flex';
            option.style.alignItems = 'center';
            option.style.justifyContent = 'space-between';
            option.appendChild(audioBtn);
        }
    });
}

function playPronunciation(text) {
    if (typeof SpeechSystem !== 'undefined' && SpeechSystem.speak) {
        const success = SpeechSystem.speakWord(text);
        if (!success) {
            showToast('🔇 Sistema de voz não disponível');
        }
    } else {
        showToast('🔇 Recuso de pronúncia não carregado');
    }
}

// Modifique a função loadQuestion para incluir pronúncia:
function loadQuestion() {
    if (gameState.currentQuestion >= gameState.questions.length) {
        endGame();
        return;
    }
    
    const question = gameState.questions[gameState.currentQuestion];
    
    // Modo Puzzle especial
    if (gameState.mode === 'puzzle') {
        loadPuzzleQuestion(question);
    } else {
        // Modo normal de múltipla escolha
        document.getElementById('quizQuestion').textContent = question.txt;
        document.getElementById('currentQuestion').textContent = gameState.currentQuestion + 1;
        
        const optionsContainer = document.getElementById('quizOptions');
        optionsContainer.innerHTML = '';
        
        question.opts.forEach((option, index) => {
            const optionEl = document.createElement('div');
            optionEl.className = 'quiz-option';
            optionEl.textContent = option;
            optionEl.onclick = () => selectAnswer(index);
            optionsContainer.appendChild(optionEl);
        });
        
        // ADICIONE ESTA LINHA: Configurar pronúncia para perguntas de inglês
        if (gameConfig.category === 'Inglês') {
            setupPronunciationForQuestion(question);
        }
    }
    
    startTimer();
}
// ===== SISTEMA MULTIPLAYER COMPLETO =====
let multiplayerState = {
    players: [],
    currentPlayerIndex: 0,
    currentQuestion: 0,
    questions: [],
    scores: {},
    gameActive: false
};

function startMultiplayerSetup() {
    if (!currentUser) {
        showSection('login');
        showToast('🔒 Faça login para jogar.');
        return;
    }
    
    showSection('multiplayer-setup');
    setupMultiplayerPlayers();
}

function setupMultiplayerPlayers() {
    const playerCount = parseInt(document.getElementById('playerCount').value);
    const playersContainer = document.getElementById('playersSetup');
    
    if (!playersContainer) return;
    
    playersContainer.innerHTML = '';
    
    for (let i = 0; i < playerCount; i++) {
        const playerHtml = `
            <div class="player-setup-item">
                <div class="player-avatar">${getRandomAvatar()}</div>
                <input type="text" class="form-input" id="playerName${i}" 
                       placeholder="Nome do Jogador ${i + 1}" required
                       value="${i === 0 ? currentUser.name : `Jogador ${i + 1}`}">
            </div>
        `;
        playersContainer.innerHTML += playerHtml;
    }
}

function selectPlayerCount(count) {
    document.getElementById('playerCount').value = count;
    
    // Atualizar UI dos botões
    document.querySelectorAll('.player-count-btn').forEach((btn, index) => {
        btn.classList.remove('active');
        if (parseInt(btn.textContent) === count) {
            btn.classList.add('active');
        }
    });
    
    setupMultiplayerPlayers();
}

function startMultiplayerGame() {
    const playerCount = parseInt(document.getElementById('playerCount').value);
    const players = [];
    
    // Coletar nomes dos jogadores
    for (let i = 0; i < playerCount; i++) {
        const nameInput = document.getElementById(`playerName${i}`);
        if (!nameInput || !nameInput.value.trim()) {
            showToast(`❌ Digite o nome do Jogador ${i + 1}`);
            return;
        }
        players.push({
            id: i + 1,
            name: nameInput.value.trim(),
            avatar: getRandomAvatar(),
            score: 0
        });
    }
    
    // Inicializar estado do multiplayer
    multiplayerState = {
        players: players,
        currentPlayerIndex: 0,
        currentQuestion: 0,
        questions: getRandomQuestions(10), // 10 perguntas
        scores: {},
        gameActive: true
    };
    
    // Inicializar scores
    players.forEach(player => {
        multiplayerState.scores[player.id] = 0;
    });
    
    showMultiplayerGame();
}

function showMultiplayerGame() {
    showSection('multiplayer-local');
    updateMultiplayerUI();
    loadMultiplayerQuestion();
}

function updateMultiplayerUI() {
    const playersGrid = document.getElementById('multiplayerPlayersGrid');
    if (!playersGrid) return;
    
    playersGrid.innerHTML = '';
    
    multiplayerState.players.forEach(player => {
        const isCurrent = player.id === multiplayerState.players[multiplayerState.currentPlayerIndex].id;
        
        const playerHTML = `
            <div class="player-info ${isCurrent ? 'player-current' : ''}" 
                 onclick="selectPlayer(${player.id})"
                 style="cursor: pointer;">
                <div class="player-avatar">${player.avatar}</div>
                <div class="player-name">${player.name}</div>
                <div class="player-score">${multiplayerState.scores[player.id] || 0}</div>
                ${isCurrent ? '<div class="current-turn">Sua vez! 🎯</div>' : ''}
            </div>
        `;
        playersGrid.innerHTML += playerHTML;
    });
    
    // Atualizar indicador de jogador atual
    const currentPlayerIndicator = document.getElementById('currentPlayer');
    if (currentPlayerIndicator) {
        const currentPlayer = multiplayerState.players[multiplayerState.currentPlayerIndex];
        currentPlayerIndicator.textContent = `Vez de: ${currentPlayer.name} ${currentPlayer.avatar}`;
    }
}

function selectPlayer(playerId) {
    // No multiplayer local, qualquer jogador pode responder
    // Mas só marca pontos para o jogador atual
    const clickedPlayerIndex = multiplayerState.players.findIndex(p => p.id === playerId);
    if (clickedPlayerIndex !== -1) {
        multiplayerState.currentPlayerIndex = clickedPlayerIndex;
        updateMultiplayerUI();
        showToast(`🎮 ${multiplayerState.players[clickedPlayerIndex].name} está respondendo!`);
    }
}

function loadMultiplayerQuestion() {
    if (multiplayerState.currentQuestion >= multiplayerState.questions.length) {
        endMultiplayerGame();
        return;
    }
    
    const question = multiplayerState.questions[multiplayerState.currentQuestion];
    const questionNumber = document.getElementById('multiplayerQuestionNumber');
    const questionElement = document.getElementById('multiplayerQuestion');
    const optionsContainer = document.getElementById('multiplayerOptions');
    
    if (questionNumber) {
        questionNumber.textContent = `Pergunta ${multiplayerState.currentQuestion + 1} de ${multiplayerState.questions.length}`;
    }
    
    if (questionElement) {
        questionElement.textContent = question.txt;
    }
    
    if (optionsContainer) {
        optionsContainer.innerHTML = '';
        
        question.opts.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'multiplayer-option';
            optionElement.textContent = option;
            optionElement.onclick = () => selectMultiplayerAnswer(index, question);
            optionsContainer.appendChild(optionElement);
        });
    }
    
    startMultiplayerTimer();
}

function startMultiplayerTimer() {
    clearInterval(multiplayerState.timer);
    
    const settings = getSettings();
    multiplayerState.timeLeft = settings.game.timer ? 30 : 999;
    
    const timeElement = document.getElementById('multiplayerTimeLeft');
    const timerBar = document.getElementById('multiplayerTimer');
    
    if (timeElement) timeElement.textContent = multiplayerState.timeLeft;
    if (timerBar) timerBar.style.width = '100%';
    
    if (settings.game.timer) {
        multiplayerState.timer = setInterval(() => {
            multiplayerState.timeLeft--;
            
            if (timeElement) timeElement.textContent = multiplayerState.timeLeft;
            if (timerBar) {
                timerBar.style.width = `${(multiplayerState.timeLeft / 30) * 100}%`;
                
                // Efeitos visuais
                if (multiplayerState.timeLeft <= 10) {
                    timerBar.style.background = 'var(--danger)';
                } else if (multiplayerState.timeLeft <= 15) {
                    timerBar.style.background = 'var(--warning)';
                }
            }
            
            if (multiplayerState.timeLeft <= 0) {
                clearInterval(multiplayerState.timer);
                handleMultiplayerTimeOut();
            }
        }, 1000);
    }
}

function selectMultiplayerAnswer(selectedIndex, question) {
    clearInterval(multiplayerState.timer);
    
    const currentPlayer = multiplayerState.players[multiplayerState.currentPlayerIndex];
    const options = document.querySelectorAll('.multiplayer-option');
    
    // Aplicar efeitos visuais
    options.forEach((option, index) => {
        option.style.pointerEvents = 'none';
        if (index === question.correct) {
            option.classList.add('correct');
        } else if (index === selectedIndex) {
            option.classList.add('wrong');
        }
    });
    
    if (selectedIndex === question.correct) {
        // Resposta correta
        multiplayerState.scores[currentPlayer.id] += 10;
        
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(true);
        }
        
        showToast(`✅ ${currentPlayer.name} acertou! +10 pontos`);
    } else {
        // Resposta errada
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(false);
        }
        
        showToast(`❌ ${currentPlayer.name} errou! Resposta: ${question.opts[question.correct]}`);
    }
    
    // Atualizar UI
    updateMultiplayerUI();
    
    // Próxima rodada
    setTimeout(() => {
        multiplayerState.currentQuestion++;
        multiplayerState.currentPlayerIndex = (multiplayerState.currentPlayerIndex + 1) % multiplayerState.players.length;
        
        if (multiplayerState.currentQuestion < multiplayerState.questions.length) {
            loadMultiplayerQuestion();
        } else {
            endMultiplayerGame();
        }
    }, 2000);
}

function handleMultiplayerTimeOut() {
    const currentPlayer = multiplayerState.players[multiplayerState.currentPlayerIndex];
    
    const options = document.querySelectorAll('.multiplayer-option');
    options.forEach((option, index) => {
        option.style.pointerEvents = 'none';
        if (index === multiplayerState.questions[multiplayerState.currentQuestion].correct) {
            option.classList.add('correct');
        }
    });
    
    showToast(`⏰ Tempo esgotado para ${currentPlayer.name}!`);
    
    setTimeout(() => {
        multiplayerState.currentQuestion++;
        multiplayerState.currentPlayerIndex = (multiplayerState.currentPlayerIndex + 1) % multiplayerState.players.length;
        
        if (multiplayerState.currentQuestion < multiplayerState.questions.length) {
            loadMultiplayerQuestion();
        } else {
            endMultiplayerGame();
        }
    }, 2000);
}

function endMultiplayerGame() {
    clearInterval(multiplayerState.timer);
    multiplayerState.gameActive = false;
    
    showMultiplayerResults();
}

function showMultiplayerResults() {
    // Ordenar jogadores por pontuação
    const rankedPlayers = [...multiplayerState.players].sort((a, b) => {
        return multiplayerState.scores[b.id] - multiplayerState.scores[a.id];
    });
    
    let resultsHTML = '<h3 style="text-align: center; margin-bottom: 20px;">🏆 Resultado Final</h3>';
    
    rankedPlayers.forEach((player, index) => {
        const score = multiplayerState.scores[player.id] || 0;
        const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '📊';
        
        resultsHTML += `
            <div class="result-item" style="
                display: flex; 
                align-items: center; 
                justify-content: space-between;
                padding: 15px;
                background: ${index === 0 ? 'var(--primary)' : 'var(--bg-dark)'};
                color: ${index === 0 ? 'white' : 'var(--text)'};
                border-radius: 10px;
                margin-bottom: 10px;
                border-left: 4px solid ${index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? '#cd7f32' : 'var(--border)'};
            ">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="font-size: 1.5em;">${medal}</div>
                    <div style="font-size: 1.2em;">${player.avatar}</div>
                    <div>
                        <div style="font-weight: bold;">${player.name}</div>
                        <div style="font-size: 0.9em; opacity: 0.8;">${score} pontos</div>
                    </div>
                </div>
                <div style="font-size: 1.3em; font-weight: bold;">
                    #${index + 1}
                </div>
            </div>
        `;
    });
    
    resultsHTML += `
        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button class="btn btn-primary" onclick="showSection('modes')" style="flex: 1;">
                🏠 Menu Principal
            </button>
            <button class="btn btn-secondary" onclick="startMultiplayerGame()" style="flex: 1;">
                🔄 Jogar Novamente
            </button>
        </div>
    `;
    
    // Substituir a tela do jogo pelos resultados
    const gameContainer = document.querySelector('.multiplayer-container');
    if (gameContainer) {
        gameContainer.innerHTML = `
            <div style="padding: 30px; text-align: center;">
                ${resultsHTML}
            </div>
        `;
    }
}

// ===== SISTEMA DE RESET E LIMPEZA DO MULTIPLAYER =====
function resetMultiplayerState() {
    console.log('🔄 Resetando estado multiplayer...');
    
    multiplayerState = {
        players: [],
        currentPlayerIndex: 0,
        currentQuestion: 0,
        questions: [],
        scores: {},
        gameActive: false,
        timer: null
    };
    
    // Limpar event listeners
    if (multiplayerState.timer) {
        clearInterval(multiplayerState.timer);
        multiplayerState.timer = null;
    }
}

function cleanupMultiplayerUI() {
    console.log('🧹 Limpando UI multiplayer...');
    
    // Resetar elementos da UI
    const elementsToReset = [
        'multiplayerPlayersGrid',
        'multiplayerQuestion', 
        'multiplayerOptions',
        'multiplayerTimer',
        'multiplayerTimeLeft',
        'multiplayerQuestionNumber',
        'currentPlayer'
    ];
    
    elementsToReset.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = '';
            element.textContent = '';
            element.style.width = '100%';
        }
    });
}

function startBuzzerRound() {
    if (!buzzerState.active) {
        buzzerState.active = true;
    }
    
    buzzerState.questionActive = true;
    buzzerState.currentPlayer = null;
    
    // Buscar pergunta aleatória
    const questions = getRandomQuestions(1, ['Música', 'História', 'Geografia', 'Ciências']);
    if (questions.length === 0) {
        showToast('❌ Nenhuma pergunta disponível');
        return;
    }
    
    const question = questions[0];
    
    // Atualizar UI
    document.getElementById('buzzerQuestion').textContent = question.txt;
    document.getElementById('startBuzzerBtn').style.display = 'none';
    
    const optionsContainer = document.getElementById('buzzerOptions');
    optionsContainer.innerHTML = '';
    optionsContainer.style.display = 'grid';
    
    // Adicionar opções
    question.opts.forEach((option, index) => {
        const optionEl = document.createElement('div');
        optionEl.className = 'quiz-option';
        optionEl.textContent = option;
        optionEl.onclick = () => selectBuzzerAnswer(index, question);
        optionsContainer.appendChild(optionEl);
    });
    
    // Iniciar timer
    startBuzzerTimer();
}

function buzz(playerNumber) {
    if (!buzzerState.questionActive || buzzerState.currentPlayer) return;
    
    buzzerState.currentPlayer = playerNumber;
    document.getElementById('buzzerMessage').textContent = `🎯 Jogador ${playerNumber} buzinou primeiro!`;
    document.getElementById('buzzerMessage').style.color = 'var(--primary)';
    
    // Efeito visual
    const playerBtn = document.querySelector(`.buzzer-btn.player${playerNumber}`);
    playerBtn.style.background = 'var(--success)';
    playerBtn.style.transform = 'scale(1.1)';
    
    // Tocar som se disponível
    if (typeof audioSystem !== 'undefined') {
        audioSystem.playSound('buzz');
    }
}

function selectBuzzerAnswer(selectedIndex, question) {
    if (!buzzerState.currentPlayer) return;
    
    clearInterval(buzzerState.buzzerTimer);
    
    const player = buzzerState.currentPlayer;
    const options = document.querySelectorAll('#buzzerOptions .quiz-option');
    
    // Aplicar efeitos visuais
    options.forEach((option, index) => {
        option.style.pointerEvents = 'none';
        if (index === question.correct) {
            option.classList.add('correct');
        } else if (index === selectedIndex) {
            option.classList.add('wrong');
        }
    });
    
    if (selectedIndex === question.correct) {
        // Resposta correta
        buzzerState.scores[player] += 10;
        document.getElementById('buzzerMessage').textContent = `✅ Jogador ${player} acertou! +10 pontos`;
        document.getElementById('buzzerMessage').style.color = 'var(--success)';
        
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(true);
        }
    } else {
        // Resposta errada
        buzzerState.scores[player] = Math.max(0, buzzerState.scores[player] - 5);
        document.getElementById('buzzerMessage').textContent = `❌ Jogador ${player} errou! -5 pontos`;
        document.getElementById('buzzerMessage').style.color = 'var(--danger)';
        
        if (typeof audioSystem !== 'undefined') {
            audioSystem.playAnswerSound(false);
        }
    }
    
    // Atualizar pontuação
    document.getElementById(`player${player}Score`).textContent = buzzerState.scores[player];
    
    // Próxima rodada
    setTimeout(() => {
        resetBuzzerRound();
    }, 2000);
}

function resetBuzzerRound() {
    buzzerState.questionActive = false;
    buzzerState.currentPlayer = null;
    
    document.getElementById('buzzerOptions').style.display = 'none';
    document.getElementById('startBuzzerBtn').style.display = 'block';
    document.getElementById('buzzerMessage').textContent = '';
    
    // Resetar botões
    document.querySelectorAll('.buzzer-btn').forEach(btn => {
        btn.style.background = '';
        btn.style.transform = '';
    });
}

function startBuzzerTimer() {
    clearInterval(buzzerState.buzzerTimer);
    buzzerState.timeLeft = 15;
    
    document.getElementById('buzzerTimeLeft').textContent = buzzerState.timeLeft;
    document.getElementById('buzzerTimer').style.width = '100%';
    
    buzzerState.buzzerTimer = setInterval(() => {
        buzzerState.timeLeft--;
        document.getElementById('buzzerTimeLeft').textContent = buzzerState.timeLeft;
        document.getElementById('buzzerTimer').style.width = `${(buzzerState.timeLeft / 15) * 100}%`;
        
        if (buzzerState.timeLeft <= 0) {
            clearInterval(buzzerState.buzzerTimer);
            handleBuzzerTimeOut();
        }
    }, 1000);
}

function handleBuzzerTimeOut() {
    if (!buzzerState.currentPlayer) {
        document.getElementById('buzzerMessage').textContent = '⏰ Tempo esgotado! Ninguém respondeu.';
        document.getElementById('buzzerMessage').style.color = 'var(--warning)';
    }
    
    setTimeout(() => {
        resetBuzzerRound();
    }, 2000);
}

function endBuzzerGame() {
    clearInterval(buzzerState.buzzerTimer);
    buzzerState.active = false;
    
    // Determinar vencedor
    let winner = null;
    if (buzzerState.scores[1] > buzzerState.scores[2]) {
        winner = 1;
    } else if (buzzerState.scores[2] > buzzerState.scores[1]) {
        winner = 2;
    }
    
    if (winner) {
        showToast(`🏆 Jogador ${winner} venceu com ${buzzerState.scores[winner]} pontos!`);
    } else {
        showToast('🤝 Empate!');
    }
    
    showSection('modes');
}