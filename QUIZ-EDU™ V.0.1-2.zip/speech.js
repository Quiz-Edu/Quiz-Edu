// ===== SISTEMA DE PRONÚNCIA COM VOZ =====
const SpeechSystem = {
    enabled: true,
    voices: [],
    currentVoice: null,
    speechSynthesis: window.speechSynthesis,
    
    // Inicializar o sistema de voz
    init: function() {
        console.log('🎤 Inicializando sistema de pronúncia...');
        
        // Carregar vozes disponíveis
        this.loadVoices();
        
        // Alguns navegadores carregam vozes depois
        this.speechSynthesis.onvoiceschanged = () => {
            this.loadVoices();
            console.log('🎤 Vozes carregadas:', this.voices.length);
        };
        
        return this.enabled;
    },
    
    // Carregar vozes disponíveis
    loadVoices: function() {
        this.voices = this.speechSynthesis.getVoices();
        
        // Tentar encontrar uma voz em inglês
        this.currentVoice = this.voices.find(voice => 
            voice.lang.startsWith('en') || 
            voice.lang.includes('US') || 
            voice.lang.includes('GB')
        ) || this.voices[0]; // Fallback para primeira voz
        
        console.log('🎤 Voz selecionada:', this.currentVoice?.name);
    },
    
    // Verificar se o navegador suporta síntese de voz
    isSupported: function() {
        return 'speechSynthesis' in window;
    },
    
    // Falar um texto em inglês
    speak: function(text, language = 'en-US') {
        if (!this.enabled || !this.isSupported()) {
            console.log('🔇 Sistema de voz desativado ou não suportado');
            return false;
        }
        
        try {
            // Parar qualquer fala anterior
            this.stop();
            
            // Criar nova utterance
            const utterance = new SpeechSynthesisUtterance(text);
            
            // Configurar voz
            if (this.currentVoice) {
                utterance.voice = this.currentVoice;
            }
            utterance.lang = language;
            utterance.rate = 0.8; // Velocidade moderada
            utterance.pitch = 1.0;
            utterance.volume = 1.0;
            
            // Eventos para debug
            utterance.onstart = () => console.log('🎤 Falando:', text);
            utterance.onend = () => console.log('🎤 Fala concluída');
            utterance.onerror = (event) => console.error('🎤 Erro na fala:', event);
            
            // Iniciar fala
            this.speechSynthesis.speak(utterance);
            return true;
            
        } catch (error) {
            console.error('🎤 Erro no sistema de voz:', error);
            return false;
        }
    },
    
    // Parar a fala atual
    stop: function() {
        if (this.speechSynthesis.speaking) {
            this.speechSynthesis.cancel();
            console.log('🎤 Fala interrompida');
        }
    },
    
    // Falar uma palavra em inglês
    speakWord: function(word) {
        return this.speak(word, 'en-US');
    },
    
    // Falar uma frase em inglês
    speakSentence: function(sentence) {
        return this.speak(sentence, 'en-US');
    },
    
    // Pronúncia fonética (exemplo)
    getPhonetic: function(word) {
        const phonetics = {
            'hello': '/həˈloʊ/',
            'water': '/ˈwɔːtər/',
            'children': '/ˈtʃɪldrən/',
            'beautiful': '/ˈbjuːtɪfəl/',
            'enough': '/ɪˈnʌf/',
            'thank you': '/ˈθæŋk juː/',
            'please': '/pliːz/',
            'sorry': '/ˈsɒri/',
            'goodbye': '/ˌɡʊdˈbaɪ/',
            'friend': '/frend/'
        };
        return phonetics[word.toLowerCase()] || '';
    },
    
    // Toggle do sistema de voz
    toggle: function() {
        this.enabled = !this.enabled;
        console.log('🎤 Sistema de voz:', this.enabled ? 'ativado' : 'desativado');
        return this.enabled;
    },
    
    // Verificar status
    getStatus: function() {
        return {
            enabled: this.enabled,
            supported: this.isSupported(),
            voices: this.voices.length,
            currentVoice: this.currentVoice?.name
        };
    }
};

// ===== INTEGRAÇÃO COM AS PERGUNTAS DE INGLÊS =====

// Função para adicionar botões de pronúncia às perguntas
function addPronunciationToEnglishQuestions() {
    const englishQuestions = QUESTIONS['pt']['Inglês'];
    
    englishQuestions.forEach((question, index) => {
        // Adicionar campo de pronúncia se aplicável
        if (shouldHavePronunciation(question.txt)) {
            question.pronunciation = extractPronunciationText(question.txt);
        }
        
        // Adicionar botão de áudio para opções em inglês
        question.opts.forEach((opt, optIndex) => {
            if (isEnglishText(opt)) {
                question.hasAudio = true;
            }
        });
    });
    
    console.log('🎤 Pronúncia adicionada às perguntas de Inglês');
}

// Verificar se a pergunta deve ter pronúncia
function shouldHavePronunciation(questionText) {
    const patterns = [
        /pronúncia/i,
        /pronuncia/i,
        /como se diz/i,
        /como se pronuncia/i,
        /sound/i,
        /listen/i
    ];
    
    return patterns.some(pattern => pattern.test(questionText));
}

// Extrair texto para pronúncia da pergunta
function extractPronunciationText(questionText) {
    if (questionText.includes("'")) {
        // Extrair texto entre aspas simples
        const match = questionText.match(/'([^']+)'/);
        return match ? match[1] : '';
    }
    
    if (questionText.includes('"')) {
        // Extrair texto entre aspas duplas
        const match = questionText.match(/"([^"]+)"/);
        return match ? match[1] : '';
    }
    
    // Tentar encontrar palavra em inglês
    const englishWords = questionText.split(' ').filter(word => 
        isEnglishText(word) && word.length > 2
    );
    
    return englishWords[0] || '';
}

// Verificar se o texto é em inglês
function isEnglishText(text) {
    // Palavras comuns em inglês
    const englishWords = [
        'hello', 'water', 'children', 'beautiful', 'enough', 'thank', 'please',
        'sorry', 'goodbye', 'friend', 'book', 'table', 'hot', 'cold', 'play',
        'sing', 'pizza', 'money', 'interesting', 'happy', 'joyful', 'big', 'small'
    ];
    
    const cleanText = text.replace(/[.,?!]/g, '').toLowerCase();
    return englishWords.includes(cleanText) || /^[a-zA-Z]+$/.test(cleanText);
}

// ===== INICIALIZAÇÃO =====
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        if (SpeechSystem.isSupported()) {
            SpeechSystem.init();
            addPronunciationToEnglishQuestions();
            console.log('🎤 Sistema de pronúncia inicializado');
        } else {
            console.warn('🎤 Navegador não suporta síntese de voz');
        }
    }, 2000);
});

// ===== EXPORTAÇÃO =====
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SpeechSystem;
}

window.SpeechSystem = SpeechSystem;
window.addPronunciationToEnglishQuestions = addPronunciationToEnglishQuestions;