// ===== SISTEMA DE SOM TRAP STYLE 🎧🔥 =====
let audioSystem = {
    enabled: true,
    volume: 0.7,
    musicEnabled: true,
    effectsEnabled: true,
    audioContext: null,
    currentMusic: null,
    
    init: function() {
        this.loadAudioSettings();
        console.log('🎧 Sistema trap inicializado! Volume:', this.volume);
        
        // Inicializar AudioContext quando o usuário interagir
        document.addEventListener('click', this.initializeAudioContext.bind(this), { once: true });
    },
    
    initializeAudioContext: function() {
        try {
            if (!this.audioContext) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                console.log('🎧 AudioContext inicializado');
            }
        } catch (error) {
            console.log('🔇 AudioContext não suportado:', error);
        }
    },
    
    loadAudioSettings: function() {
        try {
            const settings = JSON.parse(localStorage.getItem('quiz_edu_settings'));
            if (settings && settings.sound) {
                this.volume = settings.sound.volume / 100;
                this.musicEnabled = settings.sound.music;
                this.effectsEnabled = settings.sound.effects;
                this.enabled = this.effectsEnabled;
            }
        } catch (e) {
            console.log('🔇 Usando configurações padrão');
        }
    },
    
    playBeep: function(frequency, duration, type = 'sine') {
        if (!this.enabled || !this.effectsEnabled || !this.audioContext) return;
        
        try {
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            oscillator.frequency.value = frequency;
            oscillator.type = type;
            
            // Envelope mais suave
            gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(this.volume, this.audioContext.currentTime + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);
            
            oscillator.start(this.audioContext.currentTime);
            oscillator.stop(this.audioContext.currentTime + duration);
        } catch (error) {
            console.log('🔇 Erro no beep:', error);
        }
    },
    
    playSound: function(type) {
        if (!this.enabled || !this.effectsEnabled) return;
        
        // Garantir que o AudioContext esteja inicializado
        if (!this.audioContext) {
            this.initializeAudioContext();
        }
        
        const sounds = {
            // 🔥 CORRECT - 808 Style
            correct: () => {
                this.playBeep(80, 0.3, 'sine'); // 808 bass
                setTimeout(() => this.playBeep(1200, 0.08, 'square'), 80); // Hi-hat
            },
            
            // 🔥 WRONG - Trap snare
            wrong: () => {
                this.playBeep(150, 0.2, 'square'); // Snare base
                setTimeout(() => this.playBeep(300, 0.1, 'sawtooth'), 30); // Snare noise
            },
            
            // 🔥 CLICK - Hi-hat rápido
            click: () => {
                this.playBeep(1000, 0.03, 'square'); // Hi-hat
            },
            
            // 🔥 BUZZER - 808 + clap
            buzzer: () => {
                this.playBeep(50, 0.4, 'sine'); // 808 sub-bass
                setTimeout(() => this.playBeep(180, 0.15, 'square'), 80); // Clap
                setTimeout(() => this.playBeep(1200, 0.06, 'sawtooth'), 120); // Open hat
            },
            
            // 🔥 VICTORY - Beat completo
            victory: () => {
                // Kick
                this.playBeep(60, 0.3, 'sine');
                // Snare
                setTimeout(() => this.playBeep(150, 0.2, 'square'), 150);
                // Hi-hat pattern
                setTimeout(() => this.playBeep(1000, 0.03, 'square'), 75);
                setTimeout(() => this.playBeep(1000, 0.03, 'square'), 225);
                setTimeout(() => this.playBeep(1000, 0.03, 'square'), 375);
                // Melody
                setTimeout(() => this.playBeep(523, 0.2, 'sawtooth'), 300);
                setTimeout(() => this.playBeep(659, 0.2, 'sawtooth'), 450);
            },
            
            // 🔥 GAME OVER - 808 slide down
            gameOver: () => {
                try {
                    const oscillator = this.audioContext.createOscillator();
                    const gainNode = this.audioContext.createGain();
                    
                    oscillator.connect(gainNode);
                    gainNode.connect(this.audioContext.destination);
                    
                    oscillator.frequency.setValueAtTime(300, this.audioContext.currentTime);
                    oscillator.frequency.exponentialRampToValueAtTime(40, this.audioContext.currentTime + 0.8);
                    oscillator.type = 'sawtooth';
                    
                    gainNode.gain.setValueAtTime(this.volume, this.audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.8);
                    
                    oscillator.start(this.audioContext.currentTime);
                    oscillator.stop(this.audioContext.currentTime + 0.8);
                } catch (error) {
                    console.log('🔇 Erro no game over sound:', error);
                }
            },
            
            // 🔥 NOTIFICATION - Trap bell
            notification: () => {
                this.playBeep(600, 0.15, 'sine');
                setTimeout(() => this.playBeep(500, 0.2, 'sine'), 120);
            },
            
            // 🔥 START - 808 + riser
            start: () => {
                this.playBeep(50, 0.4, 'sine'); // 808
                // Riser
                try {
                    const riser = this.audioContext.createOscillator();
                    const riserGain = this.audioContext.createGain();
                    riser.connect(riserGain);
                    riserGain.connect(this.audioContext.destination);
                    
                    riser.frequency.setValueAtTime(150, this.audioContext.currentTime);
                    riser.frequency.linearRampToValueAtTime(1000, this.audioContext.currentTime + 0.4);
                    riser.type = 'sawtooth';
                    
                    riserGain.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime);
                    riserGain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.4);
                    
                    riser.start(this.audioContext.currentTime);
                    riser.stop(this.audioContext.currentTime + 0.4);
                } catch (error) {
                    console.log('🔇 Erro no riser:', error);
                }
            },
            
            // 🔥 LEVEL UP - Success melody
            levelUp: () => {
                this.playBeep(523, 0.15, 'sine'); // C5
                setTimeout(() => this.playBeep(659, 0.15, 'sine'), 150); // E5
                setTimeout(() => this.playBeep(784, 0.2, 'sine'), 300); // G5
            },
            
            // 🔥 ERROR - Alert sound
            error: () => {
                this.playBeep(200, 0.1, 'square');
                setTimeout(() => this.playBeep(150, 0.15, 'square'), 100);
            }
        };
        
        if (sounds[type]) {
            console.log('🎧 Tocando trap:', type);
            sounds[type]();
        }
    },
    
    // 🎵 Sistema de Música de Fundo
    playBackgroundMusic: function() {
        if (!this.musicEnabled || !this.enabled) return;
        
        // Simular música com osciladores (em um sistema real, usaríamos arquivos de áudio)
        try {
            if (this.currentMusic) {
                this.stopBackgroundMusic();
            }
            
            // Criar uma melodia simples de fundo
            this.playBackgroundMelody();
            
        } catch (error) {
            console.log('🔇 Erro na música de fundo:', error);
        }
    },
    
    playBackgroundMelody: function() {
        if (!this.audioContext) return;
        
        // Implementação simples de melodia de fundo
        const notes = [261.63, 329.63, 392.00, 523.25]; // C, E, G, C
        let currentNote = 0;
        
        this.currentMusic = setInterval(() => {
            if (this.musicEnabled && this.enabled) {
                this.playBeep(notes[currentNote], 0.3, 'sine');
                currentNote = (currentNote + 1) % notes.length;
            }
        }, 800);
    },
    
    stopBackgroundMusic: function() {
        if (this.currentMusic) {
            clearInterval(this.currentMusic);
            this.currentMusic = null;
        }
    },
    
    toggleBackgroundMusic: function() {
        this.musicEnabled = !this.musicEnabled;
        
        if (this.musicEnabled) {
            this.playBackgroundMusic();
        } else {
            this.stopBackgroundMusic();
        }
        
        this.saveAudioSettings();
        return this.musicEnabled;
    },
    
    updateFromUI: function() {
        const volumeSlider = document.getElementById('masterVolume');
        const musicToggle = document.getElementById('musicToggle');
        const effectsToggle = document.getElementById('effectsToggle');
        
        if (volumeSlider) {
            this.volume = parseInt(volumeSlider.value) / 100;
            document.getElementById('volumeValue').textContent = volumeSlider.value + '%';
        }
        if (musicToggle) this.musicEnabled = musicToggle.checked;
        if (effectsToggle) {
            this.effectsEnabled = effectsToggle.checked;
            this.enabled = this.effectsEnabled;
        }
        
        // Atualizar música de fundo baseado nas configurações
        if (this.musicEnabled && !this.currentMusic) {
            this.playBackgroundMusic();
        } else if (!this.musicEnabled && this.currentMusic) {
            this.stopBackgroundMusic();
        }
        
        this.saveAudioSettings();
    },
    
    saveAudioSettings: function() {
        try {
            const settings = JSON.parse(localStorage.getItem('quiz_edu_settings')) || {};
            settings.sound = {
                volume: Math.round(this.volume * 100),
                music: this.musicEnabled,
                effects: this.effectsEnabled
            };
            localStorage.setItem('quiz_edu_settings', JSON.stringify(settings));
        } catch (error) {
            console.log('💾 Erro ao salvar configurações de áudio');
        }
    },
    
    setVolume: function(volumePercent) {
        this.volume = volumePercent / 100;
        this.saveAudioSettings();
    },
    
    toggleMute: function() {
        this.enabled = !this.enabled;
        this.effectsEnabled = this.enabled;
        
        if (!this.enabled) {
            this.stopBackgroundMusic();
        } else if (this.musicEnabled) {
            this.playBackgroundMusic();
        }
        
        this.saveAudioSettings();
        return !this.enabled;
    },
    
    // 🎮 Funções específicas do jogo
    playGameSound: function(type) {
        this.playSound(type);
    },
    
    // 🔊 Efeitos para diferentes ações do jogo
    playAnswerSound: function(isCorrect) {
        if (isCorrect) {
            this.playSound('correct');
        } else {
            this.playSound('wrong');
        }
    },
    
    playGameStart: function() {
        this.playSound('start');
    },
    
    playGameEnd: function(score, totalQuestions) {
        const percentage = (score / (totalQuestions * 10)) * 100;
        if (percentage >= 70) {
            this.playSound('victory');
        } else {
            this.playSound('gameOver');
        }
    },
    
    playBuzzerSound: function() {
        this.playSound('buzzer');
    },
    
    playNotificationSound: function() {
        this.playSound('notification');
    },
    
    // 🎯 Destruir recursos
    destroy: function() {
        this.stopBackgroundMusic();
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
    }
};

// ===== FUNÇÕES GLOBAIS PARA ACESSO FÁCIL =====
function playGameSound(type) {
    audioSystem.playGameSound(type);
}

function playAnswerSound(isCorrect) {
    audioSystem.playAnswerSound(isCorrect);
}

function playBuzzerSound() {
    audioSystem.playBuzzerSound();
}

function toggleAudio() {
    return audioSystem.toggleMute();
}

function updateAudioSettings() {
    audioSystem.updateFromUI();
}

// ===== INICIALIZAÇÃO AUTOMÁTICA =====
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar com um pequeno delay para garantir que tudo esteja carregado
    setTimeout(() => {
        audioSystem.init();
        console.log('🎧 Sistema de áudio carregado e pronto!');
    }, 1000);
});

// ===== EXPORTAÇÃO PARA MÓDULOS =====
if (typeof module !== 'undefined' && module.exports) {
    module.exports = audioSystem;
}

// ===== COMPATIBILIDADE COM NAVEGADORES ANTIGOS =====
if (!window.AudioContext) {
    window.AudioContext = window.webkitAudioContext || window.mozAudioContext;
}