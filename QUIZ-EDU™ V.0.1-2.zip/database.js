// ===== BANCO DE DADOS DE PERGUNTAS =====

const QUESTIONS = {
    // ADICIONAR NO OBJETO QUESTIONS:


    'pt': {
        // MÚSICA (20 perguntas)
        'Música': [
            {
                txt: 'Quem canta "Shape of You"?',
                opts: ['Ed Sheeran', 'Justin Bieber', 'Shawn Mendes', 'Bruno Mars'],
                correct: 0,
                explanation: 'Ed Sheeran é o cantor e compositor de "Shape of You".'
            },
            {
                txt: 'Quem canta "Thriller"?',
                opts: ['Michael Jackson', 'Prince', 'Madonna', 'Elton John'],
                correct: 0,
                explanation: 'Michael Jackson é o "Rei do Pop" e cantor de "Thriller".'
            },
            {
                txt: 'Qual instrumento tem 6 cordas?',
                opts: ['Violão', 'Piano', 'Flauta', 'Bateria'],
                correct: 0,
                explanation: 'O violão tradicional tem 6 cordas.'
            },
            {
                txt: 'Gênero de "Smells Like Teen Spirit"?',
                opts: ['Rock', 'Pop', 'Jazz', 'Reggae'],
                correct: 0,
                explanation: 'Nirvana é uma banda de rock alternativo dos anos 90.'
            },
            {
                txt: 'Quem criou a banda "Queen"?',
                opts: ['Freddie Mercury', 'Brian May', 'Mick Jagger', 'Kurt Cobain'],
                correct: 1,
                explanation: 'Brian May e Roger Taylor fundaram a banda Queen em 1970.'
            },
            {
                txt: 'Qual banda britânica é conhecida como "Fab Four"?',
                opts: ['The Beatles', 'The Rolling Stones', 'Queen', 'Led Zeppelin'],
                correct: 0,
                explanation: 'The Beatles eram chamados de "Fab Four" (Quarteto Fantástico).'
            },
            {
                txt: 'Instrumento principal de um concerto de piano?',
                opts: ['Piano', 'Violino', 'Flauta', 'Bateria'],
                correct: 0,
                explanation: 'O piano é o instrumento solista em um concerto para piano.'
            },
            {
                txt: 'Gênero musical originário da Jamaica?',
                opts: ['Reggae', 'Samba', 'Jazz', 'Rock'],
                correct: 0,
                explanation: 'O reggae surgiu na Jamaica na década de 1960.'
            },
            {
                txt: 'Quem compôs "Nona Sinfonia"?',
                opts: ['Beethoven', 'Mozart', 'Bach', 'Chopin'],
                correct: 0,
                explanation: 'Beethoven compôs a Nona Sinfonia, famosa pelo "Hino à Alegria".'
            },
            {
                txt: 'Qual cantora é conhecida como "Rainha do Pop"?',
                opts: ['Madonna', 'Beyoncé', 'Lady Gaga', 'Rihanna'],
                correct: 0,
                explanation: 'Madonna é frequentemente chamada de "Rainha do Pop".'
            },
            {
                txt: 'Instrumento com teclas pretas e brancas?',
                opts: ['Piano', 'Violão', 'Saxofone', 'Trompete'],
                correct: 0,
                explanation: 'O piano tem teclas pretas e brancas.'
            },
            {
                txt: 'Qual é o plural de "violão"?',
                opts: ['Violões', 'Violãos', 'Violães', 'Violões'],
                correct: 0,
                explanation: 'O plural de violão é "violões".'
            },
            {
                txt: 'Banda de rock com vocalista Freddie Mercury?',
                opts: ['Queen', 'The Beatles', 'AC/DC', 'Nirvana'],
                correct: 0,
                explanation: 'Freddie Mercury foi o vocalista lendário da banda Queen.'
            },
            {
                txt: 'Qual destes é um instrumento de sopro?',
                opts: ['Flauta', 'Violino', 'Piano', 'Guitarra'],
                correct: 0,
                explanation: 'A flauta é um instrumento de sopro.'
            },
            {
                txt: 'Estilo musical com batidas eletrônicas?',
                opts: ['Eletrônica', 'Sertanejo', 'MPB', 'Forró'],
                correct: 0,
                explanation: 'A música eletrônica é caracterizada por batidas e sintetizadores.'
            },
            {
                txt: 'Quem canta "Bad Guy"?',
                opts: ['Billie Eilish', 'Ariana Grande', 'Taylor Swift', 'Dua Lipa'],
                correct: 0,
                explanation: 'Billie Eilish tornou-se famosa com "Bad Guy".'
            },
            {
                txt: 'Qual instrumento é conhecido como "rei dos instrumentos"?',
                opts: ['Órgão', 'Piano', 'Violino', 'Harpa'],
                correct: 0,
                explanation: 'O órgão é frequentemente chamado de "rei dos instrumentos".'
            },
            {
                txt: 'Gênero musical brasileiro com pandeiro e violão?',
                opts: ['Samba', 'Rock', 'Jazz', 'Funk'],
                correct: 0,
                explanation: 'O samba é um gênero musical brasileiro tradicional.'
            },
            {
                txt: 'Quem compôs "As Quatro Estações"?',
                opts: ['Vivaldi', 'Mozart', 'Bach', 'Beethoven'],
                correct: 0,
                explanation: 'Antonio Vivaldi compôs "As Quatro Estações".'
            },
            {
                txt: 'Qual banda tem o álbum "The Dark Side of the Moon"?',
                opts: ['Pink Floyd', 'Led Zeppelin', 'The Beatles', 'Queen'],
                correct: 0,
                explanation: 'Pink Floyd lançou o icônico álbum "The Dark Side of the Moon".'
            }
        ],

        // MATEMÁTICA (25 perguntas)
        'Matemática': [
            {
                txt: 'Quanto é 5 + 7?',
                opts: ['10', '11', '12', '13'],
                correct: 2,
                explanation: '5 + 7 = 12'
            },
            {
                txt: 'Quanto é 9 × 3?',
                opts: ['18', '27', '21', '24'],
                correct: 1,
                explanation: '9 × 3 = 27'
            },
            {
                txt: 'Quanto é 15 ÷ 3?',
                opts: ['3', '5', '4', '6'],
                correct: 1,
                explanation: '15 ÷ 3 = 5'
            },
            {
                txt: 'Qual é o resultado de 8²?',
                opts: ['16', '64', '32', '8'],
                correct: 1,
                explanation: '8² = 8 × 8 = 64'
            },
            {
                txt: 'Quanto é 25% de 100?',
                opts: ['20', '25', '30', '15'],
                correct: 1,
                explanation: '25% de 100 = 25'
            },
            {
                txt: 'Qual é o valor de π (pi) aproximadamente?',
                opts: ['3,14', '2,71', '1,61', '4,13'],
                correct: 0,
                explanation: 'π (pi) é aproximadamente 3,14159'
            },
            {
                txt: 'Quanto é 7 × 8?',
                opts: ['54', '56', '58', '60'],
                correct: 1,
                explanation: '7 × 8 = 56'
            },
            {
                txt: 'Qual é o próximo número: 2, 4, 6, 8, ...?',
                opts: ['9', '10', '11', '12'],
                correct: 1,
                explanation: 'É uma sequência de números pares: 2, 4, 6, 8, 10'
            },
            {
                txt: 'Quanto é 100 - 45?',
                opts: ['55', '65', '45', '35'],
                correct: 0,
                explanation: '100 - 45 = 55'
            },
            {
                txt: 'Qual é a fração equivalente a 0,5?',
                opts: ['1/4', '1/3', '1/2', '2/3'],
                correct: 2,
                explanation: '0,5 = 1/2'
            },
            {
                txt: 'Quanto é 12 × 11?',
                opts: ['121', '132', '122', '134'],
                correct: 1,
                explanation: '12 × 11 = 132'
            },
            {
                txt: 'Qual é a raiz quadrada de 144?',
                opts: ['11', '12', '13', '14'],
                correct: 1,
                explanation: '12 × 12 = 144, então √144 = 12'
            },
            {
                txt: 'Quanto é 3³?',
                opts: ['9', '27', '6', '12'],
                correct: 1,
                explanation: '3³ = 3 × 3 × 3 = 27'
            },
            {
                txt: 'Qual é o resultado de 18 ÷ 6?',
                opts: ['2', '3', '4', '5'],
                correct: 1,
                explanation: '18 ÷ 6 = 3'
            },
            {
                txt: 'Quanto é 14 + 29?',
                opts: ['42', '43', '44', '45'],
                correct: 1,
                explanation: '14 + 29 = 43'
            },
            {
                txt: 'Qual é o perímetro de um quadrado com lado 5cm?',
                opts: ['20cm', '25cm', '10cm', '15cm'],
                correct: 0,
                explanation: 'Perímetro = 4 × lado = 4 × 5 = 20cm'
            },
            {
                txt: 'Quanto é 3/4 de 100?',
                opts: ['65', '70', '75', '80'],
                correct: 2,
                explanation: '3/4 de 100 = 75'
            },
            {
                txt: 'Qual é o número primo?',
                opts: ['4', '6', '9', '7'],
                correct: 3,
                explanation: '7 é um número primo (divisível apenas por 1 e por ele mesmo)'
            },
            {
                txt: 'Quanto é 5² + 3²?',
                opts: ['28', '32', '34', '36'],
                correct: 2,
                explanation: '5² + 3² = 25 + 9 = 34'
            },
            {
                txt: 'Qual é a média de 10, 20 e 30?',
                opts: ['15', '20', '25', '30'],
                correct: 1,
                explanation: 'Média = (10 + 20 + 30) ÷ 3 = 60 ÷ 3 = 20'
            },
            {
                txt: 'Quanto é 8 × 7?',
                opts: ['54', '56', '58', '60'],
                correct: 1,
                explanation: '8 × 7 = 56'
            },
            {
                txt: 'Qual é o dobro de 15?',
                opts: ['25', '30', '35', '40'],
                correct: 1,
                explanation: 'Dobro de 15 = 15 × 2 = 30'
            },
            {
                txt: 'Quanto é 1000 ÷ 10?',
                opts: ['10', '100', '1000', '10000'],
                correct: 1,
                explanation: '1000 ÷ 10 = 100'
            },
            {
                txt: 'Qual é o triplo de 12?',
                opts: ['24', '36', '48', '60'],
                correct: 1,
                explanation: 'Triplo de 12 = 12 × 3 = 36'
            },
            {
                txt: 'Quanto é 45 + 55?',
                opts: ['90', '95', '100', '105'],
                correct: 2,
                explanation: '45 + 55 = 100'
            }
        ],

        // HISTÓRIA (20 perguntas - Internacional + Moçambique)
        'História': [
            {
                txt: 'Quem descobriu o Brasil (1500)?',
                opts: ['Cristóvão Colombo', 'Pedro Álvares Cabral', 'Vasco da Gama', 'Dom Pedro I'],
                correct: 1,
                explanation: 'Pedro Álvares Cabral chegou ao Brasil em 22 de abril de 1500.'
            },
            {
                txt: 'Independência do Brasil em que ano?',
                opts: ['1808', '1822', '1888', '1910'],
                correct: 1,
                explanation: 'Dom Pedro I proclamou a independência do Brasil em 7 de setembro de 1822.'
            },
            {
                txt: 'Em que ano Moçambique tornou-se independente?',
                opts: ['1974', '1975', '1976', '1977'],
                correct: 1,
                explanation: 'Moçambique tornou-se independente de Portugal em 25 de junho de 1975.'
            },
            {
                txt: 'Quem foi o primeiro presidente de Moçambique?',
                opts: ['Samora Machel', 'Joaquim Chissano', 'Eduardo Mondlane', 'Armando Guebuza'],
                correct: 0,
                explanation: 'Samora Machel foi o primeiro presidente de Moçambique (1975-1986).'
            },
            {
                txt: 'Qual era a potência colonial de Moçambique?',
                opts: ['Portugal', 'Espanha', 'França', 'Reino Unido'],
                correct: 0,
                explanation: 'Moçambique foi colônia portuguesa por quase 500 anos.'
            },
            {
                txt: 'Moçambique faz fronteira com quantos países?',
                opts: ['4', '5', '6', '7'],
                correct: 2,
                explanation: 'Moçambique faz fronteira com 6 países: África do Sul, Essuatíni, Zimbábue, Zâmbia, Malawi e Tanzânia.'
            },
            {
                txt: 'Qual é o significado do nome "Moçambique"?',
                opts: ['Terra do Ouro', 'Ilha de Moçambique', 'Terra do Marfim', 'País do Sol'],
                correct: 1,
                explanation: 'O nome vem da Ilha de Moçambique, onde os portugueses estabeleceram seu primeiro posto.'
            },
            {
                txt: 'Em que século os portugueses chegaram a Moçambique?',
                opts: ['XV', 'XVI', 'XVII', 'XVIII'],
                correct: 0,
                explanation: 'Os portugueses chegaram a Moçambique no século XV (1498).'
            },
            {
                txt: 'Qual país africano nunca foi colonizado?',
                opts: ['Etiópia', 'Quênia', 'Nigéria', 'África do Sul'],
                correct: 0,
                explanation: 'A Etiópia é o único país africano que nunca foi formalmente colonizado.'
            },
            {
                txt: 'Quem foi Nelson Mandela?',
                opts: ['Primeiro presidente negro da África do Sul', 'Rei da Etiópia', 'Líder do Quênia', 'Presidente do Egito'],
                correct: 0,
                explanation: 'Nelson Mandela foi o primeiro presidente negro da África do Sul e ícone contra o apartheid.'
            },
            {
                txt: 'Qual civilização africana construiu o Grande Zimbábue?',
                opts: ['Shona', 'Zulu', 'Massai', 'Iorubá'],
                correct: 0,
                explanation: 'O Grande Zimbábue foi construído pelo povo Shona entre os séculos XI e XV.'
            },
            {
                txt: 'Onde ocorreu a Revolução Industrial?',
                opts: ['França', 'Inglaterra', 'EUA', 'Alemanha'],
                correct: 1,
                explanation: 'A Revolução Industrial começou na Inglaterra no século XVIII.'
            },
            {
                txt: 'Qual império era liderado por Gengis Khan?',
                opts: ['Mongol', 'Otomano', 'Romano', 'Persa'],
                correct: 0,
                explanation: 'Gengis Khan fundou o Império Mongol, o maior império contíguo da história.'
            },
            {
                txt: 'Quem foi o primeiro homem a pisar na Lua?',
                opts: ['Neil Armstrong', 'Buzz Aldrin', 'Yuri Gagarin', 'John Glenn'],
                correct: 0,
                explanation: 'Neil Armstrong foi o primeiro homem a pisar na Lua em 20 de julho de 1969.'
            },
            {
                txt: 'Qual civilização construiu Machu Picchu?',
                opts: ['Maias', 'Astecas', 'Incas', 'Toltecas'],
                correct: 2,
                explanation: 'Machu Picchu foi construída pelo Império Inca no século XV.'
            },
            {
                txt: 'Onde nasceu a democracia?',
                opts: ['Roma', 'Atenas', 'Paris', 'Londres'],
                correct: 1,
                explanation: 'A democracia nasceu na Grécia Antiga, especificamente em Atenas.'
            },
            {
                txt: 'Em que ano começou a Primeira Guerra Mundial?',
                opts: ['1912', '1914', '1916', '1918'],
                correct: 1,
                explanation: 'A Primeira Guerra Mundial começou em 1914 após o assassinato do arquiduque Franz Ferdinand.'
            },
            {
                txt: 'Quem foi o líder da Revolução Russa?',
                opts: ['Stálin', 'Lênin', 'Trótski', 'Gorbachev'],
                correct: 1,
                explanation: 'Vladimir Lênin liderou a Revolução Russa de 1917.'
            },
            {
                txt: 'Qual império construiu o Coliseu?',
                opts: ['Grego', 'Romano', 'Persa', 'Egípcio'],
                correct: 1,
                explanation: 'O Coliseu foi construído pelo Império Romano no século I d.C.'
            },
            {
                txt: 'Quem foi o faraó mais famoso do Egito Antigo?',
                opts: ['Ramsés II', 'Tutancâmon', 'Cleópatra', 'Quéops'],
                correct: 1,
                explanation: 'Tutancâmon é o faraó mais famoso devido à descoberta de sua tumba intacta.'
            }
        ],

       // GEOGRAFIA (20 perguntas - Internacional + Moçambique)
        'Geografia': [
            {
                txt: 'Qual é a capital de Moçambique?',
                opts: ['Maputo', 'Beira', 'Nampula', 'Quelimane'],
                correct: 0,
                explanation: 'Maputo é a capital e maior cidade de Moçambique.'
            },
            {
                txt: 'Maior oceano do mundo?',
                opts: ['Pacífico', 'Atlântico', 'Índico', 'Ártico'],
                correct: 0,
                explanation: 'O Oceano Pacífico é o maior oceano, cobrindo cerca de 1/3 da superfície terrestre.'
            },
            {
                txt: 'Qual rio forma parte da fronteira norte de Moçambique?',
                opts: ['Rovuma', 'Zambeze', 'Limpopo', 'Save'],
                correct: 0,
                explanation: 'O Rio Rovuma forma a fronteira natural entre Moçambique e a Tanzânia.'
            },
            {
                txt: 'Qual ilha moçambicana é Patrimônio Mundial da UNESCO?',
                opts: ['Ilha de Moçambique', 'Ilha do Ibo', 'Ilha de Inhaca', 'Ilha do Bazaruto'],
                correct: 0,
                explanation: 'A Ilha de Moçambique é Patrimônio Mundial da UNESCO desde 1991.'
            },
            {
                txt: 'Com quantos países Moçambique faz fronteira?',
                opts: ['6 países', '5 países', '4 países', '7 países'],
                correct: 0,
                explanation: 'Moçambique faz fronteira com 6 países africanos.'
            },
            {
                txt: 'Qual é o clima predominante em Moçambique?',
                opts: ['Tropical', 'Desértico', 'Temperado', 'Polar'],
                correct: 0,
                explanation: 'Moçambique tem clima tropical, com estações chuvosa e seca bem definidas.'
            },
            {
                txt: 'Qual é o maior lago da África?',
                opts: ['Lago Vitória', 'Lago Tanganica', 'Lago Niassa', 'Lago Chade'],
                correct: 0,
                explanation: 'O Lago Vitória é o maior lago da África e o segundo maior do mundo em área superficial.'
            },
            {
                txt: 'Onde fica o Monte Kilimanjaro?',
                opts: ['Quênia', 'Tanzânia', 'Uganda', 'Etiópia'],
                correct: 1,
                explanation: 'O Monte Kilimanjaro, a montanha mais alta da África, fica na Tanzânia.'
            },
            {
                txt: 'Qual é o país mais ao sul da África?',
                opts: ['África do Sul', 'Namíbia', 'Botswana', 'Lesoto'],
                correct: 0,
                explanation: 'A África do Sul é o país mais meridional do continente africano.'
            },
            {
                txt: 'Qual é a cordilheira mais longa do mundo?',
                opts: ['Himalaia', 'Andes', 'Alpes', 'Montanhas Rochosas'],
                correct: 1,
                explanation: 'A Cordilheira dos Andes é a mais longa do mundo, com cerca de 7.000 km.'
            },
            {
                                txt: 'Onde fica o Grand Canyon?',
                opts: ['EUA', 'Canadá', 'México', 'Austrália'],
                correct: 0,
                explanation: 'O Grand Canyon fica no estado do Arizona, Estados Unidos.'
            },
            {
                txt: 'Qual é o país com mais fusos horários?',
                opts: ['Rússia', 'EUA', 'China', 'França'],
                correct: 3,
                explanation: 'A França tem 12 fusos horários devido aos seus territórios ultramarinos.'
            },
            {
                txt: 'Onde fica a Grande Barreira de Coral?',
                opts: ['Austrália', 'Indonésia', 'Filipinas', 'Malásia'],
                correct: 0,
                explanation: 'A Grande Barreira de Coral fica na costa de Queensland, Austrália.'
            },
            {
                txt: 'Qual é o maior deserto do mundo?',
                opts: ['Saara', 'Arábia', 'Gobi', 'Antártica'],
                correct: 3,
                explanation: 'O Deserto Antártico é o maior deserto do mundo em área.'
            },
            {
                txt: 'Qual cidade é conhecida como "Cidade Luz"?',
                opts: ['Roma', 'Paris', 'Londres', 'Nova York'],
                correct: 1,
                explanation: 'Paris é conhecida como "Cidade Luz" devido à iluminação pública pioneira.'
            },
            {
                txt: 'Qual é o menor país do mundo?',
                opts: ['Mônaco', 'Vaticano', 'San Marino', 'Liechtenstein'],
                correct: 1,
                explanation: 'O Vaticano é o menor país do mundo em área e população.'
            },
            {
                txt: 'Quantos continentes existem?',
                opts: ['5', '6', '7', '8'],
                correct: 2,
                explanation: 'Os 7 continentes são: África, América, Antártida, Ásia, Europa, Oceania.'
            },
            {
                txt: 'Qual é o rio mais longo do mundo?',
                opts: ['Amazonas', 'Nilo', 'Yangtzé', 'Mississippi'],
                correct: 0,
                explanation: 'O Rio Amazonas é considerado o mais longo do mundo, com cerca de 6.992 km.'
            },
            {
                txt: 'Onde fica o Monte Everest?',
                opts: ['Índia', 'China', 'Nepal/China', 'Butão'],
                correct: 2,
                explanation: 'O Monte Everest fica na fronteira entre Nepal e China (Tibet).'
            },
            {
                txt: 'Qual é o país mais populoso do mundo?',
                opts: ['Índia', 'China', 'EUA', 'Indonésia'],
                correct: 1,
                explanation: 'A China é o país mais populoso do mundo, com mais de 1,4 bilhão de habitantes.'
            }
        ],

        // CIÊNCIAS (20 perguntas)
        'Ciências': [
            {
                txt: 'O que é fotossíntese?',
                opts: ['Respiração', 'Produção de energia pela luz', 'Digestão', 'Transpiração'],
                correct: 1,
                explanation: 'Fotossíntese é o processo onde plantas convertem luz solar em energia química.'
            },
            {
                txt: 'Água é formada por?',
                opts: ['H2O', 'CO2', 'O2', 'NaCl'],
                correct: 0,
                explanation: 'A água é composta por dois átomos de hidrogênio e um de oxigênio (H₂O).'
            },
            {
                txt: 'Planeta mais próximo do sol?',
                opts: ['Terra', 'Vênus', 'Mercúrio', 'Marte'],
                correct: 2,
                explanation: 'Mercúrio é o planeta mais próximo do Sol no nosso sistema solar.'
            },
            {
                txt: 'Formas de energia incluem?',
                opts: ['Elétrica', 'Quantidade', 'Peso', 'Velocidade'],
                correct: 0,
                explanation: 'Energia elétrica é uma das formas de energia, junto com térmica, cinética, etc.'
            },
            {
                txt: 'O que os pulmões fazem?',
                opts: ['Respirar', 'Digere', 'Transportam', 'Filtram'],
                correct: 0,
                explanation: 'Os pulmões são responsáveis pela respiração, trocando oxigênio por dióxido de carbono.'
            },
            {
                txt: 'Qual é a unidade básica da vida?',
                opts: ['Célula', 'Átomo', 'Molécula', 'Tecido'],
                correct: 0,
                explanation: 'A célula é a unidade básica estrutural e funcional de todos os seres vivos.'
            },
            {
                txt: 'O que causa as estações do ano?',
                opts: ['Distância do Sol', 'Inclinação da Terra', 'Rotação da Terra', 'Órbita da Lua'],
                correct: 1,
                explanation: 'As estações são causadas pela inclinação do eixo da Terra durante sua órbita ao redor do Sol.'
            },
            {
                txt: 'Qual gás é essencial para a respiração?',
                opts: ['Nitrogênio', 'Oxigênio', 'Hélio', 'Carbono'],
                correct: 1,
                explanation: 'O oxigênio é essencial para a respiração celular na maioria dos seres vivos.'
            },
            {
                txt: 'O que é gravidade?',
                opts: ['Força que atrai objetos', 'Tipo de energia', 'Medida de massa', 'Velocidade da luz'],
                correct: 0,
                explanation: 'Gravidade é a força que atrai objetos com massa uns pelos outros.'
            },
            {
                txt: 'Qual planeta é conhecido como "Planeta Vermelho"?',
                opts: ['Vênus', 'Marte', 'Júpiter', 'Saturno'],
                correct: 1,
                explanation: 'Marte é chamado de "Planeta Vermelho" devido ao óxido de ferro em sua superfície.'
            },
            {
                txt: 'O que é um ecossistema?',
                opts: ['Só plantas', 'Só animais', 'Comunidade de seres vivos', 'Tipo de clima'],
                correct: 2,
                explanation: 'Um ecossistema é uma comunidade de seres vivos interagindo com seu ambiente.'
            },
            {
                txt: 'Qual é a velocidade da luz?',
                opts: ['300.000 km/s', '150.000 km/s', '450.000 km/s', '600.000 km/s'],
                correct: 0,
                explanation: 'A velocidade da luz no vácuo é de aproximadamente 300.000 km por segundo.'
            },
            {
                txt: 'O que é reciclagem?',
                opts: ['Jogar lixo fora', 'Reutilizar materiais', 'Queimar resíduos', 'Enterrar lixo'],
                correct: 1,
                explanation: 'Reciclagem é o processo de converter resíduos em novos materiais e objetos.'
            },
            {
                txt: 'Qual é a função do coração?',
                opts: ['Respirar', 'Bombear sangue', 'Digerir comida', 'Pensar'],
                correct: 1,
                explanation: 'O coração bombeia sangue por todo o corpo através do sistema circulatório.'
            },
            {
                txt: 'O que é um átomo?',
                opts: ['Partícula muito grande', 'Unidade básica da matéria', 'Tipo de célula', 'Molécula de água'],
                correct: 1,
                explanation: 'O átomo é a unidade básica da matéria, composto por prótons, nêutrons e elétrons.'
            },
            {
                txt: 'Qual é a principal fonte de energia da Terra?',
                opts: ['Lua', 'Sol', 'Vento', 'Água'],
                correct: 1,
                explanation: 'O Sol é a principal fonte de energia para a Terra, fornecendo luz e calor.'
            },
            {
                txt: 'O que é evolução?',
                opts: ['Mudança rápida', 'Mudança das espécies ao longo do tempo', 'Criação instantânea', 'Extinção'],
                correct: 1,
                explanation: 'Evolução é o processo de mudança nas características das espécies ao longo de gerações.'
            },
            {
                txt: 'Qual é o gás do efeito estufa mais comum?',
                opts: ['Oxigênio', 'Dióxido de Carbono', 'Hélio', 'Nitrogênio'],
                correct: 1,
                explanation: 'Dióxido de Carbono (CO₂) é o principal gás do efeito estufa relacionado às atividades humanas.'
            },
            {
                txt: 'O que é um fóssil?',
                opts: ['Rocha comum', 'Restos preservados de seres vivos', 'Mineral precioso', 'Planta viva'],
                correct: 1,
                explanation: 'Fósseis são restos ou vestígios preservados de animais, plantas e outros organismos.'
            },
            {
                txt: 'Qual é a camada de gás que envolve a Terra?',
                opts: ['Hidrosfera', 'Atmosfera', 'Litosfera', 'Biosfera'],
                correct: 1,
                explanation: 'A atmosfera é a camada de gases que envolve a Terra e é mantida pela gravidade.'
            }
        ],

        // CONTINUAÇÃO COM MAIS CATEGORIAS...
        'Português': [
            // 20 perguntas de Português
    {
        txt: 'Plural de "cidadão"?',
        opts: ['Cidadãos', 'Cidadões', 'Cidões', 'Cidadã'],
        correct: 0,
        explanation: 'O plural de cidadão é "cidadãos".'
    },
    // NOVAS PERGUNTAS:
    {
        txt: 'Qual destes é um exemplo correto do uso do pretérito mais-que-perfeito?',
        opts: ['Se eu estudar, passarei.', 'Ele chegou antes que eu terminasse.', 'Se eu tivesse estudado, teria passado.', 'Eu comera quando chegaram.'],
        correct: 3,
        explanation: '"Eu comera" é a forma simples do pretérito mais-que-perfeito, que indica ação passada anterior a outra ação passada.'
    },
    {
        txt: 'Qual destas palavras é acentuada pela mesma regra de "ópera"?',
        opts: ['prático', 'saúde', 'herói', 'árvore'],
        correct: 3,
        explanation: '"Ópera" e "árvore" são paroxítonas terminadas em "a", acentuadas graficamente.'
    },
    {
        txt: 'Qual destas frases contém um pleonasmo vicioso?',
        opts: ['Subir para cima', 'Há dois anos atrás', 'Ambos os dois', 'Todas as alternativas'],
        correct: 3,
        explanation: 'Todas as opções são exemplos de pleonasmo vicioso (redundância desnecessária).'
    },
    {
        txt: 'Qual a forma aportuguesada correta de "a priori"?',
        opts: ['apriori', 'aprióri', 'apriório', 'Não se aportuguesa'],
        correct: 0,
        explanation: 'De acordo com o Acordo Ortográfico, "a priori" deve ser grafado como "apriori".'
    },
    {
        txt: 'Qual destes pares é exemplo de homonímia perfeita?',
        opts: ['Cedo (verbo) / cedo (advérbio)', 'São (verbo) / são (adjetivo)', 'Cesta (objeto) / sexta (dia)', 'Verão (estação) / verão (verbo)'],
        correct: 1,
        explanation: '"São" (verbo) e "são" (adjetivo) são homónimos perfeitos: mesma grafia e pronúncia, significados diferentes.'
    },
    {
        txt: 'Qual a classificação de "que" em: "Disse que não viria."?',
        opts: ['Pronome relativo', 'Conjunção integrante', 'Conjunção coordenativa', 'Advérbio'],
        correct: 1,
        explanation: '"Que" é conjunção integrante, introduzindo oração subordinada substantiva.'
    },
    {
        txt: 'Qual a forma correta do verbo "adequar" na 1ª pessoa do presente?',
        opts: ['eu adéquo', 'eu adequo', 'eu adequeio', 'eu adequão'],
        correct: 1,
        explanation: 'O verbo "adequar" é regular: eu adequo, tu adequas, ele adequa.'
    },
    {
        txt: 'Qual destes versos de Camões exemplifica sinédoque?',
        opts: ['"Amor é fogo que arde sem se ver"', '"Os bons vi sempre passar"', '"As armas e os barões assinalados"', '"O peito, em que o mar tanto choveu"'],
        correct: 3,
        explanation: '"Peito" é sinédoque - parte pelo todo (peito representa o navegador).'
    },
    {
        txt: 'Qual destas locuções está gramaticalmente incorreta?',
        opts: ['à medida que', 'debaixo de', 'ao invés de', 'a partir de'],
        correct: 0,
        explanation: '"À medida que" é locução conjuncional, não prepositiva.'
    },
    {
        txt: 'Qual a diferença entre "descrição" e "discrição"?',
        opts: ['São sinónimos', 'Descrição é ato de descrever; Discrição é qualidade do discreto.', 'Descrição é erro ortográfico.', 'Discrição é ato de discriminar.'],
        correct: 1,
        explanation: 'São palavras parónimas com significados diferentes.'
    },
    {
        txt: 'Na frase "É preciso aguardarmos.", o "-mos" é:',
        opts: ['Pronome oblíquo', 'Desinência do infinitivo flexionado', 'Pronome de realce', 'Erro gramatical'],
        correct: 1,
        explanation: 'É desinência número-pessoal do infinitivo flexionado.'
    },
    {
        txt: 'Qual destes termos é oxítono?',
        opts: ['café', 'mesa', 'árvore', 'pássaro'],
        correct: 0,
        explanation: 'Oxítonos têm sílaba tónica na última sílaba.'
    },
    {
        txt: 'Qual a origem etimológica de "saudade"?',
        opts: ['Do árabe "sawdah"', 'Do latim "solitatem"', 'Do grego "solitudinos"', 'Do tupi "saubade"'],
        correct: 1,
        explanation: '"Saudade" vem do latim "solitatem" (solidão).'
    },
    {
        txt: 'Qual frase contém zeugma?',
        opts: ['Ela prefere cinema; eu, teatro.', 'Choveu a cântaros.', 'O vento sussurrava segredos.', 'A cidade que nunca dorme.'],
        correct: 0,
        explanation: 'Zeugma é omissão de termo já mencionado ("prefere" foi elidido).'
    },
    {
        txt: 'Qual palavra perdeu o hífen pelo Acordo Ortográfico?',
        opts: ['micro-ondas', 'anti-inflamatório', 'para-raios', 'contra-regra'],
        correct: 3,
        explanation: '"Contra-regra" passou a "contrarregra".'
    },
    {
        txt: 'Qual é o sujeito em "Chove muito hoje."?',
        opts: ['Chove', 'muito', 'hoje', 'Sujeito indeterminado'],
        correct: 3,
        explanation: 'Em "chove", o sujeito é indeterminado.'
    },
    {
        txt: '"Mais bem-humorado" é exemplo de:',
        opts: ['Comparativo de superioridade', 'Superlativo absoluto', 'Superlativo relativo', 'Advérbio de intensidade'],
        correct: 0,
        explanation: '"Mais bem-humorado" é grau comparativo de superioridade.'
    },
    {
        txt: 'Qual destes não é um conectivo de conclusão?',
        opts: ['portanto', 'logo', 'pois', 'assim'],
        correct: 2,
        explanation: '"Pois" é conjunção explicativa, não conclusiva.'
    },
    {
        txt: 'Qual a regência verbal correta de "aspirar"?',
        opts: ['Aspirar algo', 'Aspirar a algo', 'Aspirar por algo', 'Todas corretas'],
        correct: 3,
        explanation: '"Aspirar" pode ser transitivo direto ("aspirar pó") ou indireto ("aspirar ao cargo").'
    }
],
            
            // ... (adicionar mais 19 perguntas)
        

        'Jogos': [
            // 20 perguntas sobre Jogos
            
    // Mantenha as existentes:
    {
        txt: 'Qual jogo é famoso por criar mundos usando blocos 3D?',
        opts: ['Terraria', 'Minecraft', 'Roblox', 'The Sims'],
        correct: 1,
        explanation: 'Minecraft permite criar mundos usando blocos 3D.'
    },
    {
        txt: 'Console da Nintendo famoso: ?',
        opts: ['PlayStation', 'Xbox', 'Nintendo Switch', 'Sega'],
        correct: 2,
        explanation: 'Nintendo Switch é o console híbrido da Nintendo.'
    },
    {
        txt: 'Qual é a principal arma usada em "Counter-Strike: Global Offensive"?',
        opts: ['AK-47', 'M4A1', 'AWP', 'Todas acima'],
        correct: 3,
        explanation: 'Todas as armas listadas são usadas em CS:GO.'
    },
    // NOVAS PERGUNTAS:
    {
        txt: 'Em "The Legend of Zelda: Ocarina of Time", qual é o primeiro templo como adulto?',
        opts: ['Templo do Fogo', 'Templo da Água', 'Templo da Floresta', 'Templo da Sombra'],
        correct: 2,
        explanation: 'O Templo da Floresta é o primeiro que Link completa como adulto.'
    },
    {
        txt: 'Qual empresa desenvolveu "Cyberpunk 2077"?',
        opts: ['Bethesda', 'Ubisoft', 'CD Projekt Red', 'Rockstar'],
        correct: 2,
        explanation: 'Cyberpunk 2077 foi desenvolvido pela CD Projekt Red.'
    },
    {
        txt: 'Qual destes NÃO é um Deus Antigo em "World of Warcraft"?',
        opts: ['C\'Thun', 'Yogg-Saron', 'N\'Zoth', 'Sargeras'],
        correct: 3,
        explanation: 'Sargeras é um Titã, não um Deus Antigo.'
    },
    {
        txt: 'Qual é a espada lendária de Artorias em "Dark Souls"?',
        opts: ['Espada de Quebra-cascos', 'Lâmina da Lua Negra', 'Espada de Gwyn', 'Espada Mestra'],
        correct: 0,
        explanation: 'A Espada de Quebra-cascos é a arma icônica de Artorias.'
    },
    {
        txt: 'Quem é o protagonista silencioso de "Half-Life"?',
        opts: ['Gordon Ramsay', 'Gordon Freeman', 'Barney Calhoun', 'Adrian Shephard'],
        correct: 1,
        explanation: 'Gordon Freeman é o protagonista de Half-Life.'
    },
    {
        txt: 'Em "Elden Ring", quem oferece accordo para se tornar Lorde?',
        opts: ['Ranni, a Bruxa', 'Melina', 'Fia, a Companheira da Morte', 'Sorceress Sellen'],
        correct: 1,
        explanation: 'Melina oferece accordo e permite nivelamento.'
    },
    {
        txt: 'Qual destes é "Soulslike" mas não foi feito pela FromSoftware?',
        opts: ['Demon\'s Souls', 'Bloodborne', 'Sekiro', 'Nioh'],
        correct: 3,
        explanation: 'Nioh foi desenvolvido pela Team Ninja.'
    },
    {
        txt: 'Qual é a cidade principal em "The Witcher 3: Wild Hunt"?',
        opts: ['Novigrad', 'Oxenfurt', 'Vizima', 'Beauclair'],
        correct: 0,
        explanation: 'Novigrad é a maior cidade onde muita trama ocorre.'
    },
    {
        txt: 'Qual vilão de "Metal Gear Solid" usa camuflagem óptica?',
        opts: ['Revolver Ocelot', 'Vulcan Raven', 'Psycho Mantis', 'Gray Fox'],
        correct: 3,
        explanation: 'Gray Fox é o ninja cyborg com camuflagem óptica.'
    },
    {
        txt: 'Qual IA substitui temporariamente a GLaDOS em "Portal 2"?',
        opts: ['Wheatley', 'Cave Johnson', 'ATLAS', 'P-body'],
        correct: 0,
        explanation: 'Wheatley assume o controle do centro de enriquecimento.'
    },
    {
        txt: 'Qual NÃO é um Pokémon lendário de Kanto?',
        opts: ['Articuno', 'Zapdos', 'Moltres', 'Raikou'],
        correct: 3,
        explanation: 'Raikou é da segunda geração (Johto).'
    },
    {
        txt: 'Qual é a gangue de Arthur Morgan em "Red Dead Redemption 2"?',
        opts: ['Os O\'Driscoll', 'A Gangue de Van der Linde', 'Os Lemoyne Raiders', 'Os Braithwaites'],
        correct: 1,
        explanation: 'Arthur faz parte da Gangue de Van der Linde.'
    },
    {
        txt: 'Qual é o sistema de batalha da série "Persona" moderna?',
        opts: ['Sistema de Press Turn', 'Sistema One More', 'Sistema de Batalha em Duplas', 'Sistema ATB'],
        correct: 1,
        explanation: 'O sistema "One More" dá turnos extras por golpes críticos.'
    },
    {
        txt: 'Em qual jogo você gerencia uma fazença com personagens 2D?',
        opts: ['Stardew Valley', 'Minecraft', 'Terraria', 'Farm Together'],
        correct: 0,
        explanation: 'Stardew Valley é um RPG de simulação agrícola em 2D.'
    },
    {
        txt: 'Qual empresa criou a série "The Legend of Zelda"?',
        opts: ['Square Enix', 'Capcom', 'Nintendo', 'Sega'],
        correct: 2,
        explanation: 'Nintendo é a criadora da série The Legend of Zelda.'
    },
    {
        txt: 'Qual destes é um gênero de "The Sims"?',
        opts: ['FPS', 'Simulação de vida', 'RPG de ação', 'Estratégia em tempo real'],
        correct: 1,
        explanation: 'The Sims é um jogo de simulação de vida.'
    },
    {
        txt: 'Em "Grand Theft Auto V", quantos protagonistas controláveis existem?',
        opts: ['1', '2', '3', '4'],
        correct: 2,
        explanation: 'GTA V tem três protagonistas: Michael, Trevor e Franklin.'
    }
],

        'Cultura Geral': [
            // 20 perguntas de Cultura Geral
            {
                txt: 'Qual é a capital de Moçambique?',
                opts: ['Maputo', 'Beira', 'Nampula', 'Quelimane'],
                correct: 0,
                explanation: 'Maputo é a capital e maior cidade de Moçambique.'
            },
    
    {
        txt: 'Qual é o significado etimológico do nome "Moçambique"?',
        opts: ['Terra do Ouro', 'Ilha de Moçambique', 'Filhos do Mar', 'Grande Baía'],
        correct: 1,
        explanation: 'O nome vem da Ilha de Moçambique, derivado de Mussa Bin Bique.'
    },
    {
        txt: 'Qual é o instrumento musical tradicional de cabaça com palhetas?',
        opts: ['Mbira', 'Marimba', 'Xipalapala', 'Timbila'],
        correct: 3,
        explanation: 'A Timbila é instrumento dos Chope, Patrimônio da UNESCO.'
    },
    {
        txt: 'Quem é considerado o "Pai da Nação" moçambicana?',
        opts: ['Joaquim Chissano', 'Samora Machel', 'Eduardo Mondlane', 'Filipe Nyusi'],
        correct: 2,
        explanation: 'Eduardo Mondlane foi primeiro presidente da FRELIMO.'
    },
    {
        txt: 'Qual estilo de dança é originário de Moçambique?',
        opts: ['Marrabenta', 'Kizomba', 'Semba', 'Kuduro'],
        correct: 0,
        explanation: 'Marrabenta é gênero musical e dança nascido em Maputo.'
    },
    {
        txt: 'Em que província fica a Ilha de Moçambique (Patrimônio UNESCO)?',
        opts: ['Nampula', 'Cabo Delgado', 'Zambézia', 'Sofala'],
        correct: 0,
        explanation: 'A Ilha de Moçambique fica na Província de Nampula.'
    },
    {
        txt: 'Qual é a cerimônia de iniciação feminina dos Makonde?',
        opts: ['Ungano', 'Likumbi', 'Mapiko', 'Lipiko'],
        correct: 3,
        explanation: 'Lipiko é cerimônia com escarificações para raparigas Makonde.'
    },
    {
        txt: 'Quem escreveu "Terra Sonâmbula"?',
        opts: ['Luís Bernardo Honwana', 'Paulina Chiziane', 'Mia Couto', 'Ungulani Ba Ka Khosa'],
        correct: 2,
        explanation: 'Mia Couto é autor de "Terra Sonâmbula".'
    },
    {
        txt: 'Onde fica o Parque Nacional da Gorongosa?',
        opts: ['Sofala', 'Inhambane', 'Manica', 'Tete'],
        correct: 0,
        explanation: 'Parque Nacional da Gorongosa fica na Província de Sofala.'
    },
    {
        txt: 'Qual é o principal grupo étnico do sul de Moçambique?',
        opts: ['Macua', 'Sena', 'Shangaan (Tsonga)', 'Maconde'],
        correct: 2,
        explanation: 'Povo Shangaan é predominante no sul.'
    },
    {
        txt: 'Qual destas é língua nacional de Moçambique além do Português?',
        opts: ['Swahili', 'Xitsonga', 'Zulu', 'Shona'],
        correct: 1,
        explanation: 'Xitsonga é uma das línguas bantu nacionais.'
    },
    {
        txt: 'Que evento é comemorado em 7 de Setembro em Moçambique?',
        opts: ['Dia da Independência', 'Dia da Vitória', 'Dia das Forças Armadas', 'Dia da Acordo de Lusaka'],
        correct: 3,
        explanation: 'Dia da Vitória marca Acordos de Lusaka (1974).'
    },
    {
        txt: 'Qual é o estilo de escultura em pau-preto dos Macondes?',
        opts: ['Shetani', 'Ujamaa', 'Ujima', 'Vitalismo'],
        correct: 0,
        explanation: 'Escultura Shetani tem formas abstratas representando espíritos.'
    },
    {
        txt: 'Quem apoiou internacionalmente a luta pela independência?',
        opts: ['Nelson Mandela', 'Julius Nyerere', 'Kwame Nkrumah', 'Patrice Lumumba'],
        correct: 1,
        explanation: 'Julius Nyerere (Tanzânia) apoiou a FRELIMO.'
    },
    {
        txt: 'Qual é o prato nacional de Moçambique?',
        opts: ['Matapa', 'Frango à Zambeziana', 'Galinha à Cafreal', 'Caril de Amendoim'],
        correct: 0,
        explanation: 'Matapa é prato tradicional com folhas de mandioca e camarão.'
    },
    {
        txt: 'Qual país NÃO faz fronteira com Moçambique?',
        opts: ['Zâmbia', 'Zimbábue', 'Botswana', 'Essuatíni'],
        correct: 2,
        explanation: 'Botswana não faz fronteira com Moçambique.'
    },
    {
        txt: 'Qual é o principal produto de exportação de Moçambique?',
        opts: ['Ouro', 'Diamantes', 'Gás Natural', 'Café'],
        correct: 2,
        explanation: 'Gás Natural é principal produto de exportação.'
    },
    {
        txt: 'Quantas províncias tem Moçambique?',
        opts: ['8', '9', '10', '11'],
        correct: 2,
        explanation: 'Moçambique tem 10 províncias mais Maputo Cidade.'
    },
    {
        txt: 'Qual é a moeda oficial de Moçambique?',
        opts: ['Rand', 'Dólar', 'Metical', 'Euro'],
        correct: 2,
        explanation: 'Metical (MT) é a moeda oficial.'
    },
    {
        txt: 'Qual destes é um parque nacional em Moçambique?',
        opts: ['Kruger', 'Serengeti', 'Bazaruto', 'Etosha'],
        correct: 2,
        explanation: 'Parque Nacional do Bazaruto é em Moçambique.'
    },
    {
        txt: 'Em que ano Moçambique adotou o multipartidarismo?',
        opts: ['1975', '1990', '1994', '2000'],
        correct: 1,
        explanation: 'Constituição de 1990 estabeleceu multipartidarismo.'
    }
],
'Doramas': [
    {
        txt: "Qual dorama coreano é conhecido como 'Jogo do Lula'?",
        opts: ["Round 6", "Vincenzo", "Itaewon Class", "Crash Landing on You"],
        correct: 0,
        explanation: "Round 6 (Squid Game) é o dorama coreano sobre jogos mortais."
    },
    {
        txt: "Qual atriz protagoniza 'Crash Landing on You'?",
        opts: ["Son Ye-jin", "Park Min-young", "Kim Go-eun", "Jun Ji-hyun"],
        correct: 0,
        explanation: "Son Ye-jin é a protagonista de Crash Landing on You."
    },
    {
        txt: "Qual dorama é sobre um chef que abre restaurante em Itaewon?",
        opts: ["Itaewon Class", "My Mister", "Hotel del Luna", "Goblin"],
        correct: 0,
        explanation: "Itaewon Class conta a história de um jovem que abre restaurante."
    },
    { txt: "Em ‘Mr. Queen’, quem viaja no tempo para o corpo da rainha Cheorin?", opts: ["Um chef moderno", "Um soldado", "Um professor", "Um hacker"], correct: 0, explanation: "O protagonista é um chef do presente que vai parar no corpo da rainha Cheorin." },

{ txt: "Qual é o nome do rei em ‘Mr. Queen’?", opts: ["Rei Cheoljong", "Rei Gwanghae", "Rei Sejong", "Rei Hwon"], correct: 0, explanation: "Cheoljong é o rei da era Joseon em Mr. Queen." },

{ txt: "Qual é a principal característica da rainha em ‘Mr. Queen’ após a possessão?", opts: ["Comportamento estranho e moderno", "Amante de poesia", "Extremamente introvertida", "Perita em medicina"], correct: 0, explanation: "A rainha passa a agir como alguém moderno, causando situações cômicas." },

{ txt: "Qual gênero define melhor ‘Mr. Queen’?", opts: ["Comédia histórica e fantasia", "Romance escolar", "Thriller policial", "Melodrama trágico"], correct: 0, explanation: "A série mistura comédia, romance e fantasia com elementos históricos." },

{ txt: "Qual habilidade moderna ajuda o protagonista na era Joseon?", opts: ["Cozinhar", "Lutar com espada", "Programar computadores", "Medicina"], correct: 0, explanation: "O protagonista é um chef habilidoso e usa a culinária a seu favor."
},
{ txt: "Em ‘Vincenzo’, qual é a profissão do protagonista?", opts: ["Consigliere da máfia", "Juiz", "Policial", "Cirurgião"], correct: 0, explanation: "Vincenzo Cassano é consigliere da máfia italiana." },

{ txt: "Por que Vincenzo volta para a Coreia?", opts: ["Para recuperar ouro escondido", "Para fugir da lei", "Para reencontrar a família", "Para estudar"], correct: 0, explanation: "Ele retorna para recuperar ouro escondido em um prédio." },

{ txt: "Quem é a parceira principal de Vincenzo?", opts: ["Hong Cha-young", "Seo Ye-ji", "Moon Young", "Yoon Seri"], correct: 0, explanation: "A advogada Hong Cha-young se torna sua principal aliada." },

{ txt: "Qual empresa antagonista em Vincenzo?", opts: ["Babel Group", "SPO Corp", "Shinwa Group", "Vogue Corp"], correct: 0, explanation: "A Babel Group é a corporação vilã da história." },

{ txt: "Qual é o tom principal da série ‘Vincenzo’?", opts: ["Ação, crime e humor negro", "Romance colegial", "Drama médico", "Fantasia histórica"], correct: 0, explanation: "A série mistura máfia, suspense e humor negro." },
{ txt: "Qual dorama tem um CEO fingindo ser funcionário comum para encontrar o amor?", opts: ["Business Proposal", "Penthouse", "Kingdom", "Healer"], correct: 0, explanation: "Em Business Proposal, o CEO vai a encontros às cegas disfarçado." },

{ txt: "Qual dorama envolve uma advogada com espectro autista?", opts: ["Extraordinary Attorney Woo", "Vagabond", "W", "Doctors"], correct: 0, explanation: "Woo Young-woo é protagonista com habilidades únicas." },

{ txt: "Em ‘Goblin’, qual é o papel do protagonista?", opts: ["Um goblin imortal", "Um príncipe moderno", "Um policial", "Um médico"], correct: 0, explanation: "Ele é um goblin imortal buscando descanso eterno." },

{ txt: "Qual dorama mostra uma CEO vinda da Coreia do Sul que cai na Coreia do Norte?", opts: ["Crash Landing on You", "Snowdrop", "While You Were Sleeping", "My Love From the Star"], correct: 0, explanation: "A protagonista cai de parapente na Coreia do Norte." },

{ txt: "Quem administra o hotel dos espíritos em ‘Hotel Del Luna’?", opts: ["Jang Man-wol", "Go Moon-young", "Kim Mijo", "Yoon Seri"], correct: 0, explanation: "Man-wol é a dona do hotel para almas." },

{ txt: "Qual série segue jovens empreendedores e empresas de tecnologia na Coreia?", opts: ["Start-Up", "Sweet Home", "Hospital Playlist", "Twenty-Five Twenty-One"], correct: 0, explanation: "Start-Up foca em start-ups e inovação tecnológica." },

{ txt: "Em ‘Itaewon Class’, qual é o sonho do protagonista?", opts: ["Abrir um restaurante e vencer um conglomerado", "Ser cantor", "Ser professor", "Viajar o mundo"], correct: 0, explanation: "O drama conta a jornada dele abrindo um restaurante." },

{ txt: "Qual dorama é famoso pela frase 'Estou apaixonada por você… no futuro'?", opts: ["Twenty-Five Twenty-One", "Pinocchio", "My Mister", "The Heirs"], correct: 0, explanation: "É uma fala marcante de 2521." },

{ txt: "Qual dorama envolve almas trocando de corpo e magia antiga?", opts: ["Alchemy of Souls", "Kingdom", "Hospital Playlist", "Narco-Saints"], correct: 0, explanation: "Alchemy of Souls mistura magia e romance." },

{ txt: "Qual série retrata a competição extrema por status escolar e riqueza?", opts: ["Penthouse", "Reply 1988", "Weightlifting Fairy", "Sisyphus"], correct: 0, explanation: "Penthouse mostra famílias ricas e segredos." },

{ txt: "Que dorama mostra uma influencer tentando esconder sua aparência real?", opts: ["True Beauty", "Uncanny Counter", "Hellbound", "Misaeng"], correct: 0, explanation: "True Beauty aborda autoestima e aparência." },

{ txt: "Qual dorama tem um alienígena que vive na Coreia há séculos?", opts: ["My Love From the Star", "Taxi Driver", "Kill Me Heal Me", "Flower of Evil"], correct: 0, explanation: "Do Min-joon é um alienígena que vive por centenas de anos." },

{ txt: "Que dorama mostra um grupo de amigos em 1980s com foco em família e nostalgia?", opts: ["Reply 1988", "Hometown Cha-Cha-Cha", "King: Eternal Monarch", "Crash Course In Romance"], correct: 0, explanation: "Reply 1988 retrata amizades e família nos anos 80." },

{ txt: "Em ‘Business Proposal’, o que a protagonista faz no primeiro encontro às cegas?", opts: ["Finge ser outra pessoa", "Revela segredos da empresa", "Foge", "Finge estar doente"], correct: 0, explanation: "Ela vai no lugar da amiga e se passa por outra pessoa." },

{ txt: "Qual dorama envolve um anjo que se apaixona?", opts: ["Angel’s Last Mission: Love", "Kingdom", "Doctor Stranger", "Signal"], correct: 0, explanation: "Angel’s Last Mission fala sobre amor proibido." },

{ txt: "Em ‘Crash Landing on You’, o protagonista masculino é:", opts: ["Um oficial norte-coreano", "Um ator famoso", "Um médico sul-coreano", "Um príncipe"], correct: 0, explanation: "Ele é um oficial da Coreia do Norte." },

{ txt: "Qual dorama apresenta um mundo alternativo conectado por portas misteriosas?", opts: ["The King: Eternal Monarch", "Signal", "Happiness", "Beyond Evil"], correct: 0, explanation: "Mostra mundos paralelos e romance." },

{ txt: "Qual dorama se passa em um hospital com foco em amizade e música?", opts: ["Hospital Playlist", "Doctor Stranger", "Descendants of the Sun", "Good Doctor"], correct: 0, explanation: "Hospital Playlist celebra amizade e medicina." },

{ txt: "Em qual dorama um contador se torna vigilante que punem criminosos?", opts: ["Taxi Driver", "Navillera", "School 2015", "Big Mouth"], correct: 0, explanation: "Taxi Driver é sobre justiça fora da lei." },

{ txt: "Qual dorama tem um romance entre professora e aluno adulto?", opts: ["Crash Course in Romance", "Beyond Evil", "D.P.", "Vagabond"], correct: 0, explanation: "Crash Course in Romance aborda ensino e sentimentos adultos." },
{ txt: "Em ‘Hometown Cha-Cha-Cha’, qual é a profissão do protagonista masculino?", opts: ["Faz-tudo da vila", "Médico", "Advogado", "Professor"], correct: 0, explanation: "Hong Du-sik trabalha como faz-tudo na vila litorânea." },

{ txt: "Qual dorama apresenta um romance entre uma CEO e um empregado da vila litorânea?", opts: ["Hometown Cha-Cha-Cha", "Personal Taste", "Our Beloved Summer", "Love Alarm"], correct: 0, explanation: "Conta a história de um dentista e um faz-tudo." },

{ txt: "Qual dorama apresenta um aplicativo que avisa quando alguém gosta de você?", opts: ["Love Alarm", "Sweet Home", "Unlock My Boss", "Big"], correct: 0, explanation: "Love Alarm gira em torno de um app de amor misterioso." },

{ txt: "Qual dorama envolve monstros e pessoas presas em um prédio?", opts: ["Sweet Home", "Signal", "Kingdom", "The Smile Has Left Your Eyes"], correct: 0, explanation: "Sweet Home mostra sobreviventes enfrentando monstros." },

{ txt: "Em ‘Healer’, qual é a identidade secreta do protagonista?", opts: ["Um mensageiro noturno habilidoso", "Um agente secreto do governo", "Um hacker perigoso", "Um policial infiltrado"], correct: 0, explanation: "Healer trabalha como mensageiro e agente secreto." },

{ txt: "Qual dorama mistura romance, humor e policial, estrelado por Park Min-young e Park Seo-joon?", opts: ["What's Wrong With Secretary Kim?", "Itaewon Class", "Her Private Life", "City Hunter"], correct: 0, explanation: "Conta sobre um CEO narcisista e sua secretária." },

{ txt: "Qual dorama tem um casal que escreve regras para manter amizade mas acabam apaixonados?", opts: ["Our Beloved Summer", "Business Proposal", "Pinocchio", "Flower Boy Next Door"], correct: 0, explanation: "Segue a história de dois ex-namorados documentaristas." },

{ txt: "Em ‘Descendants of the Sun’, o protagonista trabalha como o quê?", opts: ["Soldado das forças especiais", "Advogado militar", "Embaixador", "Piloto"], correct: 0, explanation: "Yoo Shi-jin é capitão das forças especiais." },

{ txt: "Qual dorama se passa em um reino zumbi da era Joseon?", opts: ["Kingdom", "Moon Lovers", "Saimdang", "The Last Empress"], correct: 0, explanation: "Kingdom mistura história com terror e zumbis." },

{ txt: "Qual série tem a protagonista Go Moon-young, autora de livros infantis sombrios?", opts: ["It's Okay to Not Be Okay", "True Beauty", "High Society", "Scarlet Heart"], correct: 0, explanation: "A protagonista é uma escritora excêntrica com traumas." },

{ txt: "Em qual dorama um professor finge ter dupla identidade para proteger sua família?", opts: ["Big Mouth", "Misty", "Insider", "Reborn Rich"], correct: 0, explanation: "Em Big Mouth, ele é confundido com um gênio criminoso." },

{ txt: "Qual dorama traz uma protagonista que trabalha como curadora de arte e é fangirl secreta?", opts: ["Her Private Life", "Love to Hate You", "Touch Your Heart", "Romance is a Bonus Book"], correct: 0, explanation: "Ela é fangirl de um idol e trabalha em museu." },

{ txt: "Qual dorama envolve reencarnação e vingança na vida corporativa?", opts: ["Reborn Rich", "The Glory", "Law School", "Money Heist Korea"], correct: 0, explanation: "O protagonista volta ao passado para se vingar." },

{ txt: "Qual dorama é sobre espalhar justiça contra bullying extremo?", opts: ["The Glory", "A Business Proposal", "Doom at Your Service", "Clean With Passion"], correct: 0, explanation: "A protagonista busca vingança contra bullies escolares." },

{ txt: "Em ‘Reply 1988’, onde os amigos moram?", opts: ["Mesmo bairro tradicional", "Internato escolar", "Grande mansão", "Ilha remota"], correct: 0, explanation: "Moram no mesmo bairro de Seul." },

{ txt: "Qual dorama tem um príncipe que viaja para o futuro moderno?", opts: ["Rooftop Prince", "Kingdom", "Signal", "Kairos"], correct: 0, explanation: "Ele viaja do passado para o presente em busca de respostas." },

{ txt: "Qual dorama tem protagonista com múltiplas personalidades?", opts: ["Kill Me, Heal Me", "The K2", "Good Doctor", "Insider"], correct: 0, explanation: "O personagem tem transtorno dissociativo de identidade." },

{ txt: "Qual dorama tem advogados lidando com casos reais e vidas complexas, sem muito romance?", opts: ["Misaeng", "Tempted", "Bloody Heart", "Start-Up"], correct: 0, explanation: "Misaeng retrata vida corporativa e desafios profissionais." },

{ txt: "Qual dorama mistura romance e viagem no tempo ligado a uma cabana misteriosa?", opts: ["A Time Called You", "Signal", "Sisyphus", "Tomorrow"], correct: 0, explanation: "A história envolve tempo e amor perdido." },

{ txt: "Qual dorama segue um grupo de pessoas que ajudam almas a passarem para o além?", opts: ["Tomorrow", "School 2017", "Vagabond", "Run On"], correct: 0, explanation: "Eles escoltam almas e evitam suicídios." },
    // ... mais 7 perguntas
],
'Doramas': [
    {
        txt: "Qual dorama coreano é conhecido como 'Jogo do Lula'?",
        opts: ["Round 6", "Vincenzo", "Itaewon Class", "Crash Landing on You"],
        correct: 0,
        explanation: "Round 6 (Squid Game) é o dorama coreano sobre jogos mortais."
    },
    {
        txt: "Qual atriz protagoniza 'Crash Landing on You'?",
        opts: ["Park Min-young", "Kim Go-eun", "Son Ye-jin", "Jun Ji-hyun"],
        correct: 2,
        explanation: "Son Ye-jin é a protagonista de Crash Landing on You."
    },
    {
        txt: "Qual dorama é sobre um chef que abre restaurante em Itaewon?",
        opts: ["Goblin", "Itaewon Class", "My Mister", "Hotel del Luna"],
        correct: 1,
        explanation: "Itaewon Class conta a história de um jovem que abre restaurante."
    },
    {
        txt: "Em ‘Mr. Queen’, quem viaja para o corpo da rainha Cheorin?",
        opts: ["Um hacker", "Um professor", "Um chef moderno", "Um soldado"],
        correct: 2,
        explanation: "O protagonista é um chef do presente que vai parar no corpo da rainha."
    },
    {
        txt: "Qual é o nome do rei em ‘Mr. Queen’?",
        opts: ["Rei Sejong", "Rei Hwon", "Rei Cheoljong", "Rei Gwanghae"],
        correct: 2,
        explanation: "Cheoljong é o rei em Mr. Queen."
    },
    {
        txt: "Qual é a principal característica da rainha em ‘Mr. Queen’ após a possessão?",
        opts: ["Extremamente introvertida", "Comportamento estranho e moderno", "Perita em medicina", "Amante de poesia"],
        correct: 1,
        explanation: "A rainha começa a agir como alguém moderno."
    },
    {
        txt: "Qual gênero define ‘Mr. Queen’?",
        opts: ["Romance escolar", "Thriller policial", "Melodrama trágico", "Comédia histórica e fantasia"],
        correct: 3,
        explanation: "Mistura comédia, história e fantasia."
    },
    {
        txt: "Qual habilidade ajuda o protagonista de Mr. Queen na era Joseon?",
        opts: ["Programação", "Medicina", "Cozinhar", "Luta com espada"],
        correct: 2,
        explanation: "Ele é um chef moderno."
    },
    {
        txt: "Em ‘Vincenzo’, qual é o trabalho do protagonista?",
        opts: ["Juiz", "Consigliere da máfia", "Policial", "Cirurgião"],
        correct: 1,
        explanation: "Vincenzo Cassano é consigliere da máfia."
    },
    //21 (0)
{ txt: "Em 'Cafe Minamdang', qual é o trabalho falso do protagonista?", 
  opts: ["Xamã", "Advogado", "Policial", "Corretor"], 
  correct: 0, explanation: "Ele finge ser xamã, mas é ex-perito criminal." },

//22 (3)
{ txt: "Qual personagem é um ex-profiler criminal em Cafe Minamdang?", 
  opts: ["Han Jae-hee", "Seo Hye-won", "Cha Do-hyun", "Nam Han-joon"], 
  correct: 3, explanation: "Nam Han-joon é ex-profiler do FBI coreano." },

//23 (1)
{ txt: "Qual dorama envolve investigação com elementos sobrenaturais e humor?", 
  opts: ["Penthouse", "Cafe Minamdang", "Navillera", "Reply 1994"], 
  correct: 1, explanation: "Cafe Minamdang mistura crime e comédia mística." },

//24 (2)
{ txt: "Qual dorama apresenta um advogado autista super talentoso?", 
  opts: ["Law School", "Good Manager", "Extraordinary Attorney Woo", "Vagabond"], 
  correct: 2 },

//25 (3)
{ txt: "Qual dorama tem romance entre CEO e funcionária impostora?", 
  opts: ["Reply 1997", "Our Beloved Summer", "Start-Up", "Business Proposal"], 
  correct: 3 },

//26 (2)
{ txt: "Qual drama mostra um herói que faz entregas secretas e luta à noite?", 
  opts: ["Happiness", "Taxi Driver", "Healer", "Flower Crew"], 
  correct: 2 },

//27 (2)
{ txt: "Qual drama policial envolve corrupção militar e traição?", 
  opts: ["Start-Up", "Big Mouth", "D.P.", "School 2013"], 
  correct: 2 },

//28 (0)
{ txt: "Qual dorama tem CEO narcisista que muda por causa da secretária?", 
  opts: ["What's Wrong With Secretary Kim", "Vincenzo", "Pinocchio", "Her Private Life"], 
  correct: 0 },

//29 (1)
{ txt: "Qual dorama envolve adolescentes lidando com trauma e identidade?", 
  opts: ["Sweet Home", "True Beauty", "Mr. Sunshine", "Doctor Stranger"], 
  correct: 1 },

//30 (0)
{ txt: "Qual dorama traz romance entre humano e entidade mística guardiã?", 
  opts: ["Goblin", "The K2", "Kingdom", "Kill Me Heal Me"], 
  correct: 0 },

//31 (0)
{ txt: "Qual dorama se passa em ambiente escolar com bullying pesado e vingança?", 
  opts: ["Happiness", "All of Us Are Dead", "Tomorrow", "Twenty-Five Twenty-One"], 
  correct: 0 },

//32 (3)
{ txt: "Qual série apresenta um grupo caçando espíritos que não cruzaram?", 
  opts: ["Snowdrop", "W", "Healer", "Tomorrow"], 
  correct: 3 },

//33 (1)
{ txt: "Qual dorama envolve espionagem corporativa com romance lento?", 
  opts: ["Business Proposal", "Her Private Life", "Start-Up", "Kingdom"], 
  correct: 1 },

//34 (2)
{ txt: "Qual dorama mistura advogados, corrupção e suspense político?", 
  opts: ["Love Alarm", "Heirs", "Big Mouth", "Hometown Cha-Cha-Cha"], 
  correct: 2 },

//35 (3)
{ txt: "Qual romance histórico envolve destino e fantasia com guerreiros mágicos?", 
  opts: ["My Country", "Mr. Queen", "Scarlet Heart", "Alchemy of Souls"], 
  correct: 3 },

//36 (2)
{ txt: "Qual drama apresenta jovens idealistas abrindo empresa de tecnologia?", 
  opts: ["Itaewon Class", "Run On", "Start-Up", "Snowdrop"], 
  correct: 2 },

//37 (2)
{ txt: "Qual dorama mostra policial perseguindo serial killer extremamente cruel?", 
  opts: ["Tomorrow", "Flower of Evil", "Mouse", "Vagabond"], 
  correct: 2 },

//38 (0)
{ txt: "Qual comedy romance envolve CEO tímido e assistente peculiar?", 
  opts: ["My Shy Boss", "Penthouse", "Big Mouth", "W"], 
  correct: 0 },

//39 (1)
{ txt: "Qual dorama apresenta uma rainha com espírito moderno dentro do corpo?", 
  opts: ["Kingdom", "Mr. Queen", "Dali and Cocky Prince", "Royal Secret Agent"], 
  correct: 1 },

//40 (0)
{ txt: "Qual dorama segue amigos de infância em época escolar e anos 80-90?", 
  opts: ["Reply 1988", "Sweet Home", "Signal", "Move to Heaven"], 
  correct: 0 },

//41 (0)
{ txt: "Qual dorama envolve advogada autista com inteligência extraordinária?", 
  opts: ["Doctor Cha", "Divorce Attorney Shin", "Hyena", "Extraordinary Attorney Woo"], 
  correct: 3 }, //obs: mas seu padrão manda 0 → então resposta colocada na posição 0

//42 (3)
{ txt: "Qual série mostra um grupo enfrentando monstros em prédio isolado?", 
  opts: ["Itaewon Class", "Start-Up", "Business Proposal", "Sweet Home"], 
  correct: 3 },

//43 (1)
{ txt: "Qual dorama envolve romance entre repórter e herói secreto lutador?", 
  opts: ["The K2", "Healer", "Big Mouth", "Hyde Jekyll Me"], 
  correct: 1 },

//44 (2)
{ txt: "Qual drama trata de justiça escolar, vingança e violência psicológica?", 
  opts: ["Start-Up", "Pinocchio", "The Glory", "Rooftop Prince"], 
  correct: 2 },

//45 (3)
{ txt: "Qual drama coreano envolve reinado e zumbis históricos?", 
  opts: ["Saimdang", "Mr. Sunshine", "My Country", "Kingdom"], 
  correct: 3 },

//46 (2)
{ txt: "Qual dorama mostra CEO arrogante apaixonando por garota comum?", 
  opts: ["Reply 1994", "W", "Business Proposal", "Crash Landing on You"], 
  correct: 2 },

//47 (2)
{ txt: "Qual dorama apresenta detetive espiritual resolvendo casos pós-vida?", 
  opts: ["Vagabond", "Hell Is Other People", "Tomorrow", "Startup"], 
  correct: 2 },

//48 (0)
{ txt: "Qual série segue médica mudando vida após fugir de casamento tóxico?", 
  opts: ["Doctor Cha", "Hospital Playlist", "Dr. Romantic", "Little Women"], 
  correct: 0 },

//49 (1)
{ txt: "Qual drama investiga corrupção com humor e 'consultoria espiritual'?", 
  opts: ["Move to Heaven", "Café Minamdang", "Big Mouth", "Prison Playbook"], 
  correct: 1 },

//50 (0)
{ txt: "Qual série envolve zumbis em escola e sobrevivência adolescente?", 
  opts: ["All of Us Are Dead", "The Guest", "The K2", "School 2017"], 
  correct: 0 },
  
    { txt: "Qual dorama tem um goblin imortal como protagonista?", 
      opts: ["Goblin", "Hotel Del Luna", "Mr. Queen", "Vincenzo"], 
      correct: 0, explanation: "O protagonista de Goblin é um goblin imortal." },

    // 2 (correct = 3)
    { txt: "Qual dorama se passa em Itaewon com tema de restaurante?", 
      opts: ["Start-Up", "Business Proposal", "Hometown Cha-Cha-Cha", "Itaewon Class"], 
      correct: 3, explanation: "A história de Itaewon Class gira em torno de um restaurante." },

    // 3 (correct = 1)
    { txt: "Em 'Crash Landing on You', a protagonista cai onde?", 
      opts: ["China", "Coreia do Norte", "Japão", "Filipinas"], 
      correct: 1, explanation: "Ela cai acidentalmente na Coreia do Norte." },

    // 4 (correct = 2)
    { txt: "Qual dorama envolve um advogado autista altamente talentoso?", 
      opts: ["It's Okay to Not Be Okay", "The Good Bad Mother", "Extraordinary Attorney Woo", "Vincenzo"], 
      correct: 2, explanation: "Woo Young-woo é uma advogada com TEA extraordinária." },

    // 5 (correct = 3)
    { txt: "Qual dorama envolve vingança contra bullies escolares?", 
      opts: ["Twenty-Five Twenty-One", "Reply 1988", "Snowdrop", "The Glory"], 
      correct: 3, explanation: "The Glory trata de vingança contra bullying extremo." },

    // 6 (correct = 2)
    { txt: "Qual drama apresenta um hotel para espíritos?", 
      opts: ["Start-Up", "Crash Landing on You", "Hotel Del Luna", "Tomorrow"], 
      correct: 2, explanation: "Hotel Del Luna é gerenciado para almas." },

    // 7 (correct = 2)
    { txt: "Qual dorama apresenta um conselheiro da máfia italiana?", 
      opts: ["Healer", "Mr. Sunshine", "Vincenzo", "The K2"], 
      correct: 2, explanation: "Vincenzo é consigliere da máfia." },

    // 8 (correct = 0)
    { txt: "Qual dorama se passa em época Joseon com viagem de espírito no tempo?", 
      opts: ["Mr. Queen", "Kingdom", "Moon Lovers", "Rooftop Prince"], 
      correct: 0, explanation: "Mr. Queen traz um chef atual no corpo de uma rainha." },

    // 9 (correct = 1)
    { txt: "Qual drama envolve uma CEO que se muda para uma vila costeira?", 
      opts: ["Business Proposal", "Hometown Cha-Cha-Cha", "Start-Up", "Our Beloved Summer"], 
      correct: 1, explanation: "O romance se passa na vila de Gongjin." },

    // 10 (correct = 0)
    { txt: "Qual dorama tem um guarda-costas militar e uma médica?", 
      opts: ["Descendants of the Sun", "Snowdrop", "Signal", "Healer"], 
      correct: 0, explanation: "DOTS envolve um capitão e uma médica." },

    // 11 (0)
    { txt: "Em 'Goblin', quem é a noiva do Goblin?", 
      opts: ["Ji Eun-tak", "Cha Young", "Seo Dan", "Go Moon-young"], 
      correct: 0 },

    //12 (3)
    { txt: "Qual dorama tem cenário de start-ups e tecnologia?", 
      opts: ["True Beauty", "Business Proposal", "Itaewon Class", "Start-Up"], 
      correct: 3 },

    //13 (1)
    { txt: "Em 'Mr. Queen', o protagonista originalmente era o quê?", 
      opts: ["Ator", "Chef moderno", "Médico", "Engenheiro"], 
      correct: 1 },

    //14 (2)
    { txt: "Qual série envolve monstros e pessoas presas em um prédio?", 
      opts: ["Hotel Del Luna", "Crash Landing on You", "Sweet Home", "Signal"], 
      correct: 2 },

    //15 (3)
    { txt: "Qual dorama tem mundo paralelo e portas interdimensionais?", 
      opts: ["Healer", "Kill Me Heal Me", "Mr. Sunshine", "The King: Eternal Monarch"], 
      correct: 3 },

    //16 (2)
    { txt: "Qual dorama tem uma advogada com título Woo Young-woo?", 
      opts: ["Healer", "Tomorrow", "Extraordinary Attorney Woo", "Hyena"], 
      correct: 2 },

    //17 (2)
    { txt: "Qual dorama tem um vigilante motorista que pune criminosos?", 
      opts: ["Start-Up", "Good Doctor", "Taxi Driver", "Vagabond"], 
      correct: 2 },

    //18 (0)
    { txt: "Qual drama tem fantasmas resolvendo casos da vida e da morte?", 
      opts: ["Tomorrow", "Signal", "D.P.", "Mouse"], 
      correct: 0 },

    //19 (1)
    { txt: "Qual drama mostra trainees militares enfrentando injustiças?", 
      opts: ["Healer", "Crash Course in Romance", "Itaewon Class", "D.P."], 
      correct: 3 },

    //20 (0)
    { txt: "Qual drama tem romance entre guardião e humana escolhida?", 
      opts: ["Goblin", "My Mister", "Snowdrop", "Business Proposal"], 
      correct: 0 },


    {
        txt: "Por que Vincenzo volta para a Coreia?",
        opts: ["Para reencontrar a família", "Para estudar", "Para fugir da lei", "Para recuperar ouro escondido"],
        correct: 3,
        explanation: "Ele retorna para recuperar ouro."
    },
    ],
   
'Religião': [
    {
        txt: "Qual é o livro sagrado do Cristianismo?",
        opts: ["Bíblia", "Alcorão", "Torá", "Vedas"],
        correct: 0,
        explanation: "A Bíblia é o livro sagrado do Cristianismo."
    },
    {
        txt: "Quantos pilares tem o Islamismo?",
        opts: ["5", "4", "6", "7"],
        correct: 0,
        explanation: "O Islamismo tem 5 pilares fundamentais."
    },
    {
        txt: "Qual cidade é sagrada para cristãos, judeus e muçulmanos?",
        opts: ["Jerusalém", "Meca", "Roma", "Belém"],
        correct: 0,
        explanation: "Jerusalém é cidade sagrada para as três religiões."
    },
    // ... mais 7 perguntas
],

'inglês': [
    {
        txt: "Como se diz 'olá' em inglês?",
        opts: ["Hello", "Goodbye", "Thank you", "Please"],
        correct: 0,
        explanation: "'Hello' é a forma padrão de dizer 'olá' em inglês."
    },
    {
        txt: "Qual é a tradução de 'água' para inglês?",
        opts: ["Water", "Fire", "Earth", "Air"],
        correct: 0,
        explanation: "'Water' significa 'água' em inglês."
    },
    {
        txt: "Complete: I ___ to school every day.",
        opts: ["go", "goes", "going", "went"],
        correct: 0,
        explanation: "A forma correta é 'I go' - presente simples para 'I'."
    },
    {
        txt: "Qual é o plural de 'child'?",
        opts: ["Children", "Childs", "Childes", "Childen"],
        correct: 0,
        explanation: "O plural irregular de 'child' é 'children'."
    },
    {
        txt: "Como se pergunta 'Como você está?' em inglês?",
        opts: ["How are you?", "What is your name?", "Where are you?", "How old are you?"],
        correct: 0,
        explanation: "'How are you?' é a forma correta de perguntar 'Como você está?'."
    },
    {
        txt: "Qual destes é um verbo no passado?",
        opts: ["Played", "Playing", "Plays", "Play"],
        correct: 0,
        explanation: "'Played' é a forma no passado simples do verbo 'play'."
    },
    {
        txt: "Traduza: 'The book is on the table.'",
        opts: ["O livro está sobre a mesa.", "O livro está debaixo da mesa.", "O livro está ao lado da mesa.", "O livro está atrás da mesa."],
        correct: 0,
        explanation: "'On the table' significa 'sobre a mesa'."
    },
    {
        txt: "Qual é o antônimo de 'hot'?",
        opts: ["Cold", "Warm", "Big", "Small"],
        correct: 0,
        explanation: "'Cold' (frio) é o antônimo de 'hot' (quente)."
    },
    {
        txt: "Complete: She ___ a beautiful song.",
        opts: ["sings", "sing", "singing", "sang"],
        correct: 0,
        explanation: "Com 'She' usamos 'sings' no presente simples."
    },
    {
        txt: "Como se diz 'obrigado' em inglês?",
        opts: ["Thank you", "Please", "Sorry", "Hello"],
        correct: 0,
        explanation: "'Thank you' é a forma de dizer 'obrigado' em inglês."
    },
    {
        txt: "Qual é a forma negativa de 'I like pizza'?",
        opts: ["I don't like pizza", "I doesn't like pizza", "I not like pizza", "I no like pizza"],
        correct: 0,
        explanation: "A forma negativa correta é 'I don't like pizza'."
    },
    {
        txt: "What time ___ you get up?",
        opts: ["do", "does", "is", "are"],
        correct: 0,
        explanation: "Com 'you' usamos 'do' para perguntas no presente simples."
    },
    {
        txt: "Traduza: 'Eu tenho dois irmãos.'",
        opts: ["I have two brothers.", "I has two brothers.", "I am two brothers.", "I having two brothers."],
        correct: 0,
        explanation: "'I have' é a forma correta para 'eu tenho'."
    },
    {
        txt: "Qual destes é um adjetivo?",
        opts: ["Beautiful", "Beauty", "Beautifully", "Beautify"],
        correct: 0,
        explanation: "'Beautiful' é um adjetivo que significa 'bonito'."
    },
    {
        txt: "Como se forma o futuro com 'will'?",
        opts: ["I will study", "I will studying", "I will studied", "I will to study"],
        correct: 0,
        explanation: "Com 'will' usamos o verbo na forma base: 'will + verbo'."
    },
    {
        txt: "Qual é a pronúncia correta de 'enough'?",
        opts: ["i-'nəf", "e-noug", "e-nof", "i-nog"],
        correct: 0,
        explanation: "'Enough' se pronuncia /ɪˈnʌf/ - 'i-nəf'."
    },
    {
        txt: "Complete: There ___ many people at the party.",
        opts: ["are", "is", "am", "be"],
        correct: 0,
        explanation: "Com 'many people' (plural) usamos 'are'."
    },
    {
        txt: "Qual é o sinônimo de 'happy'?",
        opts: ["Joyful", "Sad", "Angry", "Tired"],
        correct: 0,
        explanation: "'Joyful' é um sinônimo de 'happy' (feliz)."
    },
    {
        txt: "How ___ money do you have?",
        opts: ["much", "many", "some", "any"],
        correct: 0,
        explanation: "'Much' é usado com substantivos incontáveis como 'money'."
    },
    {
        txt: "Traduza: 'Ele está lendo um livro interessante.'",
        opts: ["He is reading an interesting book.", "He are reading an interesting book.", "He reads an interesting book.", "He read an interesting book."],
        correct: 0,
        explanation: "Presente contínuo: 'is reading' para ações em progresso."
    }
    
],
// Substitua algumas perguntas da categoria Inglês por estas:

    
    // ... mantenha as outras perguntas

            // ... (adicionar mais 19 perguntas)
        

        // ... (adicionar as outras categorias)
    },

    'en': {
        // ENGLISH VERSION OF ALL QUESTIONS
        'Music': [
            {
                txt: 'Who sings "Shape of You"?',
                opts: ['Ed Sheeran', 'Justin Bieber', 'Shawn Mendes', 'Bruno Mars'],
                correct: 0,
                explanation: 'Ed Sheeran is the singer and songwriter of "Shape of You".'
            }
            // ... (traduzir todas as perguntas para inglês)
        ],
        // ... (traduzir todas as categorias)
    }
};

// ===== FUNÇÕES DE ACESSO AO BANCO DE DADOS =====

// Obter todas as categorias disponíveis
function getAvailableCategories(language = currentLanguage) {
    return Object.keys(QUESTIONS[language] || QUESTIONS['pt']);
}

// Obter perguntas de uma categoria específica
function getQuestionsByCategory(category, language = currentLanguage) {
    const langQuestions = QUESTIONS[language] || QUESTIONS['pt'];
    return langQuestions[category] || [];
}

// Obter uma pergunta aleatória de uma categoria
function getRandomQuestion(category, language = currentLanguage) {
    const questions = getQuestionsByCategory(category, language);
    if (questions.length === 0) return null;
    
    const randomIndex = Math.floor(Math.random() * questions.length);
    return questions[randomIndex];
}

// Obter múltiplas perguntas aleatórias
function getRandomQuestions(count = 10, categories = [], language = currentLanguage) {
    let allQuestions = [];
    
    // Se nenhuma categoria for especificada, usar todas
    if (categories.length === 0) {
        categories = getAvailableCategories(language);
    }
    
    // Coletar todas as perguntas das categorias selecionadas
    categories.forEach(category => {
        const categoryQuestions = getQuestionsByCategory(category, language);
        allQuestions = allQuestions.concat(categoryQuestions);
    });
    
    // Embaralhar e selecionar
    const shuffled = allQuestions.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}

// Verificar se uma categoria existe
function categoryExists(category, language = currentLanguage) {
    const langQuestions = QUESTIONS[language] || QUESTIONS['pt'];
    return category in langQuestions;
}

// Obter estatísticas do banco de dados
function getDatabaseStats(language = currentLanguage) {
    const langQuestions = QUESTIONS[language] || QUESTIONS['pt'];
    const stats = {};
    
    Object.keys(langQuestions).forEach(category => {
        stats[category] = langQuestions[category].length;
    });
    
    stats.total = Object.values(stats).reduce((sum, count) => sum + count, 0);
    stats.categories = Object.keys(stats).length - 1; // excluir 'total'
    
    return stats;
}

// Exportar para uso em outros arquivos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        QUESTIONS,
        getAvailableCategories,
        getQuestionsByCategory,
        getRandomQuestion,
        getRandomQuestions,
        categoryExists,
        getDatabaseStats
    };
}