

// ===== SISTEMA DE CORREÇÃO E FALLBACK COMPLETO =====

// ===== REGISTRO DE PROBLEMAS CONHECIDOS =====
const KNOWN_ISSUES = {
    critical: [
        'multiplayer-incomplete',
        'buzzer-incomplete', 
        'puzzle-missing',
        'audio-integration',
        'special-modes-logic'
    ],
    important: [
        'stats-incomplete',
        'achievements-missing',
        'profile-edit-missing'
    ],
    minor: [
        'responsive-issues',
        'animation-optimization'
    ]
};

// ===== SISTEMA DE FALLBACKS =====
const FALLBACK_SYSTEMS = {
    // Fallback para Multiplayer incompleto
    multiplayer: {
        active: false,
        fallbackMessage: '🔧 Modo Multiplayer em desenvolvimento. Use o Modo Buzzer para competir com amigos!',
        redirectTo: 'buzzer'
    },
    
    // Fallback para Buzzer incompleto  
    buzzer: {
        active: false,
        fallbackMessage: '🎯 Modo Buzzer em ajustes finais. Use o Modo Solo para treinar!',
        redirectTo: 'solo'
    },
    
    // Fallback para Puzzle não implementado
    puzzle: {
        active: false,
        fallbackMessage: '🧩 Modo Puzzle chegando em breve! Experimente outros modos.',
        redirectTo: 'solo'
    },
    
    // Fallback para áudio não funcionando
    audio: {
        active: false,
        fallbackMessage: '🔇 Sistema de áudio em configuração. O jogo continuará funcionando normalmente.',
        fallbackAction: 'disableAudio'
    }
};

// ===== DETECÇÃO DE FUNÇÕES FALTANDO =====
function detectMissingFunctions() {
    const missingFunctions = [];
    
    // Verificar funções críticas do Multiplayer
    const multiplayerFunctions = [
        'startMultiplayerGame', 'showMultiplayerGame', 'loadMultiplayerQuestion',
        'selectMultiplayerAnswer', 'detectPlayerFromClick', 'showMultiplayerResults'
    ];
    
    multiplayerFunctions.forEach(func => {
        if (typeof window[func] !== 'function') {
            missingFunctions.push(`multiplayer.${func}`);
            FALLBACK_SYSTEMS.multiplayer.active = true;
        }
    });
    
    // Verificar funções do Buzzer
    const buzzerFunctions = [
        'startBuzzerRound', 'selectBuzzerAnswer', 'handleBuzzerTimeOut'
    ];
    
    buzzerFunctions.forEach(func => {
        if (typeof window[func] !== 'function') {
            missingFunctions.push(`buzzer.${func}`);
            FALLBACK_SYSTEMS.buzzer.active = true;
        }
    });
    
    // Verificar Modo Puzzle
    if (typeof window.loadPuzzleQuestion !== 'function') {
        missingFunctions.push('puzzle.loadPuzzleQuestion');
        FALLBACK_SYSTEMS.puzzle.active = true;
    }
    
    // Verificar integração de áudio
    if (typeof audioSystem === 'undefined' || typeof audioSystem.playSound !== 'function') {
        missingFunctions.push('audio.integration');
        FALLBACK_SYSTEMS.audio.active = true;
    }
    
    console.log('🔍 Funções faltando detectadas:', missingFunctions);
    return missingFunctions;
}

// ===== SISTEMA DE FALLBACK AUTOMÁTICO =====
function initializeFallbackSystems() {
    console.log('🛡️ Inicializando sistemas de fallback...');
    
    // Fallback para Multiplayer
    if (FALLBACK_SYSTEMS.multiplayer.active) {
        patchMultiplayerSystem();
    }
    
    // Fallback para Buzzer
    if (FALLBACK_SYSTEMS.buzzer.active) {
        patchBuzzerSystem();
    }
    
    // Fallback para Puzzle
    if (FALLBACK_SYSTEMS.puzzle.active) {
        patchPuzzleSystem();
    }
    
    // Fallback para Áudio
    if (FALLBACK_SYSTEMS.audio.active) {
        patchAudioSystem();
    }
    
    // Fallback para Estatísticas
    patchStatisticsSystem();
    
    // Fallback para Modos Especiais
    patchSpecialModes();
}

// ===== PATCH PARA MULTIPLAYER =====
function patchMultiplayerSystem() {
    console.log('🔧 Aplicando patch para Multiplayer...');
    
    // Fallback para startMultiplayerGame
    if (typeof startMultiplayerGame === 'undefined') {
        window.startMultiplayerGame = function() {
            showToast(FALLBACK_SYSTEMS.multiplayer.fallbackMessage);
            setTimeout(() => {
                if (typeof startBuzzer === 'function') {
                    startBuzzer();
                } else {
                    showSection('modes');
                }
            }, 2000);
        };
    }
    
    // Fallback para funções multiplayer faltantes
    const multiplayerFallbacks = {
        showMultiplayerGame: function() {
            showToast('🎮 Modo Multiplayer em desenvolvimento');
            showSection('modes');
        },
        loadMultiplayerQuestion: function() {
            showToast('Use o Modo Buzzer para competição multiplayer');
            showSection('buzzer');
        },
        selectMultiplayerAnswer: function() {
            showToast('Sistema multiplayer em ajustes');
        },
        detectPlayerFromClick: function() {
            return 1; // Sempre retorna jogador 1 como fallback
        },
        showMultiplayerResults: function(ranking) {
            createInfoModal('🏆 Resultados Multiplayer', `
                <div style="text-align: center; padding: 20px;">
                    <h3>🎮 Modo Multiplayer</h3>
                    <p>Este modo está em desenvolvimento ativo!</p>
                    <p>Enquanto isso, você pode:</p>
                    <div style="display: grid; gap: 10px; margin: 20px 0;">
                        <button class="btn btn-primary" onclick="startBuzzer()">
                            🎯 Jogar Modo Buzzer
                        </button>
                        <button class="btn btn-secondary" onclick="startGameSetup('solo')">
                            🎮 Jogar Modo Solo
                        </button>
                    </div>
                </div>
            `);
        },
        endMultiplayerGame: function() {
            showSection('modes');
            showToast('Partida multiplayer finalizada');
        }
    };
    
    // Aplicar fallbacks
    Object.keys(multiplayerFallbacks).forEach(funcName => {
        if (typeof window[funcName] === 'undefined') {
            window[funcName] = multiplayerFallbacks[funcName];
        }
    });
}

// ===== PATCH PARA BUZZER =====
function patchBuzzerSystem() {
    console.log('🔧 Aplicando patch para Buzzer...');
    
    const buzzerFallbacks = {
        startBuzzerRound: function() {
            if (!buzzerState.active) return;
            
            buzzerState.questionActive = true;
            buzzerState.currentPlayer = null;
            
            const questions = getRandomQuestions(1, ['Música', 'História', 'Geografia', 'Ciências']);
            if (questions.length === 0) return;
            
            const randomQuestion = questions[0];
            
            document.getElementById('buzzerQuestion').textContent = randomQuestion.txt;
            document.getElementById('startBuzzerBtn').style.display = 'none';
            
            const optionsContainer = document.getElementById('buzzerOptions');
            optionsContainer.innerHTML = '';
            optionsContainer.style.display = 'grid';
            
            randomQuestion.opts.forEach((option, index) => {
                const optionEl = document.createElement('div');
                optionEl.className = 'quiz-option';
                optionEl.textContent = option;
                optionEl.onclick = () => selectBuzzerAnswer(index, randomQuestion);
                optionsContainer.appendChild(optionEl);
            });
            
            startBuzzerTimer();
        },
        
        selectBuzzerAnswer: function(selectedIndex, question) {
            if (!buzzerState.currentPlayer) return;
            
            clearInterval(buzzerState.buzzerTimer);
            
            const player = buzzerState.currentPlayer;
            const options = document.querySelectorAll('#buzzerOptions .quiz-option');
            
            options.forEach((option, index) => {
                option.style.pointerEvents = 'none';
                if (index === question.correct) {
                    option.classList.add('correct');
                } else if (index === selectedIndex) {
                    option.classList.add('wrong');
                }
            });
            
            if (selectedIndex === question.correct) {
                buzzerState.scores[player] += 10;
                document.getElementById('buzzerMessage').textContent = `Jogador ${player} acertou! +10 pontos`;
                document.getElementById('buzzerMessage').style.color = 'var(--success)';
                
                // Tocar som de acerto se disponível
                if (typeof audioSystem !== 'undefined') {
                    audioSystem.playSound('correct');
                }
            } else {
                buzzerState.scores[player] = Math.max(0, buzzerState.scores[player] - 5);
                document.getElementById('buzzerMessage').textContent = `Jogador ${player} errou! -5 pontos`;
                document.getElementById('buzzerMessage').style.color = 'var(--danger)';
                
                // Tocar som de erro se disponível
                if (typeof audioSystem !== 'undefined') {
                    audioSystem.playSound('wrong');
                }
            }
            
            document.getElementById(`player${player}Score`).textContent = buzzerState.scores[player];
            
            setTimeout(() => {
                resetBuzzerRound();
            }, 2000);
        },
        
        handleBuzzerTimeOut: function() {
            if (!buzzerState.currentPlayer) {
                document.getElementById('buzzerMessage').textContent = 'Tempo esgotado! Ninguém respondeu.';
                document.getElementById('buzzerMessage').style.color = 'var(--warning)';
            }
            
            setTimeout(() => {
                resetBuzzerRound();
            }, 2000);
        }
    };
    
    // Aplicar fallbacks do buzzer
    Object.keys(buzzerFallbacks).forEach(funcName => {
        if (typeof window[funcName] === 'undefined') {
            window[funcName] = buzzerFallbacks[funcName];
        }
    });
}

// ===== PATCH PARA PUZZLE =====
function patchPuzzleSystem() {
    console.log('🔧 Aplicando patch para Puzzle...');
    
    window.loadPuzzleQuestion = function(question) {
        // Fallback: converter puzzle para múltipla escolha normal
        document.getElementById('quizQuestion').innerHTML = `
            <div style="text-align: center;">
                <div>🧩 ${question.txt}</div>
                <div style="color: var(--text-muted); font-size: 0.9em; margin-top: 10px;">
                    Modo Puzzle em desenvolvimento - Versão múltipla escolha
                </div>
            </div>
        `;
        
        const optionsContainer = document.getElementById('quizOptions');
        optionsContainer.innerHTML = '';
        
        question.opts.forEach((option, index) => {
            const optionEl = document.createElement('div');
            optionEl.className = 'quiz-option';
            optionEl.textContent = option;
            optionEl.onclick = () => selectAnswer(index);
            optionsContainer.appendChild(optionEl);
        });
    };
}

// ===== PATCH PARA ÁUDIO =====
function patchAudioSystem() {
    console.log('🔧 Aplicando patch para Áudio...');
    
    // Criar sistema de áudio mínimo se não existir
    if (typeof audioSystem === 'undefined') {
        window.audioSystem = {
            enabled: false,
            volume: 0,
            musicEnabled: false,
            effectsEnabled: false,
            playSound: function(type) {
                console.log('🔇 Áudio desativado:', type);
            },
            playGameSound: function(type) {
                console.log('🔇 Som de jogo desativado:', type);
            },
            playAnswerSound: function(isCorrect) {
                console.log('🔇 Resposta:', isCorrect ? 'correta' : 'incorreta');
            },
            init: function() {
                console.log('🔇 Sistema de áudio em modo fallback');
            }
        };
    }
}

// ===== PATCH PARA ESTATÍSTICAS =====
function patchStatisticsSystem() {
    console.log('🔧 Aplicando patch para Estatísticas...');
    
    // Garantir que showStats exista e funcione
    if (typeof showStats === 'undefined') {
        window.showStats = function() {
            if (!currentUser) {
                showToast('🔒 Faça login para ver estatísticas');
                return;
            }
            
            createInfoModal('📊 Estatísticas', `
                <div style="text-align: center;">
                    <h3>📈 Sistema de Estatísticas</h3>
                    <p>Recurso em desenvolvimento</p>
                    <p>Em breve: estatísticas detalhadas por modo de jogo</p>
                </div>
            `);
        };
    }
}

// ===== PATCH PARA MODOS ESPECIAIS =====
function patchSpecialModes() {
    console.log('🔧 Aplicando patch para Modos Especiais...');
    
    // SpeedQuiz - Timer de 10 segundos
    const originalStartTimer = window.startTimer;
    if (typeof originalStartTimer === 'function') {
        window.startTimer = function() {
            if (gameState.mode === 'speed') {
                // Timer de 10 segundos para SpeedQuiz
                clearInterval(gameState.timer);
                gameState.timeLeft = 10;
                document.getElementById('timeLeft').textContent = gameState.timeLeft;
                document.getElementById('quizTimer').style.width = '100%';
                
                gameState.timer = setInterval(() => {
                    gameState.timeLeft--;
                    document.getElementById('timeLeft').textContent = gameState.timeLeft;
                    document.getElementById('quizTimer').style.width = `${(gameState.timeLeft / 10) * 100}%`;
                    
                    if (gameState.timeLeft <= 0) {
                        clearInterval(gameState.timer);
                        handleTimeOut();
                    }
                }, 1000);
            } else {
                // Usar timer normal para outros modos
                originalStartTimer();
            }
        };
    }
    
    // Tabuada - Gerar perguntas de multiplicação
    const originalGetRandomQuestions = window.getRandomQuestions;
    if (typeof originalGetRandomQuestions === 'function') {
        window.getRandomQuestions = function(count = 10, categories = []) {
            // Se for modo tabuada, gerar perguntas de multiplicação
            if (gameConfig.mode === 'tabuada') {
                return generateMultiplicationQuestions(count);
            }
            
            // Caso contrário, usar sistema normal
            return originalGetRandomQuestions(count, categories);
        };
    }
}

// ===== GERADOR DE PERGUNTAS DE MULTIPLICAÇÃO =====
function generateMultiplicationQuestions(count) {
    const questions = [];
    
    for (let i = 0; i < count; i++) {
        const num1 = Math.floor(Math.random() * 10) + 1;
        const num2 = Math.floor(Math.random() * 10) + 1;
        const correctAnswer = num1 * num2;
        
        // Gerar opções
        const options = [correctAnswer];
        while (options.length < 4) {
            const wrongAnswer = correctAnswer + Math.floor(Math.random() * 10) - 5;
            if (wrongAnswer !== correctAnswer && wrongAnswer > 0 && !options.includes(wrongAnswer)) {
                options.push(wrongAnswer);
            }
        }
        
        // Embaralhar opções
        options.sort(() => Math.random() - 0.5);
        const correctIndex = options.indexOf(correctAnswer);
        
        questions.push({
            txt: `Quanto é ${num1} × ${num2}?`,
            opts: options.map(opt => opt.toString()),
            correct: correctIndex,
            explanation: `${num1} × ${num2} = ${correctAnswer}`
        });
    }
    
    return questions;
}

// ===== SISTEMA DE VERIFICAÇÃO DE INTEGRIDADE =====
function performIntegrityCheck() {
    console.log('🔍 Realizando verificação de integridade...');
    
    const integrityReport = {
        timestamp: new Date().toISOString(),
        missingFunctions: detectMissingFunctions(),
        fallbacksActive: Object.keys(FALLBACK_SYSTEMS).filter(key => FALLBACK_SYSTEMS[key].active),
        coreSystems: {
            database: typeof QUESTIONS !== 'undefined',
            authentication: typeof currentUser !== 'undefined',
            gameEngine: typeof gameState !== 'undefined',
            audio: typeof audioSystem !== 'undefined'
        },
        uiComponents: {
            sections: document.querySelectorAll('.section').length,
            interactiveElements: document.querySelectorAll('button, .btn').length
        }
    };
    
    console.log('📊 Relatório de integridade:', integrityReport);
    
    // Se houver muitos problemas, mostrar aviso
    const criticalIssues = integrityReport.missingFunctions.filter(f => f.includes('multiplayer') || f.includes('buzzer'));
    if (criticalIssues.length > 2) {
        showToast('⚠️ Alguns recursos estão em desenvolvimento. O jogo principal funciona normalmente!');
    }
    
    return integrityReport;
}

// ===== SISTEMA DE RECUPERAÇÃO =====
function attemptRecovery() {
    console.log('🔄 Tentando recuperação automática...');
    
    try {
        // 1. Verificar e recriar variáveis globais se necessário
        if (typeof gameState === 'undefined') {
            window.gameState = {
                mode: null,
                score: 0,
                streak: 0,
                currentQuestion: 0,
                totalQuestions: 10,
                timeLeft: 30,
                timer: null,
                helpUsed: false,
                selectedCategories: [],
                questions: []
            };
        }
        
        if (typeof buzzerState === 'undefined') {
            window.buzzerState = {
                active: false,
                currentPlayer: null,
                scores: {1: 0, 2: 0},
                timer: 15,
                buzzerTimer: null,
                questionActive: false
            };
        }
        
        if (typeof gameConfig === 'undefined') {
            window.gameConfig = {
                mode: '',
                category: 'random',
                questionCount: 10,
                difficulty: 'medium',
                timePerQuestion: 30
            };
        }
        
        // 2. Recriar funções essenciais se faltarem
        const essentialFunctions = {
            showToast: function(message, duration = 3000) {
                console.log('💬 Toast:', message);
                alert(message); // Fallback simples
            },
            showSection: function(sectionId) {
                document.querySelectorAll('.section').forEach(section => {
                    section.classList.remove('active');
                });
                const target = document.getElementById(sectionId);
                if (target) target.classList.add('active');
            }
        };
        
        Object.keys(essentialFunctions).forEach(funcName => {
            if (typeof window[funcName] === 'undefined') {
                window[funcName] = essentialFunctions[funcName];
            }
        });
        
        console.log('✅ Recuperação automática concluída');
        return true;
        
    } catch (error) {
        console.error('❌ Falha na recuperação automática:', error);
        return false;
    }
}

// ===== INICIALIZAÇÃO ROBUSTA =====
function initializeApplication() {
    console.log('🚀 Iniciando QUIZ-EDU com sistema de correção...');
    
    try {
        // 1. Verificação de integridade
        const integrityReport = performIntegrityCheck();
        
        // 2. Tentativa de recuperação se necessário
        if (integrityReport.missingFunctions.length > 5) {
            if (!attemptRecovery()) {
                throw new Error('Falha crítica na recuperação do sistema');
            }
        }
        
        // 3. Inicializar sistemas de fallback
        initializeFallbackSystems();
        
        // 4. Inicializar sistemas principais (se existirem)
        initializeCoreSystemsSafely();
        
        // 5. Configurar interface
        setupUserInterfaceSafely();
        
        // 6. Mostrar aplicação
        showApplicationSafely();
        
        console.log('✅ QUIZ-EDU inicializado com correções aplicadas');
        
    } catch (error) {
        console.error('❌ Erro crítico na inicialização:', error);
        showEmergencyInterface();
    }
}

function initializeCoreSystemsSafely() {
    try {
        if (typeof initializeLanguage === 'function') initializeLanguage();
        if (typeof initializeTheme === 'function') initializeTheme();
        if (typeof audioSystem !== 'undefined' && audioSystem.init) audioSystem.init();
        if (typeof loadRanking === 'function') loadRanking();
    } catch (error) {
        console.warn('⚠️ Alguns sistemas não inicializaram:', error);
    }
}

function setupUserInterfaceSafely() {
    try {
        // Configurações básicas de UI que sempre devem funcionar
        document.body.style.paddingTop = '70px';
        document.body.style.paddingBottom = '70px';
        
        // Mostrar top bar e footer
        const topBar = document.querySelector('.top-bar');
        const footer = document.querySelector('.footer');
        if (topBar) topBar.style.display = 'flex';
        if (footer) footer.style.display = 'block';
        
    } catch (error) {
        console.warn('⚠️ Problemas na configuração da UI:', error);
    }
}

function showApplicationSafely() {
    try {
        const initialSection = document.getElementById('initial');
        if (initialSection) {
            showSection('initial');
        } else {
            // Fallback: mostrar primeira seção disponível
            const firstSection = document.querySelector('.section');
            if (firstSection) {
                firstSection.classList.add('active');
            }
        }
        
        setTimeout(() => {
            showToast('🎮 QUIZ-EDU carregado com sistema de correção ativo!');
        }, 1000);
        
    } catch (error) {
        console.error('❌ Erro ao mostrar aplicação:', error);
    }
}

function showEmergencyInterface() {
    console.log('🚨 Mostrando interface de emergência...');
    
    const emergencyHTML = `
        <div style="
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: var(--bg-dark);
            display: flex; flex-direction: column;
            align-items: center; justify-content: center;
            z-index: 9999; padding: 20px; text-align: center;
        ">
            <div style="font-size: 4em; margin-bottom: 20px;">🛠️</div>
            <h1 style="color: var(--primary); margin-bottom: 20px;">QUIZ-EDU</h1>
            <p style="color: var(--text); margin-bottom: 30px; max-width: 500px;">
                Estamos com alguns ajustes técnicos. Alguns recursos podem não estar disponíveis no momento.
            </p>
            <div style="display: flex; gap: 15px; flex-wrap: wrap; justify-content: center;">
                <button onclick="location.reload()" class="btn btn-primary">
                    🔄 Tentar Novamente
                </button>
                <button onclick="showSection('modes')" class="btn btn-secondary">
                    🎮 Tentar Jogar Anyway
                </button>
            </div>
        </div>
    `;
    
    document.body.innerHTML = emergencyHTML;
}

// ===== INICIALIZAÇÃO AUTOMÁTICA =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM carregado - Iniciando sistema de correção...');
    
    // Pequeno delay para garantir que todos os scripts carreguem
    setTimeout(() => {
        initializeApplication();
    }, 100);
});

// ===== BACKUP: INICIALIZAÇÃO TARDIA =====
setTimeout(() => {
    if (typeof gameState === 'undefined') {
        console.warn('🔄 Inicialização tardia - aplicando correções...');
        initializeApplication();
    }
}, 3000);


// ===== EXPORTAÇÃO PARA USO GLOBAL =====
window.initializeApplication = initializeApplication;
window.detectMissingFunctions = detectMissingFunctions;
window.performIntegrityCheck = performIntegrityCheck;
window.attemptRecovery = attemptRecovery;

console.log('🛡️ Sistema de correção carregado e pronto');